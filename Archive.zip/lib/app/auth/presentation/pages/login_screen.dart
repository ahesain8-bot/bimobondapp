import 'package:bimobondapp/app/auth/presentation/bloc/auth_bloc.dart';
import 'package:bimobondapp/app/auth/presentation/bloc/auth_event.dart';
import 'package:bimobondapp/app/auth/presentation/bloc/auth_state.dart';
import 'package:bimobondapp/app/auth/presentation/utils/auth_message_localizer.dart';
import 'package:bimobondapp/app/auth/presentation/utils/post_signup_navigation.dart';
import 'package:bimobondapp/app/auth/presentation/widgets/login/google_login_sheet.dart';
import 'package:bimobondapp/app/auth/presentation/widgets/login/login_view.dart';
import 'package:bimobondapp/core/theme/cubit/locale_cubit.dart';
import 'package:bimobondapp/core/widgets/popup_dialogs.dart';
import 'package:bimobondapp/l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class LoginScreen extends StatefulWidget {
  final String language;

  const LoginScreen({super.key, this.language = 'ar'});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _hasLoggedIn = false;
  bool _isSubmitting = false;

  Future<void> _onGooglePressed() async {
    final proceed = await GoogleLoginSheet.show(context);
    if (!proceed || !mounted) return;

    setState(() {
      _isSubmitting = true;
      _hasLoggedIn = true;
    });
    context.read<AuthBloc>().add(const GoogleLoginRequestedEvent());
  }

  Future<void> _onApplePressed() async {
    final l10n = AppLocalizations.of(context)!;
    PopupDialogs.showErrorDialog(context, l10n.settingsComingSoon);
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LocaleCubit, Locale>(
      builder: (context, locale) {
        final l10n = AppLocalizations.of(context)!;
        final isArabic = locale.languageCode == 'ar';
        final isDark = Theme.of(context).brightness == Brightness.dark;

        return BlocConsumer<AuthBloc, AuthState>(
          listenWhen: (previous, current) =>
              current is AuthFailure || current is AuthSuccess,
          listener: (context, state) {
            if (!_isSubmitting) return;

            if (state is AuthFailure) {
              setState(() => _isSubmitting = false);
              final message = state.messageKey != null
                  ? localizeAuthMessage(l10n, state.messageKey!)
                  : state.message;
              PopupDialogs.showErrorDialog(context, message);
            } else if (state is AuthSuccess) {
              setState(() => _isSubmitting = false);
              if (_hasLoggedIn) {
                PopupDialogs.showSuccessDialog(context, l10n.loginSuccess);
              }
              navigateAfterAuth(context, user: state.user);
            }
          },
          builder: (context, state) {
            return LoginView(
              l10n: l10n,
              isArabic: isArabic,
              isDark: isDark,
              onGooglePressed: _onGooglePressed,
              onApplePressed: _onApplePressed,
            );
          },
        );
      },
    );
  }
}
