import 'package:bimobondapp/app/auth/domain/repositories/auth_repository.dart';
import 'package:bloc/bloc.dart';
import 'package:bimobondapp/app/auth/domain/usecases/login_usecase.dart';
import 'package:bimobondapp/app/auth/domain/usecases/sign_up_with_email_usecase.dart';
import 'package:bimobondapp/app/auth/domain/usecases/verify_phone_usecase.dart';
import 'package:bimobondapp/app/auth/domain/usecases/sign_in_with_phone_usecase.dart';
import 'package:bimobondapp/app/auth/domain/usecases/sign_in_with_google_usecase.dart';
import 'package:bimobondapp/app/auth/domain/usecases/update_profile_usecase.dart';
import 'package:bimobondapp/app/auth/domain/usecases/get_profile_usecase.dart';
import 'package:bimobondapp/app/auth/domain/usecases/send_otp_usecase.dart';
import 'package:bimobondapp/app/auth/domain/usecases/verify_otp_usecase.dart';
import 'package:bimobondapp/app/auth/domain/usecases/reset_password_usecase.dart';
import 'package:bimobondapp/core/usecases/usecase.dart';

import 'package:bimobondapp/app/auth/presentation/bloc/auth_event.dart';
import 'package:bimobondapp/app/auth/presentation/bloc/auth_state.dart';
import 'package:bimobondapp/core/error/error_message_resolver.dart';
import 'package:bimobondapp/core/error/failures.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository authRepository;
  final LoginUseCase loginUseCase;
  final SignUpWithEmailUseCase signUpWithEmailUseCase;
  final VerifyPhoneUseCase verifyPhoneUseCase;
  final SignInWithPhoneUseCase signInWithPhoneUseCase;
  final SignInWithGoogleUseCase signInWithGoogleUseCase;
  final UpdateProfileUseCase updateProfileUseCase;
  final GetProfileUseCase getProfileUseCase;
  final SendOtpUseCase sendOtpUseCase;
  final VerifyOtpUseCase verifyOtpUseCase;
  final ResetPasswordUseCase resetPasswordUseCase;

  AuthBloc({
    required this.authRepository,
    required this.loginUseCase,
    required this.signUpWithEmailUseCase,
    required this.verifyPhoneUseCase,
    required this.signInWithPhoneUseCase,
    required this.signInWithGoogleUseCase,
    required this.updateProfileUseCase,
    required this.getProfileUseCase,
    required this.sendOtpUseCase,
    required this.verifyOtpUseCase,
    required this.resetPasswordUseCase,
  }) : super(AuthInitial()) {
    on<CheckAuthStatusEvent>(_onCheckAuthStatus);
    on<LoginSubmittedEvent>(_onLoginSubmitted);
    on<VerifyPhoneEvent>(_onVerifyPhone);
    on<PhoneCodeSentEvent>(_onPhoneCodeSent);
    on<PhoneAuthFailedEvent>(_onPhoneAuthFailed);
    on<SubmitOtpEvent>(_onSubmitOtp);
    on<GoogleLoginRequestedEvent>(_onGoogleLoginRequested);
    on<UpdateProfileRequestedEvent>(_onUpdateProfileRequested);
    on<FetchProfileEvent>(_onFetchProfile);
    on<LogoutRequestedEvent>(_onLogoutRequested);
    on<SignUpWithEmailEvent>(_onSignUpWithEmail);
    on<SendEmailOtpEvent>(_onSendEmailOtp);
    on<VerifyEmailOtpEvent>(_onVerifyEmailOtp);
    on<ResetPasswordRequestedEvent>(_onResetPassword);
  }

  Future<void> _onFetchProfile(
    FetchProfileEvent event,
    Emitter<AuthState> emit,
  ) async {
    final cachedUser = state is AuthSuccess
        ? (state as AuthSuccess).user
        : null;

    final result = await getProfileUseCase(NoParams());
    result.fold((failure) {
      if (failure is UnauthorizedFailure || failure.message == 'Not Found') {
        add(const LogoutRequestedEvent());
        return;
      }
      if (cachedUser != null) {
        emit(AuthSuccess(user: cachedUser));
      }
    }, (user) => emit(AuthSuccess(user: user)));
  }

  void _onLogoutRequested(
    LogoutRequestedEvent event,
    Emitter<AuthState> emit,
  ) async {
    await authRepository.logout();
    emit(AuthInitial());
  }

  Future<void> _onCheckAuthStatus(
    CheckAuthStatusEvent event,
    Emitter<AuthState> emit,
  ) async {
    final result = await authRepository.getCachedUser();
    result.fold((failure) => emit(AuthInitial()), (user) {
      if (user != null) {
        emit(AuthSuccess(user: user));
        add(const FetchProfileEvent());
      } else {
        emit(AuthInitial());
      }
    });
  }

  Future<void> _onLoginSubmitted(
    LoginSubmittedEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    final result = await loginUseCase(
      LoginParams(name: event.name, password: event.password),
    );
    result.fold(
      (failure) => emit(
        AuthFailure(
          message: failure.message.isNotEmpty
              ? failure.message
              : 'Login failed. Please try again.',
          messageKey: failure.message.isNotEmpty ? null : 'loginFailed',
        ),
      ),
      (user) => emit(AuthSuccess(user: user)),
    );
  }

  Future<void> _onVerifyPhone(
    VerifyPhoneEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    try {
      await verifyPhoneUseCase(
        phoneNumber: event.phoneNumber,
        codeSent: (verificationId, resendToken) {
          add(
            PhoneCodeSentEvent(
              verificationId: verificationId,
              resendToken: resendToken,
            ),
          );
        },
        verificationFailed: (e) {
          add(
            PhoneAuthFailedEvent(
              message: e.message ?? 'Verification failed',
              messageKey: 'verificationFailed',
            ),
          );
        },
      );
    } catch (e) {
      emit(AuthFailure(message: ErrorMessageResolver.resolve(e)));
    }
  }

  void _onPhoneCodeSent(PhoneCodeSentEvent event, Emitter<AuthState> emit) {
    emit(
      PhoneCodeSentState(
        verificationId: event.verificationId,
        resendToken: event.resendToken,
      ),
    );
  }

  void _onPhoneAuthFailed(PhoneAuthFailedEvent event, Emitter<AuthState> emit) {
    emit(AuthFailure(message: event.message, messageKey: event.messageKey));
  }

  Future<void> _onSubmitOtp(
    SubmitOtpEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    final result = await signInWithPhoneUseCase(
      verificationId: event.verificationId,
      smsCode: event.smsCode,
    );
    result.fold(
      (failure) => emit(
        AuthFailure(
          message: failure.message.isNotEmpty
              ? failure.message
              : 'Invalid OTP code',
          messageKey: failure.message.isNotEmpty ? null : 'invalidOtpCode',
        ),
      ),
      (user) => emit(AuthSuccess(user: user)),
    );
  }

  Future<void> _onGoogleLoginRequested(
    GoogleLoginRequestedEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    final result = await signInWithGoogleUseCase();
    result.fold(
      (failure) => emit(AuthFailure(message: failure.message)),
      (user) => emit(AuthSuccess(user: user)),
    );
  }

  Future<void> _onUpdateProfileRequested(
    UpdateProfileRequestedEvent event,
    Emitter<AuthState> emit,
  ) async {
    // Keep AuthSuccess while updating so MainScreen does not treat this as a
    // fresh login (AuthLoading → AuthSuccess) and jump to the Home tab.
    final result = await updateProfileUseCase(event.data);
    result.fold(
      (failure) => emit(
        AuthFailure(
          message: failure.message.isNotEmpty
              ? failure.message
              : 'Failed to update profile',
          messageKey: failure.message.isNotEmpty ? null : 'updateProfileFailed',
        ),
      ),
      (user) => emit(AuthSuccess(user: user)),
    );
  }

  Future<void> _onSignUpWithEmail(
    SignUpWithEmailEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    final result = await signUpWithEmailUseCase(
      SignUpWithEmailParams(
        fullName: event.fullName,
        email: event.email,
        password: event.password,
      ),
    );
    result.fold(
      (failure) => emit(
        AuthFailure(
          message: failure.message.isNotEmpty
              ? failure.message
              : 'Signup failed. Please try again.',
          messageKey: failure.message.isNotEmpty ? null : 'signupFailed',
        ),
      ),
      // Docs flow A: Firebase create + /auth/login → navigate by onboarding flags.
      (user) => emit(AuthSuccess(user: user)),
    );
  }

  Future<void> _onSendEmailOtp(
    SendEmailOtpEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    final result = await sendOtpUseCase(
      SendOtpParams(type: 'EMAIL', email: event.email),
    );
    result.fold(
      (failure) => emit(
        AuthFailure(
          message: failure.message.isNotEmpty
              ? failure.message
              : 'Failed to send OTP',
        ),
      ),
      (_) => emit(EmailOtpSentState(email: event.email)),
    );
  }

  Future<void> _onVerifyEmailOtp(
    VerifyEmailOtpEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    final result = await verifyOtpUseCase(
      VerifyOtpParams(
        type: 'EMAIL',
        email: event.email,
        code: event.otpCode,
      ),
    );
    result.fold(
      (failure) => emit(
        AuthFailure(
          message: failure.message.isNotEmpty
              ? failure.message
              : 'Invalid OTP code',
          messageKey: failure.message.isNotEmpty ? null : 'invalidOtpCode',
        ),
      ),
      (_) => emit(EmailOtpVerifiedState(email: event.email)),
    );
  }

  Future<void> _onResetPassword(
    ResetPasswordRequestedEvent event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    final result = await resetPasswordUseCase(
      ResetPasswordParams(
        type: 'EMAIL',
        email: event.email,
        code: event.code,
        newPassword: event.newPassword,
      ),
    );
    result.fold(
      (failure) => emit(
        AuthFailure(
          message: failure.message.isNotEmpty
              ? failure.message
              : 'Password reset failed',
        ),
      ),
      (_) => emit(const PasswordResetSuccessState()),
    );
  }
}
