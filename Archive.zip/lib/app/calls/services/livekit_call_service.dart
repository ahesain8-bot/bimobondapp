import 'dart:async';

import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:livekit_client/livekit_client.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../core/services/live_audio_session.dart';

class LiveKitCallService {
  Room? _room;
  EventsListener<RoomEvent>? _listener;
  bool _holdsAudioSession = false;

  bool _isMuted = false;
  bool _isCameraOff = false;
  bool _isSpeakerPhoneOn = true;

  final _participantsController =
      StreamController<List<Participant>>.broadcast();
  final _roomStateController = StreamController<ConnectionState>.broadcast();

  Room? get room => _room;
  bool get isMuted => _isMuted;
  bool get isCameraOff => _isCameraOff;
  bool get isSpeakerPhoneOn => _isSpeakerPhoneOn;
  bool get isConnected => _room?.connectionState == ConnectionState.connected;

  Future<void> _acquireAudioSession() async {
    if (_holdsAudioSession) return;
    await LiveAudioSession.instance.acquire();
    _holdsAudioSession = true;
  }

  Future<void> _releaseAudioSession() async {
    if (!_holdsAudioSession) return;
    await LiveAudioSession.instance.release();
    _holdsAudioSession = false;
  }

  Stream<List<Participant>> get onParticipantsChanged =>
      _participantsController.stream;
  Stream<ConnectionState> get onRoomStateChanged =>
      _roomStateController.stream;

  List<Participant> get allParticipants {
    if (_room == null) return [];
    final list = <Participant>[];
    if (_room!.localParticipant != null) {
      list.add(_room!.localParticipant!);
    }
    list.addAll(_room!.remoteParticipants.values);
    return list;
  }

  Future<void> _requestPermissions(bool isVideo) async {
    try {
      final micStatus = await Permission.microphone.request();
      debugPrint('LiveKitCallService: mic permission status = $micStatus');
      if (isVideo) {
        final camStatus = await Permission.camera.request();
        debugPrint('LiveKitCallService: camera permission status = $camStatus');
      }
    } catch (e) {
      debugPrint('LiveKitCallService permission request error: $e');
    }
  }

  Future<void> _configureAudioSession() async {
    try {
      final session = await AudioSession.instance;
      await session.configure(const AudioSessionConfiguration(
        avAudioSessionCategory: AVAudioSessionCategory.playAndRecord,
        avAudioSessionCategoryOptions:
            AVAudioSessionCategoryOptions.defaultToSpeaker,
        avAudioSessionMode: AVAudioSessionMode.voiceChat,
        androidAudioAttributes: AndroidAudioAttributes(
          contentType: AndroidAudioContentType.speech,
          usage: AndroidAudioUsage.voiceCommunication,
        ),
        androidAudioFocusGainType: AndroidAudioFocusGainType.gain,
      ));
      await session.setActive(true);
    } catch (e) {
      debugPrint('LiveKitCallService audio session error: $e');
    }
  }

  Future<void> connect({
    required String url,
    required String token,
    required bool isVideo,
  }) async {
    await disconnect();
    await _requestPermissions(isVideo);
    await _configureAudioSession();

    try {
      await _acquireAudioSession();
      final roomOptions = const RoomOptions(
        defaultAudioPublishOptions: AudioPublishOptions(
          name: 'microphone',
        ),
        defaultVideoPublishOptions: VideoPublishOptions(
          name: 'camera',
          simulcast: true,
        ),
      );

      _room = Room(roomOptions: roomOptions);
      _listener = _room!.createListener();

      _setupListeners();

      await _room!.connect(url, token);
      debugPrint('LiveKitCallService: connected to room ${_room?.name}');

      // Configure media devices safely
      _isMuted = false;
      _isCameraOff = !isVideo;
      _isSpeakerPhoneOn = isVideo;

      // Try enabling microphone; if mic fails or permission denied, continue call with mic muted so audio playback works
      try {
        await _room!.localParticipant?.setMicrophoneEnabled(true);
      } catch (e) {
        debugPrint(
            'LiveKitCallService: microphone enable error (continuing without mic): $e');
        _isMuted = true;
      }

      if (isVideo) {
        try {
          await _room!.localParticipant?.setCameraEnabled(true);
        } catch (e) {
          debugPrint('LiveKitCallService: camera enable error: $e');
          _isCameraOff = true;
        }
      } else {
        await _room!.localParticipant?.setCameraEnabled(false);
      }

      try {
        await AudioManager.instance.setSpeakerOutputPreferred(_isSpeakerPhoneOn);
      } catch (e) {
        debugPrint('LiveKitCallService initial speakerphone set error: $e');
      }

      _updateState();
    } catch (e) {
      debugPrint('LiveKitCallService connection error: $e');
      try {
        await _releaseAudioSession();
      } catch (releaseError, releaseStack) {
        debugPrint(
          'LiveKitCallService audio session release error: '
          '$releaseError\n$releaseStack',
        );
      }
      rethrow;
    }
  }

  void _setupListeners() {
    if (_listener == null) return;

    _listener!
      ..on<RoomConnectedEvent>((_) {
        _roomStateController.add(ConnectionState.connected);
        _updateState();
      })
      ..on<RoomDisconnectedEvent>((_) {
        _roomStateController.add(ConnectionState.disconnected);
        _updateState();
      })
      ..on<RoomReconnectingEvent>((_) {
        _roomStateController.add(ConnectionState.reconnecting);
      })
      ..on<RoomReconnectedEvent>((_) {
        _roomStateController.add(ConnectionState.connected);
        _updateState();
      })
      ..on<ParticipantConnectedEvent>((_) => _updateState())
      ..on<ParticipantDisconnectedEvent>((_) => _updateState())
      ..on<TrackSubscribedEvent>((_) => _updateState())
      ..on<TrackUnsubscribedEvent>((_) => _updateState())
      ..on<TrackMutedEvent>((_) => _updateState())
      ..on<TrackUnmutedEvent>((_) => _updateState());
  }

  void _updateState() {
    _participantsController.add(allParticipants);
  }

  Future<void> toggleMute() async {
    if (_room == null || _room!.localParticipant == null) return;
    final nextMutedState = !_isMuted;
    try {
      if (!nextMutedState) {
        // Request microphone permission when unmuting
        try {
          await Permission.microphone.request();
        } catch (e) {
          debugPrint('LiveKitCallService mic permission request error: $e');
        }
      }
      await _room!.localParticipant?.setMicrophoneEnabled(!nextMutedState);
      _isMuted = nextMutedState;
    } catch (e) {
      debugPrint('LiveKitCallService toggleMute error: $e');
      _isMuted = true; // Fallback to muted if microphone operation fails
    }
    _updateState();
  }

  Future<void> toggleCamera() async {
    if (_room == null || _room!.localParticipant == null) return;
    _isCameraOff = !_isCameraOff;
    if (!_isCameraOff) {
      try {
        await Permission.camera.request();
      } catch (e) {
        debugPrint('LiveKitCallService camera request error: $e');
      }
      try {
        await _room!.localParticipant?.setMicrophoneEnabled(!_isMuted);
      } catch (_) {}
    }
    try {
      await _room!.localParticipant?.setCameraEnabled(!_isCameraOff);
    } catch (e) {
      debugPrint('LiveKitCallService setCameraEnabled error: $e');
      _isCameraOff = true;
    }
    _updateState();
  }

  bool _isFrontCamera = true;

  Future<void> switchCamera() async {
    if (_room == null || _room!.localParticipant == null) return;
    final track =
        _room!.localParticipant?.videoTrackPublications.firstOrNull?.track;
    if (track is LocalVideoTrack) {
      _isFrontCamera = !_isFrontCamera;
      final newPosition =
          _isFrontCamera ? CameraPosition.front : CameraPosition.back;
      await track.setCameraPosition(newPosition);
    }
  }

  Future<void> toggleSpeaker() async {
    _isSpeakerPhoneOn = !_isSpeakerPhoneOn;
    try {
      await AudioManager.instance.setSpeakerOutputPreferred(_isSpeakerPhoneOn);
    } catch (e) {
      debugPrint('LiveKitCallService toggleSpeaker error: $e');
    }
    _updateState();
  }

  Future<void> disconnect() async {
    try {
      _listener?.dispose();
      _listener = null;
      await _releaseAudioSession();
      if (_room != null) {
        await _room!.disconnect();
        await _room!.dispose();
        _room = null;
      }
    } catch (e) {
      debugPrint('LiveKitCallService disconnect error: $e');
    }
  }

  void dispose() {
    disconnect();
    _participantsController.close();
    _roomStateController.close();
  }
}
