// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appTitle => 'تطبيق بيموبوند';

  @override
  String get helloWorld => 'مرحبا بالعالم!';

  @override
  String get loginTitle => 'تسجيل الدخول';

  @override
  String get loginScreenTitle => 'تسجيل الدخول إلى بيموبوند';

  @override
  String get loginWithPhone => 'استخدام رقم الجوال';

  @override
  String get loginWithEmailUsername => 'استخدام البريد الالكتروني';

  @override
  String get loginEmailUsernameHint => 'البريد الإلكتروني أو اسم المستخدم';

  @override
  String get continueWithGoogle => 'المتابعة باستخدام Google';

  @override
  String get continueWithApple => 'المتابعة باستخدام Apple';

  @override
  String get signInSubtitle => 'تسجيل الدخول للمتابعة';

  @override
  String get emailLabel => 'البريد الإلكتروني';

  @override
  String get passwordLabel => 'كلمة المرور';

  @override
  String get loginButton => 'تسجيل الدخول';

  @override
  String get dontHaveAccount => 'ليس لديك حساب؟ ';

  @override
  String get signUp => 'إنشاء حساب';

  @override
  String get orDivider => 'أو';

  @override
  String get continueAsGuest => 'الدخول كضيف';

  @override
  String get continueWith => 'المتابعة باستخدام';

  @override
  String get notificationErrorTitle => 'خطأ';

  @override
  String get notificationSuccessTitle => 'نجاح';

  @override
  String get signUpTitle => 'إنشاء حساب';

  @override
  String get signUpScreenTitle => 'إنشاء حساب في بيموبوند';

  @override
  String get signUpSubtitle => 'أدخل بياناتك لإنشاء حساب جديد';

  @override
  String get fullNameLabel => 'الاسم الكامل';

  @override
  String get usernameLabel => 'اسم المستخدم';

  @override
  String get countryLabel => 'الدولة';

  @override
  String get nationalityLabel => 'الجنسية';

  @override
  String get ageLabel => 'العمر';

  @override
  String get addressLabel => 'العنوان';

  @override
  String get phoneLabel => 'رقم الجوال';

  @override
  String get mobileNumberLabel => 'رقم الجوال';

  @override
  String get confirmPasswordLabel => 'تأكيد كلمة المرور';

  @override
  String get createAccountBtn => 'إنشاء الحساب';

  @override
  String get alreadyHaveAccount => 'لديك حساب؟ ';

  @override
  String get phoneLoginTitle => 'الدخول برقم الجوال';

  @override
  String get phoneLoginSubtitle => 'أدخل رقم جوالك لتلقي رمز التحقق';

  @override
  String get phoneLoginUsageNote => 'قد يُستخدم رقم جوالك للتواصل مع أشخاص قد تعرفهم وتحسين الإعلانات والمزيد حسب إعداداتك.';

  @override
  String get emailLoginUsageNote => 'قد يُستخدم بريدك الإلكتروني للتواصل مع أشخاص قد تعرفهم وتحسين الإعلانات والمزيد حسب إعداداتك.';

  @override
  String get phoneHint => '+20 123 456 7890';

  @override
  String get termsAndConditionsPart1 => 'بالاستمرار، أنت توافق على ';

  @override
  String get termsAndConditionsPart2 => 'الشروط والأحكام';

  @override
  String get loginLegalNotePart1 => 'بالمتابعة، أنت توافق على ';

  @override
  String get loginTermsOfService => 'شروط الخدمة';

  @override
  String get loginLegalNotePart2 => ' وتؤكد أنك قرأت ';

  @override
  String get loginPrivacyPolicy => 'سياسة الخصوصية';

  @override
  String get verifyPhoneTitle => 'التحقق من الجوال';

  @override
  String get emailVerificationTitle => 'تحقق من بريدك الإلكتروني';

  @override
  String emailVerificationSent(Object email) {
    return 'أرسلنا رابط التحقق إلى $email.';
  }

  @override
  String get emailVerificationContinue => 'افتح بريدك الإلكتروني وتحقق من حسابك قبل المتابعة.';

  @override
  String get emailVerificationButton => 'لقد قمت بالتحقق من بريدي الإلكتروني';

  @override
  String get emailVerificationResendError => 'يتعذر إعادة إرسال بريد التحقق. يرجى تسجيل الدخول مرة أخرى.';

  @override
  String get emailVerificationResendSuccess => 'تمت إعادة إرسال بريد التحقق. تحقق من صندوق الوارد ومجلد البريد العشوائي.';

  @override
  String get emailVerificationResendFailed => 'فشل إعادة إرسال بريد التحقق. يرجى المحاولة مرة أخرى.';

  @override
  String get emailVerificationStatusError => 'يتعذر التحقق من حالة البريد الإلكتروني. يرجى تسجيل الدخول مرة أخرى.';

  @override
  String get emailVerificationNotVerified => 'لم يتم التحقق من البريد الإلكتروني بعد. يرجى فتح بريدك الإلكتروني والتحقق من حسابك.';

  @override
  String get emailVerificationCheckFailed => 'تعذّر التحقق من حالة البريد الإلكتروني. يرجى المحاولة مرة أخرى.';

  @override
  String get emailVerificationResendButton => 'إعادة إرسال بريد التحقق';

  @override
  String get emailVerificationResending => 'جارٍ إعادة الإرسال...';

  @override
  String get enterCodeSentTo => 'أدخل الرمز المكون من 6 أرقام المرسل إلى';

  @override
  String get verificationCodeLabel => 'رمز التحقق';

  @override
  String get verifyAndLoginBtn => 'التحقق والدخول';

  @override
  String get didNotReceiveCode => 'لم يصلك الرمز؟ ';

  @override
  String get resendCode => 'إعادة إرسال';

  @override
  String resendCodeIn(int seconds) {
    return 'إعادة الإرسال خلال $secondsث';
  }

  @override
  String get back => 'رجوع';

  @override
  String get continueAction => 'متابعة';

  @override
  String get emailRequired => 'البريد الإلكتروني مطلوب';

  @override
  String get invalidEmail => 'أدخل بريد إلكتروني صحيح';

  @override
  String get passwordRequired => 'كلمة المرور مطلوبة';

  @override
  String get passwordTooShort => 'يجب أن تكون كلمة المرور 6 أحرف على الأقل';

  @override
  String get passwordSignUpTooShort => 'يجب أن تكون كلمة المرور 8 أحرف على الأقل';

  @override
  String get passwordTooLong => 'يجب ألا تتجاوز كلمة المرور 20 حرفاً';

  @override
  String get passwordsDoNotMatch => 'كلمتا المرور غير متطابقتين';

  @override
  String get forgotPassword => 'نسيت كلمة المرور؟';

  @override
  String get forgotPasswordTitle => 'نسيت كلمة المرور';

  @override
  String get forgotPasswordSubtitle => 'أدخل بريدك الإلكتروني وسنرسل لك رمزًا مكونًا من 6 أرقام لإعادة تعيين كلمة المرور.';

  @override
  String get forgotPasswordButton => 'إرسال رمز إعادة التعيين';

  @override
  String get forgotPasswordSuccess => 'إذا كان هناك حساب بهذا البريد، تم إرسال رمز إعادة التعيين.';

  @override
  String get forgotPasswordFailed => 'فشل إرسال رمز إعادة التعيين. يرجى المحاولة مرة أخرى.';

  @override
  String get forgotPasswordUserNotFound => 'لا يوجد حساب مرتبط بهذا البريد الإلكتروني.';

  @override
  String get resetPasswordTitle => 'إعادة تعيين كلمة المرور';

  @override
  String get resetPasswordSubtitle => 'أدخل الرمز المكون من 6 أرقام المرسل إلى';

  @override
  String get resetPasswordButton => 'إعادة تعيين كلمة المرور';

  @override
  String get resetPasswordSuccess => 'تمت إعادة تعيين كلمة المرور بنجاح. يرجى تسجيل الدخول.';

  @override
  String get newPasswordLabel => 'كلمة المرور الجديدة';

  @override
  String get otpSentSuccess => 'تم إرسال رمز التحقق.';

  @override
  String get otpVerifiedSuccess => 'تم التحقق من البريد الإلكتروني بنجاح.';

  @override
  String get loginFailed => 'فشل تسجيل الدخول. يرجى المحاولة مرة أخرى.';

  @override
  String get verificationFailed => 'فشل التحقق';

  @override
  String get invalidOtpCode => 'رمز OTP غير صحيح';

  @override
  String get googleLoginFailed => 'فشل تسجيل الدخول عبر جوجل';

  @override
  String get googleLoginSheetTitle => 'تسجيل الدخول عبر جوجل';

  @override
  String get googleLoginSheetSubtitle => 'استخدم حساب جوجل لتسجيل الدخول بسرعة وأمان.';

  @override
  String get googleLoginContinue => 'المتابعة عبر جوجل';

  @override
  String get updateProfileFailed => 'فشل تحديث الملف الشخصي';

  @override
  String get signupFailed => 'فشل إنشاء الحساب. يرجى المحاولة مرة أخرى.';

  @override
  String get profileUpdatedSuccessfully => 'تم تحديث الملف الشخصي بنجاح!';

  @override
  String get enterSixDigitCode => 'يرجى إدخال رمز مكون من 6 أرقام';

  @override
  String get postAdded => 'تم إضافة المنشور!';

  @override
  String get addPost => 'إضافة منشور';

  @override
  String get postButton => 'نشر';

  @override
  String get loginSuccess => 'تم تسجيل الدخول بنجاح!';

  @override
  String get signupSuccess => 'تم التسجيل بنجاح! يرجى التحقق من بريدك الإلكتروني لتفعيل حسابك.';

  @override
  String get signUpWithEmailPassword => 'إنشاء حساب بالبريد الإلكتروني وكلمة المرور';

  @override
  String get signUpEmailStepTitle => 'ما هو بريدك الإلكتروني؟';

  @override
  String get signUpNameStepTitle => 'ما هو اسمك؟';

  @override
  String get signUpPasswordStepTitle => 'أنشئ كلمة مرور';

  @override
  String get nextAction => 'التالي';

  @override
  String get passwordStrengthLabel => 'قوة كلمة المرور';

  @override
  String get passwordStrengthWeak => 'ضعيفة';

  @override
  String get passwordStrengthFair => 'متوسطة';

  @override
  String get passwordStrengthGood => 'جيدة';

  @override
  String get passwordStrengthStrong => 'قوية';

  @override
  String get passwordStrengthHint => 'يجب أن تتكون كلمة المرور من 8 إلى 20 حرفاً وتتضمن مزيجاً من الأحرف والأرقام والرموز.';

  @override
  String get passwordReqLength => 'من 8 إلى 20 حرفاً';

  @override
  String get passwordReqLetter => 'حرف واحد';

  @override
  String get passwordReqNumber => 'رقم واحد';

  @override
  String get passwordReqSpecialChar => 'رمز خاص واحد (مثل ! @ # \$ % & *)';

  @override
  String get passwordRequirementsNotMet => 'يجب أن تستوفي كلمة المرور جميع المتطلبات';

  @override
  String get following => 'متابعة';

  @override
  String get followers => 'متابعون';

  @override
  String get connectionsTitle => 'العلاقات';

  @override
  String get connectionsEmptyFollowers => 'لا يوجد متابعون بعد';

  @override
  String get connectionsEmptyFollowing => 'لا تتابع أحداً بعد';

  @override
  String get connectionsEmptyFriends => 'لا يوجد أصدقاء بعد';

  @override
  String get connectionsFollowBack => 'رد المتابعة';

  @override
  String get profileMessageButton => 'رسالة';

  @override
  String get likes => 'إعجابات';

  @override
  String get profilePostsTab => 'المنشورات';

  @override
  String get profilePostAuction => 'مزاد';

  @override
  String get profileLikesTab => 'الإعجابات';

  @override
  String get noPostsYet => 'لا توجد منشورات بعد';

  @override
  String get noLikedPosts => 'لا توجد منشورات معجب بها';

  @override
  String get noSavedPosts => 'لا توجد منشورات محفوظة';

  @override
  String get noRepostedPosts => 'لا توجد إعادات نشر بعد';

  @override
  String get noOnlyMePosts => 'لا توجد منشورات خاصة بك فقط';

  @override
  String get repostTitle => 'إعادة النشر';

  @override
  String get repostSubtitle => 'شارك هذا المنشور على ملفك الشخصي';

  @override
  String get repostAction => 'إعادة النشر';

  @override
  String get repostUndo => 'تراجع عن إعادة النشر';

  @override
  String get savePost => 'حفظ المنشور';

  @override
  String get unsavePost => 'إزالة من المحفوظات';

  @override
  String get repostQuoteHint => 'أضف تعليقاً (اختياري)';

  @override
  String get repostComposeTitle => 'أضف إلى إعادة النشر';

  @override
  String get repostComposeHint => 'قل شيئاً...';

  @override
  String get repostComposeAdd => 'إضافة';

  @override
  String get postRepostersHeader => 'إعادات النشر';

  @override
  String get repostSuccess => 'تمت إعادة النشر';

  @override
  String get repostRemoved => 'تم إلغاء إعادة النشر';

  @override
  String get cannotRepostOwnPost => 'لا يمكنك إعادة نشر منشورك';

  @override
  String repostCountLabel(int count) {
    return '$count إعادة نشر';
  }

  @override
  String repostedByUser(Object name) {
    return 'أعاد $name النشر';
  }

  @override
  String postRepostersTitle(int count) {
    return 'إعادات النشر · $count';
  }

  @override
  String get postRepostersEmpty => 'لا توجد إعادات نشر بعد';

  @override
  String get profileRepostsTab => 'إعادات النشر';

  @override
  String get editProfile => 'تعديل الملف الشخصي';

  @override
  String get noBio => 'لا يوجد نبذة شخصية بعد.';

  @override
  String get profileAvatarViewPhoto => 'فتح صورة الملف الشخصي';

  @override
  String get profileAvatarViewStory => 'عرض القصة';

  @override
  String get profileAvatarNoPhoto => 'لا توجد صورة للملف الشخصي';

  @override
  String get story => 'قصة';

  @override
  String get addStoryTitle => 'إضافة قصة';

  @override
  String get shareStoryButton => 'نشر القصة';

  @override
  String get storyAddText => 'نص';

  @override
  String get storyTextDone => 'تم';

  @override
  String get storyCaptionHint => 'أضف تعليقاً (اختياري)';

  @override
  String get storyLoadMore => 'عرض المزيد';

  @override
  String get storyShowLess => 'عرض أقل';

  @override
  String storyPickMediaError(String error) {
    return 'تعذر اختيار الوسائط: $error';
  }

  @override
  String get storyExpired => 'انتهت القصة';

  @override
  String storyTimeMinutesAgo(int count) {
    return 'منذ $count د';
  }

  @override
  String storyTimeHoursAgo(int count) {
    return 'منذ $count س';
  }

  @override
  String storyTimeDaysAgo(int count) {
    return 'منذ $count ي';
  }

  @override
  String get storyAddCommentHint => 'أضف تعليقاً...';

  @override
  String get storySendMessageHint => 'اكتب رسالة...';

  @override
  String get storySendMessageTitle => 'الرد برسالة';

  @override
  String get storyViewersTitle => 'المشاهدون';

  @override
  String get storyViewerUnknown => 'مشاهد';

  @override
  String get storyMessagesTitle => 'رسائل على هذه القصة';

  @override
  String get storyMessagesEmpty => 'لا رسائل على هذه القصة بعد';

  @override
  String get storyMessageSendFailed => 'تعذر إرسال الرسالة. حاول مرة أخرى.';

  @override
  String storyMessageSent(String name) {
    return 'تم إرسال الرسالة إلى $name';
  }

  @override
  String get storyPreviewLabel => 'قصة';

  @override
  String get postPreviewLabel => 'منشور';

  @override
  String get storyMessageOnStory => 'رد على قصتك';

  @override
  String get storyMessageOnPost => 'رد على منشورك';

  @override
  String get personalInfo => 'المعلومات الشخصية';

  @override
  String get genderLabel => 'الجنس';

  @override
  String get male => 'ذكر';

  @override
  String get female => 'أنثى';

  @override
  String get selectCountry => 'اختر الدولة';

  @override
  String get changeProfilePhoto => 'تغيير صورة الملف الشخصي';

  @override
  String get takePhoto => 'التقاط صورة';

  @override
  String get importFromLibrary => 'استيراد';

  @override
  String get uploadFromLibrary => 'رفع من المكتبة';

  @override
  String get removeCurrentPhoto => 'إزالة الصورة الحالية';

  @override
  String get changePhoto => 'تغيير الصورة';

  @override
  String get enterYourName => 'أدخل اسمك';

  @override
  String get enterUsername => 'أدخل اسم المستخدم';

  @override
  String get addBioToProfile => 'أضف نبذة شخصية لملفك';

  @override
  String get selectGender => 'اختر الجنس';

  @override
  String get instagramProfileUrl => 'اسم المستخدم أو الرابط';

  @override
  String get youtubeChannelUrl => 'اسم المستخدم أو رابط القناة';

  @override
  String get egypt => 'مصر';

  @override
  String get saudiArabia => 'السعودية';

  @override
  String get uae => 'الإمارات';

  @override
  String get usa => 'أمريكا';

  @override
  String get uk => 'بريطانيا';

  @override
  String get kuwait => 'الكويت';

  @override
  String get qatar => 'قطر';

  @override
  String get bioLabel => 'نبذة شخصية';

  @override
  String get instagramLabel => 'إنستجرام';

  @override
  String get youtubeLabel => 'يوتيوب';

  @override
  String fieldIsRequired(String field) {
    return '$field مطلوب';
  }

  @override
  String get edit => 'تعديل';

  @override
  String get feedFollowingTab => 'المتابَعون';

  @override
  String get feedForYou => 'لك';

  @override
  String get feedLive => 'مباشر';

  @override
  String get feedShop => 'المتجر';

  @override
  String get shopTitle => 'المتجر';

  @override
  String get shopFeatured => 'مميز';

  @override
  String get shopFlashDeals => 'عروض سريعة';

  @override
  String get shopForYou => 'لك';

  @override
  String get shopCart => 'السلة';

  @override
  String get shopCheckout => 'الدفع';

  @override
  String get shopOrders => 'الطلبات';

  @override
  String get shopBuyNow => 'اشتري الآن';

  @override
  String get shopAddToCart => 'أضف للسلة';

  @override
  String get shopEmpty => 'لا توجد منتجات';

  @override
  String get shopRetry => 'إعادة المحاولة';

  @override
  String get shopAllCategories => 'الكل';

  @override
  String get shopProducts => 'المنتجات';

  @override
  String get shopNoProductsYet => 'لا توجد منتجات بعد';

  @override
  String get shopEmptyHint => 'جرّب فئة أو كلمة بحث مختلفة.';

  @override
  String get shopSeeAll => 'عرض الكل';

  @override
  String get shopSearchHint => 'ابحث عن منتجات...';

  @override
  String get shopSearchForProducts => 'ابحث عن منتجات';

  @override
  String get shopRecentSearches => 'الأخيرة';

  @override
  String shopNoResultsFor(String query) {
    return 'لا نتائج لـ \"$query\"';
  }

  @override
  String get shopSort => 'الترتيب';

  @override
  String get shopSortNewest => 'الأحدث';

  @override
  String get shopSortOldest => 'الأقدم';

  @override
  String get shopSortPriceLow => 'السعر: من الأقل';

  @override
  String get shopSortPriceHigh => 'السعر: من الأعلى';

  @override
  String get shopSortTitleAsc => 'العنوان أ-ي';

  @override
  String get shopSortTitleDesc => 'العنوان ي-أ';

  @override
  String get shopCartEmpty => 'سلتك فارغة';

  @override
  String get shopSubtotal => 'المجموع الفرعي';

  @override
  String get shopCommission => 'العمولة';

  @override
  String get shopCheckoutAction => 'إتمام الشراء';

  @override
  String get shopShippingDetails => 'تفاصيل الشحن';

  @override
  String get shopPayWithCoins => 'الدفع بالعملات';

  @override
  String get shopFirstName => 'الاسم الأول';

  @override
  String get shopFirstNameHint => 'أدخل اسمك الأول';

  @override
  String get shopLastName => 'اسم العائلة';

  @override
  String get shopLastNameHint => 'أدخل اسم العائلة';

  @override
  String get shopStreet => 'الشارع';

  @override
  String get shopStreetHint => 'أدخل اسم الشارع';

  @override
  String get shopStreetNo => 'رقم الشارع';

  @override
  String get shopStreetNoHint => 'الرقم';

  @override
  String get shopApartmentNo => 'رقم الشقة';

  @override
  String get shopApartmentNoHint => 'الشقة';

  @override
  String get shopCity => 'المدينة';

  @override
  String get shopCityHint => 'أدخل مدينتك';

  @override
  String get shopPostcode => 'الرمز البريدي';

  @override
  String get shopPostcodeHint => 'أدخل الرمز البريدي';

  @override
  String get shopCountry => 'الدولة';

  @override
  String get shopCountryHint => 'أدخل دولتك';

  @override
  String get shopPhone => 'الهاتف';

  @override
  String get shopPhoneHint => 'أدخل رقم هاتفك';

  @override
  String get shopFieldRequired => 'مطلوب';

  @override
  String get shopYourBalance => 'رصيدك';

  @override
  String get shopDueNow => 'المستحق الآن';

  @override
  String get shopBuyCoins => 'شراء عملات';

  @override
  String shopPayCoinsAmount(int count) {
    return 'ادفع $count عملة';
  }

  @override
  String shopNeedMoreCoins(int count) {
    return 'تحتاج إلى $count عملة إضافية.';
  }

  @override
  String get shopNotEnoughCoins => 'رصيد العملات غير كافٍ. اشترِ المزيد للمتابعة.';

  @override
  String shopCoinsLabel(int count) {
    return '$count عملة';
  }

  @override
  String get shopProductNotFound => 'المنتج غير موجود';

  @override
  String get shopAddFavorite => 'إضافة إلى المفضلة';

  @override
  String get shopRemoveFavorite => 'إزالة من المفضلة';

  @override
  String get shopShare => 'مشاركة';

  @override
  String get shopReadMore => 'اقرأ المزيد';

  @override
  String get shopShowLess => 'عرض أقل';

  @override
  String get shopVariants => 'الخيارات';

  @override
  String get shopQuantity => 'الكمية';

  @override
  String get shopOutOfStock => 'غير متوفر';

  @override
  String get shopSelectVariantFirst => 'اختر خيارًا أولاً';

  @override
  String get shopAddedToCart => 'تمت الإضافة إلى السلة';

  @override
  String get shopLiveBadge => 'مباشر';

  @override
  String get shopBestPrice => 'أفضل سعر';

  @override
  String get shopPurchases => 'مشترياتي';

  @override
  String get shopSales => 'المبيعات';

  @override
  String get shopNoPurchasesYet => 'لا توجد مشتريات بعد';

  @override
  String get shopNoSalesYet => 'لا توجد مبيعات بعد';

  @override
  String get shopStatusPending => 'قيد الانتظار';

  @override
  String get shopStatusPaid => 'مدفوع';

  @override
  String get shopStatusCancelled => 'ملغى';

  @override
  String get shopStatusRefunded => 'مسترد';

  @override
  String get shopStatusUnknown => 'غير معروف';

  @override
  String get shopFulfillmentNone => 'لم يبدأ';

  @override
  String get shopFulfillmentAwaitingShipment => 'بانتظار الشحن';

  @override
  String get shopFulfillmentShipped => 'تم الشحن';

  @override
  String get shopFulfillmentDelivered => 'تم التسليم';

  @override
  String get shopFulfillmentAccepted => 'مقبول';

  @override
  String get shopFulfillmentDisputed => 'نزاع';

  @override
  String get shopStatus => 'الحالة';

  @override
  String get shopFulfillment => 'التنفيذ';

  @override
  String get shopTracking => 'التتبع';

  @override
  String get shopItems => 'العناصر';

  @override
  String shopQty(int count) {
    return 'الكمية: $count';
  }

  @override
  String get shopTotalPaid => 'الإجمالي المدفوع';

  @override
  String get shopShipping => 'الشحن';

  @override
  String get shopShip => 'شحن';

  @override
  String get shopShipOrder => 'شحن الطلب';

  @override
  String get shopTrackingNumber => 'رقم التتبع';

  @override
  String get shopShippingNote => 'ملاحظة الشحن';

  @override
  String get shopReceive => 'استلام';

  @override
  String get shopAccept => 'قبول';

  @override
  String get shopDispute => 'نزاع';

  @override
  String get shopDisputeOrder => 'فتح نزاع';

  @override
  String get shopNoteOptional => 'ملاحظة (اختياري)';

  @override
  String get shopCancel => 'إلغاء';

  @override
  String get shopLiveAddProduct => 'إضافة منتج';

  @override
  String get shopLiveNoProductsToAdd => 'لا توجد منتجات لإضافتها';

  @override
  String get shopLiveEmptyHost => 'لا منتجات بعد — اضغط إضافة منتج';

  @override
  String get shopLiveEmptyViewer => 'لا توجد منتجات في هذا البث بعد';

  @override
  String get shopPinned => 'مثبّت';

  @override
  String get shopPin => 'تثبيت';

  @override
  String get shopUnpin => 'إلغاء التثبيت';

  @override
  String get shopRemove => 'إزالة';

  @override
  String get shopBuy => 'شراء';

  @override
  String shopItemsCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count عناصر',
      one: 'عنصر واحد',
    );
    return '$_temp0';
  }

  @override
  String get noPostsFound => 'لا توجد منشورات';

  @override
  String get navHome => 'الرئيسية';

  @override
  String get pressBackAgainToExit => 'اضغط رجوع مرة أخرى للخروج';

  @override
  String get navFriends => 'الأصدقاء';

  @override
  String get navAuctions => 'مزادات';

  @override
  String get auctionsSearchHint => 'ابحث في المزادات...';

  @override
  String get postsSearchTitle => 'بحث المنشورات';

  @override
  String get postsSearchHint => 'ابحث في المنشورات...';

  @override
  String get searchAction => 'بحث';

  @override
  String get searchHistorySeeMore => 'عرض المزيد';

  @override
  String get searchHistorySeeLess => 'عرض أقل';

  @override
  String get searchHistoryClear => 'مسح';

  @override
  String get searchHistoryEmpty => 'لا توجد عمليات بحث حديثة';

  @override
  String get searchSeeAll => 'عرض الكل';

  @override
  String get searchSeeLess => 'عرض أقل';

  @override
  String get searchYouMayLike => 'قد يعجبك';

  @override
  String get searchNoResults => 'لا توجد منشورات';

  @override
  String get searchTabTop => 'الأعلى';

  @override
  String get searchTabUsers => 'المستخدمون';

  @override
  String get searchTabVideos => 'الفيديوهات';

  @override
  String get searchTabLive => 'مباشر';

  @override
  String get searchTabSounds => 'الأصوات';

  @override
  String get searchTabPlaces => 'الأماكن';

  @override
  String get searchComingSoon => 'قريبًا';

  @override
  String get auctionsFiltersTitle => 'تصفية';

  @override
  String get auctionsFiltersApply => 'تطبيق التصفية';

  @override
  String get auctionsFiltersReset => 'إعادة تعيين';

  @override
  String get auctionsFiltersCategories => 'الفئات';

  @override
  String get auctionsFiltersPriceRange => 'نطاق السعر (دولار)';

  @override
  String get auctionsFiltersMinPrice => 'أقل سعر';

  @override
  String get auctionsFiltersMaxPrice => 'أعلى سعر';

  @override
  String get auctionsFiltersLiveStatus => 'حالة المزاد';

  @override
  String get auctionsFilterLive => 'مباشر';

  @override
  String get auctionsFilterEnded => 'منتهي';

  @override
  String get endedAuctionsNow => 'مزادات منتهية';

  @override
  String get auctionsFiltersTimeRemaining => 'الوقت المتبقي';

  @override
  String get auctionsFiltersInvalidPriceRange => 'لا يمكن أن يكون أقل سعر أكبر من أعلى سعر';

  @override
  String get auctionsTimeRemainingAny => 'أي وقت';

  @override
  String get auctionsTimeRemaining1Hour => 'ينتهي خلال ساعة';

  @override
  String get auctionsTimeRemaining6Hours => 'ينتهي خلال 6 ساعات';

  @override
  String get auctionsTimeRemaining24Hours => 'ينتهي خلال 24 ساعة';

  @override
  String get auctionsTimeRemaining7Days => 'ينتهي خلال 7 أيام';

  @override
  String get auctionsTimeRemaining30Days => 'ينتهي خلال 30 يوماً';

  @override
  String get popularCategories => 'الفئات الرائجة';

  @override
  String get viewAll => 'عرض الكل';

  @override
  String get auctionCategoryWatches => 'ساعات فاخرة';

  @override
  String get auctionCategoryCars => 'سيارات رياضية';

  @override
  String get auctionCategoryArt => 'فنون نادرة';

  @override
  String get auctionCategoryJewelry => 'مجوهرات';

  @override
  String get auctionCategoryAll => 'الكل';

  @override
  String get activeAuctionsNow => 'مزادات نشطة الآن';

  @override
  String get liveBadge => 'مباشر';

  @override
  String get auctionActiveBadge => 'نشط';

  @override
  String get auctionTapToEnter => 'اضغط للدخول';

  @override
  String get auctionFinishedBadge => 'انتهى';

  @override
  String get auctionCancelAction => 'إلغاء المزاد';

  @override
  String get auctionCancelTitle => 'إلغاء هذا المزاد؟';

  @override
  String get auctionCancelMessage => 'قد يتم استرداد مساهمات الهدايا إذا كان الضمان مفعّلاً. لا يمكن التراجع عن هذا الإجراء.';

  @override
  String get auctionCancelSuccess => 'تم إلغاء المزاد';

  @override
  String get auctionSellerRequiredTitle => 'يلزم توثيق البائع';

  @override
  String get auctionSellerRequiredMessage => 'أكمل توثيق البائع قبل استضافة المزادات.';

  @override
  String get auctionSellerPendingMessage => 'توثيق البائع قيد المراجعة.';

  @override
  String get auctionSellerRejectedMessage => 'تم رفض توثيق البائع. يرجى إعادة الإرسال.';

  @override
  String get auctionSellerCompleteAction => 'إكمال التوثيق';

  @override
  String get sellerVerificationTitle => 'توثيق البائع';

  @override
  String get sellerVerificationSubtitle => 'ارفع جواز سفرك وبيانات العنوان لاستضافة المزادات.';

  @override
  String get sellerVerificationSubtitleSimple => 'أدخل رقم الهوية وارفع صورة جواز السفر.';

  @override
  String get sellerVerificationIdentitySection => 'الهوية';

  @override
  String get sellerVerificationPassportSection => 'جواز السفر';

  @override
  String get sellerVerificationContactSection => 'التواصل والعنوان';

  @override
  String get sellerVerificationFullLegalName => 'الاسم القانوني الكامل';

  @override
  String get sellerVerificationDateOfBirth => 'تاريخ الميلاد';

  @override
  String get sellerVerificationNationality => 'الجنسية';

  @override
  String get sellerVerificationNationalId => 'رقم الهوية';

  @override
  String get sellerVerificationNationalIdOptional => 'الرقم الوطني (اختياري)';

  @override
  String get sellerVerificationNationalIdRequired => 'رقم الهوية مطلوب';

  @override
  String get sellerVerificationPassportNumber => 'رقم جواز السفر';

  @override
  String get sellerVerificationPassportCountry => 'بلد جواز السفر';

  @override
  String get sellerVerificationPassportExpiry => 'تاريخ انتهاء الجواز';

  @override
  String get sellerVerificationPassportFront => 'صورة وجه جواز السفر';

  @override
  String get sellerVerificationPassportPhoto => 'صورة جواز السفر';

  @override
  String get sellerVerificationPassportBackOptional => 'ظهر الجواز (اختياري)';

  @override
  String get sellerVerificationSelfieOptional => 'صورة شخصية (اختياري)';

  @override
  String get sellerVerificationContactPhone => 'رقم الهاتف';

  @override
  String get sellerVerificationAddressLine1 => 'العنوان سطر 1';

  @override
  String get sellerVerificationAddressLine2Optional => 'العنوان سطر 2 (اختياري)';

  @override
  String get sellerVerificationCity => 'المدينة';

  @override
  String get sellerVerificationRegionOptional => 'المنطقة / المحافظة (اختياري)';

  @override
  String get sellerVerificationCountry => 'الدولة';

  @override
  String get sellerVerificationPostalOptional => 'الرمز البريدي (اختياري)';

  @override
  String get sellerVerificationPickDate => 'اختر التاريخ';

  @override
  String get sellerVerificationTapToUpload => 'اضغط للرفع';

  @override
  String get sellerVerificationUploading => 'جاري الرفع…';

  @override
  String get sellerVerificationUploaded => 'تم الرفع';

  @override
  String get sellerVerificationSubmit => 'إرسال للمراجعة';

  @override
  String get sellerVerificationSubmitted => 'تم إرسال التوثيق. سنراجعه قريبًا.';

  @override
  String get sellerVerificationDobRequired => 'تاريخ الميلاد مطلوب';

  @override
  String get sellerVerificationExpiryRequired => 'تاريخ انتهاء الجواز مطلوب';

  @override
  String get sellerVerificationExpiryFuture => 'يجب ألا يكون جواز السفر منتهيًا';

  @override
  String get sellerVerificationPassportFrontRequired => 'صورة جواز السفر مطلوبة';

  @override
  String get auctionTimeLeft => 'الوقت المتبقي';

  @override
  String get auctionStartsIn => 'يبدأ خلال';

  @override
  String auctionAddedBy(String username) {
    return 'أضافه $username';
  }

  @override
  String auctionCountdownDayCount(int days) {
    return '$days يوم';
  }

  @override
  String get auctionTimerHour => 'س';

  @override
  String get auctionTimerMinute => 'د';

  @override
  String get auctionTimerSecond => 'ث';

  @override
  String auctionCountdownWithDays(int days, String time) {
    return '$days يوم $time';
  }

  @override
  String get auctionTargetReachedMessage => 'تم الوصول للسعر المستهدف. انتهى المزاد.';

  @override
  String get auctionBiddingClosed => 'المزايدة مغلقة';

  @override
  String auctionTargetPrice(String amount, String currency) {
    return 'الهدف $amount $currency';
  }

  @override
  String get liveStreamsTitle => 'بث مباشر';

  @override
  String get searchLiveStreamsHint => 'ابحث عن بث...';

  @override
  String get liveFilterAll => 'الكل';

  @override
  String get liveFilterRealEstate => 'عقارات';

  @override
  String get liveFilterAuctions => 'مزادات';

  @override
  String get liveFilterTrending => 'رائج';

  @override
  String get liveFilterInvestments => 'استثمارات';

  @override
  String get liveStreamTitle1 => 'استثمار عقاري مباشر';

  @override
  String get liveStreamTitle2 => 'عرض مزادات فاخرة';

  @override
  String get liveStreamTitle3 => 'نصائح استثمارية مباشرة';

  @override
  String liveHostName(int number) {
    return 'مضيف $number';
  }

  @override
  String liveViewersCount(int count) {
    return '$count';
  }

  @override
  String get joinLiveStream => 'انضم للبث';

  @override
  String get liveDetailsTitle => 'بث مباشر';

  @override
  String get liveFollow => 'متابعة';

  @override
  String get liveFollowing => 'متابع';

  @override
  String liveViewersShort(String count) {
    return '$count مشاهد';
  }

  @override
  String get liveTopBid => 'أعلى سعر';

  @override
  String get liveTargetPrice => 'السعر المستهدف';

  @override
  String get currencyUsd => 'دولار';

  @override
  String get currencySar => 'ر.س';

  @override
  String liveHighestBidAmount(String amount, String currency) {
    return '$amount $currency';
  }

  @override
  String get liveAddCommentOrBid => 'أضف تعليق أو سعر...';

  @override
  String liveBidAmount(int amount) {
    return 'زايد بـ $amount ر.س';
  }

  @override
  String get liveCommentSample => 'هذا العقار ممتاز جداً!';

  @override
  String get liveChatYou => 'أنت';

  @override
  String get liveSendGift => 'إرسال هدية';

  @override
  String get liveSelectGift => 'اختر هدية';

  @override
  String get liveSendToHost => 'إرسال للمضيف';

  @override
  String liveGiftSent(String name, String icon) {
    return 'أرسل $name $icon';
  }

  @override
  String get liveGiftCommentGeneric => 'أرسل هدية';

  @override
  String get liveGiftRose => 'وردة';

  @override
  String get liveGiftCoffee => 'قهوة';

  @override
  String get liveGiftDonut => 'دونات';

  @override
  String get liveGiftHeart => 'قلب';

  @override
  String get liveGiftParty => 'احتفال';

  @override
  String get liveGiftCrown => 'تاج';

  @override
  String get liveGiftRocket => 'صاروخ';

  @override
  String get liveGiftDiamond => 'ماسة';

  @override
  String get liveVipBadge => 'VIP';

  @override
  String liveCoinsBalance(int count) {
    return '$count';
  }

  @override
  String get liveGiftPriceLabel => 'السعر';

  @override
  String liveGiftPriceAmount(String amount, String currency) {
    return '$amount $currency';
  }

  @override
  String liveGiftBuy(String price) {
    return 'شراء — $price';
  }

  @override
  String get liveGiftBuyMore => 'شراء المزيد';

  @override
  String get liveGiftBuying => 'جاري الشراء…';

  @override
  String get liveGiftSending => 'جاري الإرسال…';

  @override
  String liveGiftPurchaseSuccess(String name) {
    return 'تم شراء $name';
  }

  @override
  String get liveGiftLoginRequired => 'سجّل الدخول لشراء أو إرسال الهدايا';

  @override
  String get liveGiftNoRecipient => 'افتح بثاً أو مزاداً لإرسال هدية';

  @override
  String get liveGiftCannotSendToSelf => 'لا يمكنك إرسال هدية إلى مزادك الخاص';

  @override
  String get liveGiftCatalogEmpty => 'لا توجد هدايا متاحة';

  @override
  String get liveGiftRetry => 'إعادة المحاولة';

  @override
  String liveGiftOwned(int count) {
    return '×$count';
  }

  @override
  String get liveGiftLevelBanner => 'أرسل هدية لتفعيل مستوى المُهدي والمكافآت';

  @override
  String get liveGiftPinHint => 'ثبّت الهدايا التي تفضلها في الأعلى';

  @override
  String get liveGiftPinAction => 'تثبيت';

  @override
  String get liveGiftUnpinAction => 'إلغاء التثبيت';

  @override
  String get liveGiftTabGifts => 'هدايا';

  @override
  String get liveGiftTabSongs => 'أغاني';

  @override
  String get liveGiftTabInteractive => 'تفاعلي';

  @override
  String get liveGiftTabComingSoon => 'قريباً';

  @override
  String get liveGiftSendAction => 'إرسال';

  @override
  String get liveGiftRecharge => 'شحن';

  @override
  String get firstRechargeTitle => 'عرض الشحن الأول';

  @override
  String firstRechargeSubtitle(int days) {
    return 'المكافآت متاحة فقط مع الشحن النقدي. ينتهي العرض خلال $days أيام.';
  }

  @override
  String get firstRechargeRoseTitle => 'احصل على 3 ورود في حقيبتك';

  @override
  String get firstRechargeRoseBody => 'احصل على واحدة الآن والباقي بعد 24 ساعة، كل منها متاح لمدة 7 أيام';

  @override
  String get firstRechargeBonusTitle => 'احصل على عملات إضافية';

  @override
  String get firstRechargeBonusBody => 'استخدم العملات على عناصر افتراضية مثل الهدايا';

  @override
  String get firstRechargeGetCoins => 'احصل على عملات';

  @override
  String get firstRechargeGetCoinsHint => 'اشحن لتحصل على هدايا وعملات إضافية.';

  @override
  String get firstRechargePolicy => 'بالمتابعة، فإنك توافق على سياسة العناصر الافتراضية. ستفقد أيضاً المكافأة الإضافية إذا انسحبت من هذا الشراء.';

  @override
  String firstRechargeCta(String coins, String price) {
    return 'احصل على $coins ($price)';
  }

  @override
  String get auctionGiftsTitle => 'هدايا المزاد';

  @override
  String get auctionGiftsEmpty => 'لم تُرسل هدايا على هذا المزاد بعد';

  @override
  String auctionGiftsSummary(String current, String target, String currency) {
    return '$current / $target $currency';
  }

  @override
  String auctionGiftsContribution(String amount, String currency) {
    return '+$amount $currency';
  }

  @override
  String liveQuickBid(int amount) {
    return '+$amount';
  }

  @override
  String get highestCurrentBid => 'أعلى مزايدة حالية';

  @override
  String get bidsLabel => 'المزايدات';

  @override
  String get auctionGiftsLabel => 'الهدايا';

  @override
  String get bidNow => 'زايد الآن';

  @override
  String get navAdd => 'إضافة';

  @override
  String get navChat => 'الدردشة';

  @override
  String get navProfile => 'حسابي';

  @override
  String get describePostHint => 'أضف وصفًا...';

  @override
  String get addDescriptionHint => 'أضف وصفًا...';

  @override
  String get hashtagsLabel => 'هاشتاجات';

  @override
  String get mentionsLabel => 'منشن';

  @override
  String get whoCanWatchLabel => 'من يمكنه مشاهدة هذا المنشور';

  @override
  String get allowCommentsLabel => 'السماح بالتعليقات';

  @override
  String get allowReuseLabel => 'السماح بإعادة استخدام المحتوى';

  @override
  String get allowReuseSubtitle => 'Duet و Stitch والملصقات والإضافة إلى القصة';

  @override
  String get videoPrivacySection => 'خصوصية الفيديو';

  @override
  String get advancedSettings => 'إعدادات متقدمة';

  @override
  String get addPostSettingsTitle => 'الإعدادات';

  @override
  String get everyoneCanViewPost => 'يمكن للجميع مشاهدة هذا المنشور';

  @override
  String get friendsCanViewPost => 'يمكن للأصدقاء مشاهدة هذا المنشور';

  @override
  String get onlyYouCanViewPost => 'يمكنك أنت فقط مشاهدة هذا المنشور';

  @override
  String get friendsPrivacySubtitle => 'المتابعون الذين تتابعهم';

  @override
  String get draftsLabel => 'المسودات';

  @override
  String get moreOptionsLabel => 'المزيد من الخيارات';

  @override
  String get previewLabel => 'معاينة';

  @override
  String get editCoverLabel => 'تعديل الغلاف';

  @override
  String get locationLabelShort => 'الموقع';

  @override
  String get addPostDraftsComingSoon => 'المسودات قريبًا';

  @override
  String get allowDuetLabel => 'السماح بـ Duet';

  @override
  String get allowStitchLabel => 'السماح بـ Stitch';

  @override
  String get addLocationLabel => 'إضافة موقع';

  @override
  String get selectCity => 'اختر المدينة';

  @override
  String get selectCityHint => 'ابحث عن المدن';

  @override
  String get selectCountryHint => 'ابحث عن الدول';

  @override
  String get locationSearchHint => 'ابحث عن الدول أو المدن';

  @override
  String get clearLocation => 'مسح الموقع';

  @override
  String get everyoneLabel => 'الجميع';

  @override
  String get friendsLabel => 'الأصدقاء';

  @override
  String get onlyMeLabel => 'أنا فقط';

  @override
  String get videoLabel => 'فيديو';

  @override
  String get recordVideo => 'تسجيل فيديو';

  @override
  String get imagesLabel => 'صور';

  @override
  String get imageFromLibrary => 'رفع صور من المكتبة';

  @override
  String get videoFromLibrary => 'استيراد فيديوهات من المكتبة';

  @override
  String get tapToSelectMedia => 'اضغط للرفع من المكتبة';

  @override
  String get pleaseSelectMediaFirst => 'يرجى اختيار الوسائط أولاً';

  @override
  String get loginRequired => 'تسجيل الدخول مطلوب';

  @override
  String get loginRequiredMessage => 'يرجى تسجيل الدخول للإعجاب أو التعليق أو حفظ المنشورات';

  @override
  String get cancel => 'إلغاء';

  @override
  String get login => 'تسجيل الدخول';

  @override
  String get commentsTitle => 'التعليقات';

  @override
  String commentsCount(int count) {
    return '$count تعليقات';
  }

  @override
  String get postLikesEmpty => 'لا إعجابات بعد';

  @override
  String get postViewsEmpty => 'لا مشاهدات بعد';

  @override
  String postViewWatchedDuration(int seconds) {
    return 'شاهد $seconds ث';
  }

  @override
  String get viewsLabel => 'المشاهدات';

  @override
  String get commentsSortNewest => 'الأحدث';

  @override
  String get commentsSortOldest => 'الأقدم';

  @override
  String get commentsSortTop => 'الأكثر إعجاباً';

  @override
  String get noCommentsYet => 'لا توجد تعليقات بعد. كن أول من يعلق!';

  @override
  String get addCommentHint => 'أضف تعليقًا...';

  @override
  String get justNow => 'الآن';

  @override
  String inboxTimeMinutes(int count) {
    return '$count د';
  }

  @override
  String inboxTimeHours(int count) {
    return '$count س';
  }

  @override
  String inboxTimeDays(int count) {
    return '$count ي';
  }

  @override
  String get replyAction => 'رد';

  @override
  String replyingTo(String username) {
    return 'الرد على $username';
  }

  @override
  String viewReplies(int count) {
    return 'عرض $count ردود';
  }

  @override
  String get hideReplies => 'إخفاء الردود';

  @override
  String get loadMoreReplies => 'تحميل المزيد من الردود';

  @override
  String get deleteCommentTitle => 'حذف التعليق؟';

  @override
  String get deleteCommentMessage => 'سيتم حذف هذا التعليق نهائيًا.';

  @override
  String get deleteAction => 'حذف';

  @override
  String get editPost => 'تعديل المنشور';

  @override
  String get deletePost => 'حذف المنشور';

  @override
  String get deletePostTitle => 'حذف المنشور؟';

  @override
  String get deletePostMessage => 'سيتم حذف هذا المنشور نهائيًا. يمكنك حذف منشوراتك فقط.';

  @override
  String get postOptionShare => 'مشاركة';

  @override
  String get postOptionReport => 'إبلاغ';

  @override
  String get postOptionNotInterested => 'غير مهتم';

  @override
  String get feedInterestPromptQuestion => 'هل يهمك هذا النوع من المحتوى؟';

  @override
  String get feedInterestPromptYes => 'نعم';

  @override
  String get feedInterestPromptNo => 'لا';

  @override
  String get feedInterestPromptThanks => 'شكرًا — سنعرض محتوى مشابه أكثر';

  @override
  String get postOptionDownload => 'تنزيل';

  @override
  String get postOptionAddToStory => 'إضافة للقصة';

  @override
  String get postOptionShareAsGif => 'مشاركة كصورة متحركة';

  @override
  String get postOptionCreateGroup => 'إنشاء مجموعة';

  @override
  String get postLinkCopied => 'تم نسخ الرابط';

  @override
  String get postReportTitle => 'الإبلاغ عن المنشور؟';

  @override
  String get postReportMessage => 'أخبرنا إذا كان هذا المنشور يخالف إرشادات المجتمع.';

  @override
  String get postReportSubmitted => 'شكرًا على الإبلاغ. سنراجع هذا المنشور.';

  @override
  String get postReportReasonSpam => 'بريد مزعج';

  @override
  String get postReportReasonHarassment => 'تحرش أو تنمر';

  @override
  String get postReportReasonHateSpeech => 'خطاب كراهية';

  @override
  String get postReportReasonViolence => 'عنف أو محتوى خطير';

  @override
  String get postReportReasonNudity => 'عري أو محتوى جنسي';

  @override
  String get postReportReasonFalseInfo => 'معلومات مضللة';

  @override
  String get postReportReasonScam => 'احتيال أو نصب';

  @override
  String get postReportReasonCopyright => 'انتهاك حقوق النشر';

  @override
  String get postReportReasonOther => 'أخرى';

  @override
  String get postNotInterestedApplied => 'سنعرض منشورات أقل من هذا النوع';

  @override
  String get postDownloadStarted => 'جاري التنزيل…';

  @override
  String get postDownloadSaved => 'تم الحفظ في مجلد التنزيلات';

  @override
  String get postDownloadFailed => 'تعذر تنزيل الوسائط';

  @override
  String get postShareAsGifUnavailable => 'مشاركة GIF متاحة للفيديو فقط';

  @override
  String get postShareSheetTitle => 'مشاركة المنشور';

  @override
  String get postShareSendToTitle => 'إرسال إلى';

  @override
  String get postShareSearchHint => 'بحث';

  @override
  String get postShareRecentChats => 'المحادثات الأخيرة';

  @override
  String get postShareSearchUsers => 'ابحث عن الأصدقاء والمستخدمين';

  @override
  String get postShareNoUsers => 'لم يتم العثور على مستخدمين';

  @override
  String get postShareToApps => 'مشاركة عبر التطبيقات';

  @override
  String get postShareMessenger => 'ماسنجر';

  @override
  String get postShareFacebook => 'فيسبوك';

  @override
  String get postShareInstagram => 'إنستغرام';

  @override
  String get postShareWhatsApp => 'واتساب';

  @override
  String get postShareTelegram => 'تيليجرام';

  @override
  String get postShareTwitter => 'إكس';

  @override
  String get postShareSms => 'رسائل';

  @override
  String get postShareEmail => 'بريد';

  @override
  String get postShareCopyLink => 'نسخ الرابط';

  @override
  String get postShareMore => 'المزيد';

  @override
  String get postOptionCast => 'البث';

  @override
  String get postShareInstagramHint => 'تم نسخ الرابط — الصقه في إنستغرام';

  @override
  String get postOptionCastUnavailable => 'البث غير متاح حالياً';

  @override
  String get postShareSendFailed => 'تعذر إرسال المنشور';

  @override
  String postShareSentTo(String name) {
    return 'تم الإرسال إلى $name';
  }

  @override
  String get postShareSend => 'إرسال';

  @override
  String postShareSendToCount(int count) {
    return 'إرسال ($count)';
  }

  @override
  String postShareSentCount(int count) {
    return 'تم الإرسال إلى $count أشخاص';
  }

  @override
  String get postQuickShareTitle => 'الأصدقاء الأخيرون';

  @override
  String get postQuickShareSubtitle => 'اختر الأصدقاء، اضغط مرة أخرى للإلغاء، ثم أرسل';

  @override
  String get postAddToStoryHint => 'أنشئ قصتك — المنشور جاهز للمشاركة';

  @override
  String get postCreateGroupHint => 'اختر جهات اتصال لبدء مجموعة';

  @override
  String get postUpdatedSuccessfully => 'تم تحديث المنشور بنجاح';

  @override
  String get postDeletedSuccessfully => 'تم حذف المنشور بنجاح';

  @override
  String get saveButton => 'حفظ';

  @override
  String get categoryLabel => 'الفئة';

  @override
  String get selectCategoryHint => 'اختر فئة';

  @override
  String get hashtagsHint => 'اكتب #وسم في الوصف (مثال: #سفر #طعام)';

  @override
  String get mentionsHint => 'اكتب @اسم_المستخدم في الوصف (مثال: @jane_doe)';

  @override
  String get mediaLabel => 'الوسائط';

  @override
  String get settingsAndPrivacy => 'الإعدادات والخصوصية';

  @override
  String get settingsSectionAccount => 'الحساب';

  @override
  String get settingsSecurity => 'الأمان';

  @override
  String get settingsPrivacy => 'الخصوصية';

  @override
  String get privacyPrivateAccount => 'حساب خاص';

  @override
  String get privacyPrivateAccountSubtitle => 'المتابعون المقبولون فقط يمكنهم رؤية منشوراتك وقصصك.';

  @override
  String get privacyWhoCanMessage => 'من يمكنه مراسلتك';

  @override
  String get privacyMessageEveryone => 'الجميع';

  @override
  String get privacyMessageFollowers => 'من تتابعهم';

  @override
  String get privacyMessageFriends => 'الأصدقاء';

  @override
  String get privacyMessageNobody => 'لا أحد';

  @override
  String get privacyAllowComments => 'السماح بالتعليقات';

  @override
  String get privacyAllowCommentsSubtitle => 'يمكن للآخرين التعليق على منشوراتك.';

  @override
  String get privacyUpdated => 'تم تحديث إعدادات الخصوصية';

  @override
  String get privacySectionAccount => 'خصوصية الحساب';

  @override
  String get privacySectionInteractions => 'التفاعلات';

  @override
  String get settingsSectionContent => 'المحتوى والعرض';

  @override
  String get settingsLanguage => 'اللغة';

  @override
  String get settingsNotifications => 'الإشعارات';

  @override
  String get settingsDarkMode => 'الوضع المظلم';

  @override
  String get settingsSectionSupport => 'الدعم';

  @override
  String get settingsHelpCenter => 'مركز المساعدة';

  @override
  String get settingsAbout => 'حول التطبيق';

  @override
  String get settingsLogout => 'تسجيل الخروج';

  @override
  String get settingsSelectLanguage => 'اختر اللغة';

  @override
  String get settingsAppearance => 'المظهر';

  @override
  String get settingsLightMode => 'وضع النهار';

  @override
  String get settingsDarkModeOption => 'الوضع المظلم';

  @override
  String get settingsLanguageEnglish => 'English';

  @override
  String get settingsLanguageArabic => 'العربية';

  @override
  String get settingsOn => 'مفعل';

  @override
  String get settingsOff => 'معطل';

  @override
  String get settingsLogoutTitle => 'تسجيل الخروج؟';

  @override
  String get settingsLogoutMessage => 'ستحتاج إلى تسجيل الدخول مرة أخرى لاستخدام حسابك.';

  @override
  String get settingsComingSoon => 'قريباً';

  @override
  String get settingsChatWallpaper => 'خلفية المحادثة';

  @override
  String get settingsSectionAdmin => 'المسؤول';

  @override
  String get settingsAdminActivity => 'نشاط المستخدم';

  @override
  String get adminActivityTitle => 'النشاط';

  @override
  String get adminActivityEmpty => 'لا يوجد نشاط بعد';

  @override
  String get adminActivityJustNow => 'الآن';

  @override
  String get adminActivityNoDetails => 'لا توجد تفاصيل';

  @override
  String adminActivityOnPost(String post) {
    return 'على المنشور: $post';
  }

  @override
  String get adminActivityTypeCreatePost => 'أنشأ منشوراً';

  @override
  String get adminActivityTypeComment => 'علّق';

  @override
  String get adminActivityTypeLikePost => 'أعجب بمنشور';

  @override
  String get adminActivityTypeSendGift => 'أرسل هدية';

  @override
  String get chatWallpaperTitle => 'خلفية المحادثة';

  @override
  String get chatWallpaperSubtitle => 'اختر نمط الخلفية للمحادثات. الألوان تتبع سمة التطبيق.';

  @override
  String get chatWallpaperPlus => 'علامات زائد';

  @override
  String get chatWallpaperSquares => 'مربعات';

  @override
  String get chatWallpaperMaze => 'متاهة';

  @override
  String get chatWallpaperChooseFromPhotos => 'اختر من الصور';

  @override
  String get chatWallpaperUploadDeviceSubtitle => 'رفع صورة شخصية من الجهاز';

  @override
  String get chatWallpaperDefault => 'الافتراضي (بدون خلفية)';

  @override
  String get chatWallpaperCatalog => 'كتالوج الخلفيات';

  @override
  String get chatWallpaperUpdated => 'تم تحديث الخلفية الشخصية';

  @override
  String get chatSettingsTitle => 'التفاصيل';

  @override
  String get chatSettingsProfile => 'الملف الشخصي';

  @override
  String get chatSettingsMute => 'كتم';

  @override
  String get chatSettingsMuted => 'مكتوم';

  @override
  String get chatSettingsReport => 'إبلاغ';

  @override
  String get chatSettingsMuteNotifications => 'كتم الإشعارات';

  @override
  String get chatSettingsPinToTop => 'تثبيت في الأعلى';

  @override
  String get chatSettingsWallpaperSubtitle => 'خلفية نمط مخصصة';

  @override
  String get chatSettingsSearch => 'بحث في المحادثة';

  @override
  String chatSettingsBlock(String username) {
    return 'حظر @$username';
  }

  @override
  String get chatSettingsBlocked => 'محظور';

  @override
  String get unblock => 'إلغاء الحظر';

  @override
  String get chatYouBlockedUser => 'لقد قمت بحظر هذا المستخدم. قم بإلغاء الحظر لتتمكن من مراسلته.';

  @override
  String get userNotFound => 'المستخدم غير موجود';

  @override
  String get chatSettingsDeleteHistory => 'مسح سجل المحادثة';

  @override
  String get chatSettingsSearchHint => 'اكتب كلمة للبحث...';

  @override
  String chatSettingsSearching(String query) {
    return 'جاري البحث عن \"$query\"...';
  }

  @override
  String chatSettingsReportTitle(String username) {
    return 'الإبلاغ عن @$username';
  }

  @override
  String get chatSettingsReportSpam => 'احتيال أو إزعاج';

  @override
  String get chatSettingsReportHarassment => 'مضايقة أو تنمر';

  @override
  String get chatSettingsReportInappropriate => 'محتوى غير لائق';

  @override
  String chatSettingsReportSubmitted(String reason) {
    return 'تم إرسال البلاغ: $reason';
  }

  @override
  String chatSettingsBlockTitle(String username) {
    return 'حظر @$username؟';
  }

  @override
  String get chatSettingsBlockMessage => 'لن يتمكن من مراسلتك أو رؤية ملفك الشخصي.';

  @override
  String get chatSettingsDeleteTitle => 'مسح سجل المحادثة؟';

  @override
  String get chatSettingsDeleteMessage => 'سيؤدي هذا إلى إزالة سجل المحادثة بالنسبة لك. لا يمكن التراجع عن هذا الإجراء.';

  @override
  String get messagesTitle => 'الرسائل';

  @override
  String get messagesInboxTitle => 'البريد الوارد';

  @override
  String get messagesNewChatTitle => 'محادثة جديدة';

  @override
  String get messagesNewChatSearchHint => 'بحث';

  @override
  String get closeAction => 'إغلاق';

  @override
  String get chatSendMessageHint => 'أرسل رسالة...';

  @override
  String get chatActiveYesterday => 'نشط أمس';

  @override
  String get messagesSwitchAccount => 'تغيير الحساب';

  @override
  String get messagesNewConversation => 'بدء محادثة جديدة';

  @override
  String get messagesSearchHint => 'بحث عن محادثات أو أشخاص';

  @override
  String get messagesYourStory => 'قصتك';

  @override
  String get messagesPeopleYouMayKnow => 'أشخاص قد تعرفهم';

  @override
  String get messagesSeeAll => 'عرض الكل';

  @override
  String get messagesFollow => 'متابعة';

  @override
  String get messagesFollowing => 'متابَع';

  @override
  String get messagesRecentMentions => 'الإشارات الأخيرة';

  @override
  String get messagesActivityFollowers => 'متابعون';

  @override
  String get messagesActivityActivities => 'أنشطة';

  @override
  String get messagesActivityTitle => 'النشاط';

  @override
  String get messagesNewFollowers => 'متابعون جدد';

  @override
  String get messagesActivityComments => 'تعليقات';

  @override
  String get messagesActivityMentions => 'إشارات';

  @override
  String get messagesActivityNotifications => 'إشعارات';

  @override
  String get activityTabLikes => 'إعجابات';

  @override
  String get activityAllCaughtUp => 'أنت على اطلاع بكل شيء';

  @override
  String get activityClearNotificationsMessage => 'هل تريد إزالة جميع الإشعارات المقروءة من نشاطك؟';

  @override
  String get activityOpenCommentsSubtitle => 'عرض التعليقات على منشوراتك';

  @override
  String get activityInboxSubtitle => 'إعجابات وتعليقات والمزيد';

  @override
  String get messagesRecentMessages => 'الرسائل الأخيرة';

  @override
  String get messagesAllChats => 'جميع المحادثات';

  @override
  String get messagesAll => 'الكل';

  @override
  String get messagesNoResults => 'لا توجد نتائج';

  @override
  String get messagesInboxNoMessagesYet => 'لا توجد رسائل بعد';

  @override
  String get messagesInboxYouPrefix => 'أنت';

  @override
  String get messagesInboxLastPhoto => 'صورة';

  @override
  String get messagesInboxLastVideo => 'فيديو';

  @override
  String get messagesInboxLastVoice => 'رسالة صوتية';

  @override
  String get messagesInboxLastGift => 'هدية';

  @override
  String get messagesInboxLastShare => 'شارك منشوراً';

  @override
  String get messagesInboxMessageDeleted => 'تم حذف الرسالة';

  @override
  String get messagesInboxGroupFallback => 'مجموعة';

  @override
  String get messagesInboxUserFallback => 'مستخدم';

  @override
  String get messagesPreviewProperty => 'أهلاً، هل العقار لا يزال متاحاً؟';

  @override
  String get messagesPreviewOffer => 'تم إرسال العرض الجديد';

  @override
  String get messagesPreviewThanks => 'شكراً لاهتمامك بخدماتنا';

  @override
  String get messagesPreviewCar => 'متى يمكنني معاينة السيارة؟';

  @override
  String get messagesMentionVilla => 'منشور رائع يصف الفيلا! @myself';

  @override
  String get messagesMentionCheck => 'ألقِ نظرة على هذا @myself';

  @override
  String get messagesSuggestionBioDesigner => 'مصمم داخلي | معماري';

  @override
  String get messagesSuggestionBioJeddah => 'أفضل العروض في جدة';

  @override
  String get messagesSuggestionBioLuxury => 'عقارات فاخرة عالمية';

  @override
  String get messagesSuggestionFriendsOfFriends => 'مقترح لك';

  @override
  String get messagesSuggestionPopular => 'منشئ محتوى شائع';

  @override
  String messagesSuggestionMutualFriends(num count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count أصدقاء مشتركين',
      one: 'صديق مشترك واحد',
    );
    return '$_temp0';
  }

  @override
  String get messagesSuggestionsEmpty => 'لا توجد اقتراحات حالياً';

  @override
  String get userCommentsTitle => 'تعليقاتي';

  @override
  String get userCommentsEmpty => 'لم تعلق على أي منشور بعد';

  @override
  String get userCommentReplyLabel => 'رد';

  @override
  String get userCommentAction => 'علّق';

  @override
  String userCommentOnPost(String author) {
    return 'على منشور $author';
  }

  @override
  String get userLikesTitle => 'الإعجابات';

  @override
  String get userLikesEmpty => 'لم يعجب أحد بمنشوراتك بعد';

  @override
  String get userLikeReceivedAction => 'أعجب بمنشورك';

  @override
  String get userMentionsTitle => 'إشاراتي';

  @override
  String get userMentionsEmpty => 'لم يذكرك أحد بعد';

  @override
  String get userMentionAction => 'ذكرك';

  @override
  String get userMentionInComment => 'في تعليق';

  @override
  String get userFollowersTitle => 'المتابعون';

  @override
  String get userFollowerAction => 'تابعك';

  @override
  String get chatMessageDeleted => 'تم حذف هذه الرسالة';

  @override
  String get chatActionReply => 'رد';

  @override
  String get chatActionReact => 'تفاعل';

  @override
  String get chatActionDelete => 'حذف';

  @override
  String get chatDeleteMessageTitle => 'حذف الرسالة؟';

  @override
  String get chatDeleteMessageMessage => 'سيتم إخفاء هذه الرسالة عن الجميع في المحادثة.';

  @override
  String get chatActiveNow => 'نشط الآن';

  @override
  String get chatAddComment => 'اكتب رسالة...';

  @override
  String get chatRecording => 'جاري التسجيل...';

  @override
  String get chatSlideUpToCancel => 'اسحب للأعلى للإلغاء';

  @override
  String get chatRecordingPermissionDenied => 'اسمح بالوصول إلى الميكروفون لتسجيل الرسائل الصوتية.';

  @override
  String get chatRecordingPermissionTitle => 'الوصول إلى الميكروفون';

  @override
  String get chatRecordingPermissionSettingsMessage => 'الرسائل الصوتية تحتاج الميكروفون. افتح الإعدادات، ثم الأذونات، واسمح بالميكروفون لتطبيق Bimo Bond.';

  @override
  String get chatRecordingOpenSettings => 'فتح الإعدادات';

  @override
  String get chatRecordingAllowMicrophone => 'سماح';

  @override
  String get chatRecordingPluginUnavailable => 'التسجيل الصوتي غير جاهز. أغلق التطبيق بالكامل ثم شغّله من جديد (وليس إعادة التحميل السريع).';

  @override
  String get chatVoiceTooShort => 'اضغط مطولاً لتسجيل رسالة صوتية.';

  @override
  String get chatVoicePlaybackFailed => 'تعذّر تشغيل الرسالة الصوتية.';

  @override
  String get chatAttachmentSendFailed => 'تعذّر إرسال المرفق. حاول مرة أخرى.';

  @override
  String get chatLocationPermissionDenied => 'يلزم إذن الموقع لمشاركة موقعك.';

  @override
  String get chatContactsPermissionDenied => 'يلزم إذن جهات الاتصال لمشاركة جهة اتصال.';

  @override
  String get chatFeatureComingSoon => 'قريباً.';

  @override
  String get chatMessageLocation => 'الموقع';

  @override
  String get messagesInboxLastLocation => 'موقع';

  @override
  String get messagesInboxLastFile => 'ملف';

  @override
  String get messagesInboxLastContact => 'جهة اتصال';

  @override
  String get chatSeedGreeting => 'مرحباً! كيف يمكنني مساعدتك؟';

  @override
  String get chatSeedInterested => 'أنا مهتم بالعقار المعروض';

  @override
  String get chatSeedFinalPrice => 'هل يمكنني معرفة السعر النهائي؟';

  @override
  String get chatSeedAutoReply => 'شكراً لتواصلك معنا، سنرد عليك في أقرب وقت بمزيد من التفاصيل.';

  @override
  String get chatUserBio => 'مهتم بالعقارات والتصميم.';

  @override
  String get chatMoreGallery => 'استيراد';

  @override
  String get chatMoreCamera => 'الكاميرا';

  @override
  String get chatMoreVideo => 'فيديو';

  @override
  String get chatMoreLocation => 'الموقع';

  @override
  String get chatMoreContact => 'جهة اتصال';

  @override
  String get chatMoreFile => 'ملف';

  @override
  String get chatMoreGift => 'هدية';

  @override
  String get chatMorePoll => 'تصويت';

  @override
  String get chatGiftSheetTitle => 'أرسل هدية';

  @override
  String get chatGiftSheetSubtitle => 'اختر هدية من مخزونك';

  @override
  String get chatGiftInventoryEmpty => 'لا تملك أي هدايا بعد. اشترِ هدايا من المحفظة أولاً.';

  @override
  String get chatGiftSentLabel => 'تم إرسال الهدية';

  @override
  String get chatMessageContact => 'جهة اتصال';

  @override
  String get chatPollSheetTitle => 'إنشاء تصويت';

  @override
  String get chatPollQuestionHint => 'اطرح سؤالاً';

  @override
  String get chatPollOptionsLabel => 'الخيارات';

  @override
  String chatPollOptionHint(int index) {
    return 'خيار $index';
  }

  @override
  String get chatPollAddOption => 'إضافة خيار';

  @override
  String get chatPollAllowMultiple => 'السماح باختيارات متعددة';

  @override
  String get chatPollSend => 'إرسال التصويت';

  @override
  String get chatPollQuestionRequired => 'أدخل سؤالاً للتصويت.';

  @override
  String get chatPollOptionsRequired => 'أضف خيارين على الأقل.';

  @override
  String get chatPollEnded => 'انتهى التصويت';

  @override
  String chatPollVotesCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count أصوات',
      one: 'صوت واحد',
      zero: 'لا أصوات بعد',
    );
    return '$_temp0';
  }

  @override
  String get messagesInboxLastPoll => 'تصويت';

  @override
  String get chatLastMessage1 => 'هل يمكنني معرفة السعر النهائي؟';

  @override
  String get chatLastMessage2 => 'شكراً على التحديث!';

  @override
  String get chatLastMessage3 => 'هل العقار ما زال متاحاً؟';

  @override
  String get chatLastMessage4 => 'أرسل صورة';

  @override
  String get chatLastMessage5 => 'أراك غداً 👋';

  @override
  String get mediaStudioAutoCut => 'AutoCut';

  @override
  String get addPostAsAuction => 'عرض في البث المباشر';

  @override
  String get auctionItemName => 'اسم المنتج';

  @override
  String get auctionItemNameHint => 'مثال: ساعة جيب عتيقة';

  @override
  String get auctionStartingPrice => 'السعر الابتدائي (دولار)';

  @override
  String get auctionTargetPriceLabel => 'السعر المستهدف (دولار)';

  @override
  String get auctionStartDate => 'بداية المزاد';

  @override
  String get auctionEndDate => 'نهاية المزاد';

  @override
  String get auctionEndBeforeStart => 'يجب أن يكون تاريخ النهاية بعد تاريخ البداية';

  @override
  String get auctionTargetBelowStart => 'يجب أن يكون السعر المستهدف أعلى من السعر الابتدائي';

  @override
  String get auctionInvalidPrice => 'أدخل سعراً صالحاً';

  @override
  String get hashtagFeedSubtitle => 'منشورات بهذا الوسم';

  @override
  String get noHashtagPosts => 'لا توجد منشورات لهذا الوسم بعد';

  @override
  String get trendingHashtags => 'الوسوم الرائجة';

  @override
  String get searchHashtagsHint => 'ابحث عن وسوم';

  @override
  String get noHashtagsFound => 'لم يتم العثور على وسوم';

  @override
  String hashtagPostCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count منشورات',
      one: 'منشور واحد',
      zero: 'لا منشورات',
    );
    return '$_temp0';
  }

  @override
  String get notificationsEmpty => 'لا توجد إشعارات بعد';

  @override
  String get notificationsEmptySubtitle => 'عندما يتفاعل شخص معك، ستظهر الإشعارات هنا.';

  @override
  String get notificationsEmptyUnread => 'لا توجد إشعارات غير مقروءة.';

  @override
  String get notificationsEmptyRead => 'لا توجد إشعارات مقروءة بعد.';

  @override
  String notificationsFilterUnreadCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count إشعارات غير مقروءة',
      one: 'إشعار واحد غير مقروء',
    );
    return '$_temp0';
  }

  @override
  String get notificationsRetry => 'حاول مجدداً';

  @override
  String get notificationsOk => 'حسناً';

  @override
  String get notificationsLoadError => 'تعذّر تحميل الإشعارات';

  @override
  String get notificationsMarkAllRead => 'تحديد الكل كمقروء';

  @override
  String get notificationsClearRead => 'مسح المقروء';

  @override
  String get notificationsFilterAll => 'الكل';

  @override
  String get notificationsFilterUnread => 'غير مقروء';

  @override
  String get notificationsFilterRead => 'مقروء';

  @override
  String get notificationsFilterViewAll => 'عرض الكل';

  @override
  String get notificationsFilterActivity => 'النشاط';

  @override
  String get notificationsFilterAuctions => 'المزادات';

  @override
  String get notificationsFilterInvites => 'الدعوات';

  @override
  String get notificationsAccept => 'قبول';

  @override
  String get notificationsDecline => 'رفض';

  @override
  String get notificationsEmptyActivity => 'لا توجد إشعارات نشاط بعد.';

  @override
  String get notificationsEmptyAuctions => 'لا توجد إشعارات مزادات بعد.';

  @override
  String get notificationsEmptyInvites => 'لا توجد إشعارات دعوات بعد.';

  @override
  String get notificationContextPost => 'منشور';

  @override
  String get notificationMediaVideo => 'فيديو';

  @override
  String get notificationMediaImage => 'صورة';

  @override
  String get notificationActionFollowedYou => 'تابعك';

  @override
  String get notificationActionFollowRequest => 'طلب متابعتك';

  @override
  String get notificationActionFollowAccepted => 'قبل طلب متابعتك';

  @override
  String get notificationActionPostLike => 'أعجب بمنشورك';

  @override
  String get notificationActionPostComment => 'علّق على منشورك';

  @override
  String get notificationActionCommentReply => 'رد على تعليقك';

  @override
  String get notificationActionCommentLike => 'أعجب بتعليقك';

  @override
  String get notificationActionMention => 'أشار إليك';

  @override
  String get notificationActionRepost => 'أعاد نشر منشورك';

  @override
  String get notificationActionGift => 'أرسل لك هدية';

  @override
  String get notificationActionAuctionUpdate => 'حدّث مزاد تتابعه';

  @override
  String get notificationActionAuctionWon => 'فزت بمزاد';

  @override
  String get notificationSomeone => 'شخص ما';

  @override
  String get notificationTitleDefault => 'إشعار';

  @override
  String get notificationTitleNewFollower => 'متابع جديد';

  @override
  String get notificationTitleFollowRequest => 'طلب متابعة';

  @override
  String get notificationTitleFollowAccepted => 'تم قبول طلب المتابعة';

  @override
  String get notificationTitlePostLike => 'إعجاب جديد';

  @override
  String get notificationTitlePostComment => 'تعليق جديد';

  @override
  String get notificationTitleCommentReply => 'رد جديد';

  @override
  String get notificationTitleCommentLike => 'إعجاب على تعليق';

  @override
  String get notificationTitleMention => 'إشارة';

  @override
  String get notificationTitleRepost => 'إعادة نشر';

  @override
  String get notificationTitleGift => 'هدية مستلمة';

  @override
  String get notificationTitleAuctionUpdate => 'تحديث مزاد';

  @override
  String get notificationTitleAuctionWon => 'فوز في مزاد';

  @override
  String get notificationBodyDefault => 'لديك إشعار جديد';

  @override
  String notificationBodyNewFollower(String name) {
    return 'بدأ $name بمتابعتك';
  }

  @override
  String notificationBodyFollowRequest(String name) {
    return 'طلب $name متابعتك';
  }

  @override
  String notificationBodyFollowAccepted(String name) {
    return 'قبل $name طلب متابعتك';
  }

  @override
  String notificationBodyPostLike(String name) {
    return 'أعجب $name بمنشورك';
  }

  @override
  String notificationBodyPostComment(String name) {
    return 'علّق $name على منشورك';
  }

  @override
  String notificationBodyCommentReply(String name) {
    return 'رد $name على تعليقك';
  }

  @override
  String notificationBodyCommentLike(String name) {
    return 'أعجب $name بتعليقك';
  }

  @override
  String notificationBodyMention(String name) {
    return 'أشار إليك $name';
  }

  @override
  String notificationBodyRepost(String name) {
    return 'أعاد $name نشر منشورك';
  }

  @override
  String notificationBodyGift(String name) {
    return 'أرسل لك $name هدية';
  }

  @override
  String get notificationBodyAuctionUpdate => 'تم تحديث مزاد تتابعه';

  @override
  String get notificationBodyAuctionWon => 'لقد فزت بمزاد';

  @override
  String get walletTitle => 'المحفظة';

  @override
  String get walletBalanceLabel => 'رصيد العملات';

  @override
  String get walletChoosePackage => 'اختر باقة';

  @override
  String get walletCustomAmountTitle => 'مبلغ مخصص';

  @override
  String get walletCustomCoinsLabel => 'كم عملة تريد؟';

  @override
  String get walletCustomCoinsHint => 'مثال: 500';

  @override
  String get walletCustomCoinsReceive => 'ستحصل على';

  @override
  String walletCustomCoinsValue(String coins) {
    return '$coins عملة';
  }

  @override
  String get walletCustomYouPay => 'ستدفع';

  @override
  String get walletPackageQuotes => 'عروض الباقات';

  @override
  String get walletPackageQuotePrice => 'سعر الباقة';

  @override
  String get walletPricingPreviewCost => 'التكلفة الإجمالية';

  @override
  String get walletPricingPreviewLoading => 'جاري الحساب...';

  @override
  String get walletCustomAmountInvalid => 'أدخل عدد عملات صالح.';

  @override
  String walletPurchaseSuccess(int amount) {
    return 'تم شراء $amount عملة بنجاح!';
  }

  @override
  String get walletTopUpButton => 'شحن الرصيد';

  @override
  String get walletProcessing => 'جاري معالجة الدفع...';

  @override
  String get walletCardNumber => 'رقم البطاقة';

  @override
  String get walletExpiry => 'تاريخ الانتهاء (MM/YY)';

  @override
  String get walletCvv => 'رمز التحقق (CVV)';

  @override
  String get walletCardHolder => 'اسم حامل البطاقة';

  @override
  String walletPayButton(String price) {
    return 'دفع $price';
  }

  @override
  String get coinsHubTitle => 'العملات';

  @override
  String get coinsAvailableBalance => 'الرصيد المتاح';

  @override
  String coinsWalletAccountName(String name) {
    return 'حساب $name';
  }

  @override
  String get coinsBalanceRefresh => 'تحديث الرصيد';

  @override
  String get coinsBalanceFooterHint => 'يُحدَّث عند الفتح';

  @override
  String coinsBalanceFooter(String date, String hint) {
    return '$date | $hint';
  }

  @override
  String get coinsTabBuy => 'شراء';

  @override
  String get coinsTabMarket => 'السوق';

  @override
  String get coinsTabVault => 'المخزن';

  @override
  String get coinsUnit => 'عملة';

  @override
  String get coinsHistoryTitle => 'النشاط الأخير';

  @override
  String get coinsMarketSuccess => 'تمت إضافة الهدية إلى مخزنك!';

  @override
  String get coinsVaultEmpty => 'لا توجد هدايا في مخزنك بعد. زُر السوق لشراء هدايا بالعملات.';

  @override
  String get coinsVaultOwned => 'في المخزن';

  @override
  String get coinsInsufficientBalance => 'رصيد العملات غير كافٍ. اشترِ المزيد من تبويب الشراء.';

  @override
  String get walletAccountingPurchase => 'شراء عملات';

  @override
  String get walletAccountingGiftPurchase => 'شراء هدية';

  @override
  String get walletAccountingGiftReceived => 'هدية مستلمة';

  @override
  String get walletAccountingPromotion => 'ترويج منشور';

  @override
  String get walletAccountingAdmin => 'تعديل الرصيد';

  @override
  String get balanceTitle => 'الرصيد';

  @override
  String get balanceDefaultUserName => 'المستخدم';

  @override
  String balanceUserTitle(String name) {
    return 'رصيد $name';
  }

  @override
  String get balanceEstimatedBalance => 'الرصيد التقديري';

  @override
  String get balanceView => 'عرض';

  @override
  String get balanceGet => 'احصل';

  @override
  String get balanceScheduledPayouts => 'المدفوعات المجدولة';

  @override
  String get balanceViewFullSchedule => 'عرض الجدول الكامل >';

  @override
  String get balanceSetupPaymentsBanner => 'لاستلام المدفوعات من برنامج مكافآت المبدعين، قم بإعداد المدفوعات.';

  @override
  String get balanceSetup => 'إعداد';

  @override
  String get balanceSetupRequired => 'الإعداد مطلوب';

  @override
  String get balancePastPayouts => 'المدفوعات السابقة >';

  @override
  String get balanceTransactions => 'المعاملات';

  @override
  String balanceTransactionPreview(String title, String amount) {
    return '$title: $amount >';
  }

  @override
  String get balanceFirstCoinOfferTitle => 'عرض أول شراء للعملات';

  @override
  String get balanceFirstCoinOfferSubtitle => 'احصل على عملات إضافية وهدية متحركة بخصم 99% من أول عملية شراء';

  @override
  String get balanceGetNow => 'احصل الآن ←';

  @override
  String get balanceMonetization => 'تحقيق الدخل';

  @override
  String get balanceViewMore => 'عرض المزيد >';

  @override
  String get balanceMonetizationLive => 'LIVE';

  @override
  String get balanceMonetizationActivities => 'الأنشطة';

  @override
  String get balanceServices => 'الخدمات';

  @override
  String get balancePaymentMethods => 'طرق الدفع';

  @override
  String get balanceRequired => 'مطلوب';

  @override
  String get balanceTaxInformation => 'المعلومات الضريبية';

  @override
  String get balanceIdentityVerification => 'التحقق من الهوية';

  @override
  String get balanceMonetizationCenter => 'مركز تحقيق الدخل';

  @override
  String get balanceExplore => 'استكشف >';

  @override
  String get balanceProgramCreatorRewards => 'برنامج مكافآت المبدعين';

  @override
  String get balanceProgramTiktokGo => 'مكافآت TikTok GO';

  @override
  String get balanceProgramSeries => 'Series';

  @override
  String get balanceSetupPaymentsTitle => 'إعداد المدفوعات';

  @override
  String get balanceSetupPaymentsMessage => 'تأكد من دقة معلوماتك لاستلام المدفوعات في الوقت المحدد. يمكنك تغييرها في أي وقت.';

  @override
  String get balancePayoutMethodTitle => 'طريقة الدفع';

  @override
  String get balancePayoutMethodSubtitle => 'اختر مكان استلام المدفوعات.';

  @override
  String get balanceTaxInfoTitle => 'المعلومات الضريبية';

  @override
  String get balanceTaxInfoSubtitle => 'مطلوبة لأغراض الامتثال.';

  @override
  String get balanceIdentityTitle => 'التحقق من الهوية';

  @override
  String get balanceIdentitySubtitle => 'جهّز هويتك.';

  @override
  String get balanceAddPayoutMethod => 'إضافة طريقة دفع';

  @override
  String get balanceCountryRegion => 'البلد / المنطقة';

  @override
  String get balanceCountryRegionNote => 'يمكنك التسجيل في بلد أو منطقة واحدة فقط. تأكد من اختيارك.';

  @override
  String get balanceChoosePayoutMethod => 'اختر طريقة الدفع';

  @override
  String get balancePayoutZaloPay => 'ZaloPay (VND)';

  @override
  String get balancePayoutZaloPayDetails => 'رسوم الخدمة 1.5% | الحد الأدنى للسحب 2 USD | يصل خلال يوم عمل واحد';

  @override
  String get balancePayoutBank => 'تحويل بنكي (VND)';

  @override
  String get balancePayoutBankDetails => 'رسوم الخدمة 2.9 USD | الحد الأدنى للسحب 8 USD | يصل خلال 3-5 أيام عمل';

  @override
  String get balancePayoutPayPal => 'PayPal (USD)';

  @override
  String get balancePayoutPayPalDetails => 'رسوم الخدمة 1.5% + 0.1 USD | الحد الأدنى للسحب 1 USD | يصل خلال يوم عمل واحد';

  @override
  String get balanceTransactionHistory => 'سجل المعاملات';

  @override
  String get balanceTransactionDetails => 'تفاصيل المعاملة';

  @override
  String get balanceTransactionNotFound => 'المعاملة غير موجودة';

  @override
  String get balanceNoTransactions => 'لا توجد معاملات بعد';

  @override
  String get balanceTabAll => 'الكل';

  @override
  String get balanceTabRevenue => 'الإيرادات';

  @override
  String get balanceTabExpense => 'المصروفات';

  @override
  String get balanceTabPayout => 'المدفوعات';

  @override
  String get balanceTabRefund => 'الاسترداد';

  @override
  String get balanceDetailStatus => 'الحالة';

  @override
  String get balanceStatusCompleted => 'مكتمل';

  @override
  String get balanceDetailType => 'النوع';

  @override
  String get balanceDetailActivityType => 'نوع النشاط';

  @override
  String get balanceDetailPaymentMethod => 'طريقة الدفع';

  @override
  String get balanceDetailCreated => 'تاريخ الإنشاء';

  @override
  String get balanceDetailUpdated => 'تاريخ التحديث';

  @override
  String get balanceDetailTransactionId => 'معرف المعاملة';

  @override
  String get balanceCopied => 'تم النسخ';

  @override
  String get balanceNeedHelp => 'هل تحتاج مساعدة؟ >';

  @override
  String get deleteChatTitle => 'حذف المحادثة';

  @override
  String get deleteChatMessage => 'هل أنت متأكد من رغبتك في حذف هذه المحادثة؟ لا يمكن التراجع عن هذا الإجراء.';

  @override
  String get deleteChatConfirm => 'حذف';

  @override
  String get deleteForEveryone => 'حذف للجميع';

  @override
  String get cameraFlip => 'قلب';

  @override
  String get cameraFlash => 'فلاش';

  @override
  String get cameraSwitch => 'تبديل الكاميرا';

  @override
  String get cameraSpeed => 'السرعة';

  @override
  String get cameraBeauty => 'تجميل';

  @override
  String get cameraFilters => 'فلاتر';

  @override
  String get cameraTimer => 'مؤقت';

  @override
  String get cameraSetCountdown => 'تعيين العد التنازلي';

  @override
  String get cameraStartCountdown => 'بدء العد التنازلي';

  @override
  String get cameraDragRecordingLimit => 'اسحب لتعيين حد التسجيل';

  @override
  String get cameraMusic => 'موسيقى';

  @override
  String get cameraEffects => 'تأثيرات';

  @override
  String get cameraUpload => 'رفع من المكتبة';

  @override
  String get cameraOriginalSound => 'الصوت الأصلي';

  @override
  String get cameraSeconds => 'ثانية';

  @override
  String get cameraRecording => 'جاري التسجيل';

  @override
  String get cameraMusicComingSoon => 'اختيار الموسيقى قريباً.';

  @override
  String get cameraPermissionDenied => 'يلزم السماح بالكاميرا والميكروفون للتسجيل.';

  @override
  String get cameraStarting => 'جاري تشغيل الكاميرا...';

  @override
  String get cameraOpenSettings => 'فتح الإعدادات';

  @override
  String get cameraUnavailable => 'لم يتم العثور على كاميرا على هذا الجهاز.';

  @override
  String cameraInitError(String error) {
    return 'تعذر تشغيل الكاميرا: $error';
  }

  @override
  String cameraCaptureError(String error) {
    return 'فشل الالتقاط: $error';
  }

  @override
  String get cameraCategoryTrending => 'رائج';

  @override
  String get cameraCategoryNew => 'جديد';

  @override
  String get cameraCategoryPortrait => 'بورتريه';

  @override
  String get cameraCategoryVibe => 'أجواء';

  @override
  String get cameraCategoryLandscape => 'مناظر';

  @override
  String get cameraFilterOriginal => 'أصلي';

  @override
  String get cameraFilterWarm => 'دافئ';

  @override
  String get cameraFilterCool => 'بارد';

  @override
  String get cameraFilterSunny => 'مشمس';

  @override
  String get cameraFilterPink => 'وردي';

  @override
  String get cameraFilterMoody => 'داكن';

  @override
  String get cameraFilterBw => 'أبيض وأسود';

  @override
  String get cameraFilterRetro => 'ريترو';

  @override
  String get cameraFilterFlashVintage => 'فلاش';

  @override
  String get cameraFilterBeautyGlow => 'توهج';

  @override
  String get cameraFilterNaturalBright => 'طبيعي';

  @override
  String get cameraFilterGoldenHour => 'ذهبي';

  @override
  String get openCameraStudio => 'فتح الكاميرا';

  @override
  String get cameraModePhoto => 'صورة';

  @override
  String get cameraModeVideo => 'فيديو';

  @override
  String get cameraModeLive => 'مباشر';

  @override
  String get cameraModeText => 'نص';

  @override
  String get cameraAddSound => 'إضافة صوت';

  @override
  String get cameraMuteOriginalSound => 'كتم الصوت الأصلي';

  @override
  String get cameraLayout => 'التخطيط';

  @override
  String get cameraAspectRatio => 'النسبة';

  @override
  String get cameraTabPost => 'منشور';

  @override
  String get cameraTabCreative => 'الإبداع';

  @override
  String get cameraDuration10m => '10 د';

  @override
  String get cameraZoom => 'تكبير';

  @override
  String get cameraZoomOut => 'تصغير';

  @override
  String get cameraZoomIn => 'تكبير';

  @override
  String get cameraGoLive => 'بدء البث';

  @override
  String get cameraLiveTitleHint => 'أضف عنواناً';

  @override
  String get cameraLiveComingSoon => 'البث المباشر قريباً.';

  @override
  String get cameraEffectCrown => 'تاج';

  @override
  String get cameraEffectBunny => 'أرنب';

  @override
  String get cameraEffectSunglasses => 'نظارات';

  @override
  String get cameraEffectDog => 'كلب';

  @override
  String get cameraEffectHearts => 'قلوب';

  @override
  String get cameraEffectSparkle => 'بريق';

  @override
  String get cameraEffectNeon => 'نيون';

  @override
  String get cameraEffectGlitch => 'تشويش';

  @override
  String get cameraEffectGlasses => 'نظارات';

  @override
  String get cameraEffectMoustache => 'شارب';

  @override
  String get cameraEffectBigEyes => 'عيون كبيرة';

  @override
  String get cameraEffectBigLips => 'شفاه كبيرة';

  @override
  String get cameraEffectNose => 'أنف';

  @override
  String get cameraFilterPure => 'نقي';

  @override
  String get cameraFilterBright => 'ساطع';

  @override
  String get cameraFilterClean => 'نظيف';

  @override
  String get cameraFilterSoft => 'ناعم';

  @override
  String get cameraFilterSunset => 'غروب';

  @override
  String get cameraCategoryLife => 'حياة';

  @override
  String get mediaEditorShare => 'مشاركة';

  @override
  String get mediaEditorText => 'نص';

  @override
  String get mediaEditorStickers => 'ملصقات';

  @override
  String get mediaEditorCrop => 'قص';

  @override
  String get mediaEditorEdit => 'تحرير';

  @override
  String get mediaEditorMore => 'المزيد';

  @override
  String get mediaEditorComingSoon => 'قريباً';

  @override
  String get mediaEditorDone => 'تم';

  @override
  String get mediaEditorTrim => 'قص';

  @override
  String get videoEditorSplit => 'تقسيم';

  @override
  String get videoEditorDeleteSegment => 'حذف';

  @override
  String get mediaEditorReset => 'إعادة تعيين';

  @override
  String get mediaEditorDiscard => 'تجاهل';

  @override
  String get mediaEditorSaveDraft => 'حفظ كمسودة';

  @override
  String get mediaEditorContinueEditing => 'متابعة التعديل';

  @override
  String get mediaEditorSendToFriends => 'إرسال إلى الأصدقاء';

  @override
  String get mediaEditorDiscardTitle => 'تجاهل التغييرات؟';

  @override
  String get mediaPhotoEditorFace => 'الجمال';

  @override
  String get mediaPhotoEditorMakeup => 'مكياج';

  @override
  String get mediaPhotoEditorLipstick => 'أحمر شفاه';

  @override
  String get mediaPhotoEditorBlush => 'بلاشر';

  @override
  String get mediaPhotoEditorEyeliner => 'كحل';

  @override
  String get mediaPhotoEditorEyeshadow => 'ظلال';

  @override
  String get mediaPhotoEditorFoundation => 'فاونديشن';

  @override
  String get mediaPhotoEditorContour => 'كنتور';

  @override
  String get mediaPhotoEditorUnderEye => 'تحت العين';

  @override
  String get mediaPhotoEditorBrightenEye => 'تفتيح العين';

  @override
  String get mediaPhotoEditorMagic => 'سحر';

  @override
  String get mediaPhotoEditorOff => 'إيقاف';

  @override
  String get mediaPhotoEditorSmooth => 'تنعيم';

  @override
  String get mediaPhotoEditorSaturation => 'تشبع';

  @override
  String get mediaPhotoEditorBrightness => 'السطوع';

  @override
  String get mediaPhotoEditorContrast => 'التباين';

  @override
  String get mediaPhotoEditorShape => 'الشكل';

  @override
  String get mediaPhotoEditorEyes => 'العيون';

  @override
  String get mediaPhotoEditorTooth => 'الأسنان';

  @override
  String get mediaPhotoEditorMouth => 'الفم';

  @override
  String get mediaPhotoEditorExposure => 'التعريض';

  @override
  String get mediaPhotoEditorWhiteBalance => 'الدفء';

  @override
  String get mediaPhotoEditorHighlights => 'الإضاءات';

  @override
  String get mediaPhotoEditorShadows => 'الظلال';

  @override
  String get mediaPhotoEditorNose => 'الأنف';

  @override
  String get mediaPhotoEditorOn => 'تشغيل';

  @override
  String get mediaTextHint => 'اكتب شيئاً';

  @override
  String get promotePostTitle => 'ترويج المنشور';

  @override
  String get promotionScreenTitle => 'الترويج';

  @override
  String get promotePostAction => 'ترويج';

  @override
  String get promoteGoalTitle => 'اختر هدفك';

  @override
  String get promoteAudienceTitle => 'حدد جمهورك';

  @override
  String get promoteAgeRange => 'الفئة العمرية';

  @override
  String get promoteGeoTarget => 'استهداف الأشخاص القريبين';

  @override
  String get promoteGeoTargetHint => 'استخدم موقعك الحالي للوصول المحلي';

  @override
  String get promoteGeoMapHint => 'اضغط على الخريطة لاختيار منطقة الاستهداف. الافتراضي هو موقعك.';

  @override
  String get promoteGeoUseMyLocation => 'استخدم موقعي';

  @override
  String get promoteGeoPlaceLoading => 'جاري تحديد المكان…';

  @override
  String get promoteGeoCity => 'المدينة';

  @override
  String get promoteGeoRegion => 'المنطقة';

  @override
  String get promoteGeoTown => 'المدينة';

  @override
  String get promoteGeoCountry => 'الدولة';

  @override
  String get promoteGeoContinent => 'القارة';

  @override
  String get promoteBudgetTitle => 'اختر الميزانية';

  @override
  String get promoteProcessing => 'جاري المعالجة...';

  @override
  String promotePostCta(String price) {
    return 'ترويج مقابل $price';
  }

  @override
  String promotePostSuccess(String balance) {
    return 'بدأ الترويج! رصيد المحفظة: $balance';
  }

  @override
  String get promotedBadge => 'مروّج';

  @override
  String get promoteLanguages => 'اللغات';

  @override
  String get promoteInterests => 'الاهتمامات';

  @override
  String promoteRadiusKm(int km) {
    return 'نطاق: $km كم';
  }

  @override
  String get promotePayFailedTitle => 'فشل الدفع';

  @override
  String get promoteRetryPay => 'إعادة محاولة الدفع';

  @override
  String get promoteAudienceCustomize => 'تخصيص الجمهور';

  @override
  String get promoteAudienceAllGenders => 'جميع الأجناس';

  @override
  String get promoteAudienceNearby => 'قريب';

  @override
  String get promoteAudienceGender => 'الجنس';

  @override
  String get promotePostNoCaption => 'بدون وصف';

  @override
  String get promotePopularBadge => 'شائع';

  @override
  String promoteImpressions(int count) {
    return '$count مشاهدة';
  }

  @override
  String get promoteStepGoalHeading => 'ما هو هدفك؟';

  @override
  String get promoteStepGoalSubtitle => 'اختر هدفاً لترويج هذا الفيديو.';

  @override
  String get promoteStepAudienceSubtitle => 'حدد كيف تريد الوصول إلى جمهورك.';

  @override
  String get promoteAudienceDefault => 'جمهور افتراضي';

  @override
  String get promoteAudienceDefaultHint => 'سنختار أفضل جمهور لك';

  @override
  String get promoteAudienceCreateOwn => 'إنشاء جمهورك الخاص';

  @override
  String get promoteStepLocationHeading => 'اختر منطقة الاستهداف';

  @override
  String get promoteStepLocationSubtitle => 'حدّد موقعك واضبط نطاق الوصول للأشخاص القريبين.';

  @override
  String get promoteStepBudgetSubtitle => 'اختر باقة الترويج لحملتك.';

  @override
  String promoteBudgetTotal(String price) {
    return '$price الإجمالي';
  }

  @override
  String promoteEstimatedViews(String min, String max) {
    return '$min – $max';
  }

  @override
  String get promoteEstimatedViewsLabel => 'مشاهدات الفيديو المتوقعة';

  @override
  String get promoteOverviewTitle => 'نظرة عامة';

  @override
  String get promoteOverviewGoal => 'الهدف';

  @override
  String get promoteOverviewAudience => 'الجمهور';

  @override
  String get promoteOverviewLocation => 'الموقع';

  @override
  String get promoteOverviewBudget => 'الميزانية';

  @override
  String get promoteLocationOff => 'استهداف الموقع متوقف';

  @override
  String get promoteLocationPending => 'لم يُحدَّد الموقع';

  @override
  String promoteAudienceNearbyWithRadius(int km) {
    return 'قريب · $km كم';
  }

  @override
  String get promoteLocationModeRegional => 'إقليمياً';

  @override
  String get promoteLocationModeRegionalHint => 'اختر الدولة والمنطقة والمدينة';

  @override
  String get promoteLocationModeMap => 'على الخريطة';

  @override
  String get promoteLocationModeMapHint => 'حدّد موقعك GPS واختر النطاق على الخريطة';

  @override
  String get promoteSelectCountry => 'الدولة';

  @override
  String get promoteSelectCountryHint => 'اختر الدولة';

  @override
  String get promoteSelectRegion => 'المنطقة';

  @override
  String get promoteSelectRegionHint => 'اختر المنطقة';

  @override
  String get promoteSelectTown => 'المدينة';

  @override
  String get promoteSelectTownHint => 'اختر المدينة';

  @override
  String promoteLocationRegionalSummary(String town, String region, String country) {
    return '$town · $region · $country';
  }

  @override
  String get promoteLocationCountryRequired => 'يرجى اختيار الدولة.';

  @override
  String get promoteLocationRegionRequired => 'يرجى اختيار المنطقة.';

  @override
  String get promoteLocationTownRequired => 'يرجى اختيار المدينة.';

  @override
  String get promoteLocationTownCoordinatesRequired => 'لا توجد إحداثيات لهذه المدينة. يرجى اختيار مدينة أخرى.';

  @override
  String get promoteLocationMapRequired => 'يرجى السماح بالموقع أو اختيار نقطة على الخريطة.';

  @override
  String get promoteOverviewSubtotal => 'المجموع الفرعي';

  @override
  String get promoteOverviewTotal => 'الإجمالي';

  @override
  String get promoteNext => 'التالي';

  @override
  String get promotePayStart => 'ادفع وابدأ الترويج';

  @override
  String get promoteQuickPack => 'باقة ترويج جاهزة';

  @override
  String promoteStepOf(int current, int total) {
    return 'الخطوة $current من $total';
  }

  @override
  String get promoteInsightsDashboardTitle => 'المنشورات المروّجة';

  @override
  String get promoteInsightsTitle => 'إحصائيات الترويج';

  @override
  String get promoteInsightsEmptyTitle => 'لا توجد منشورات مروّجة بعد';

  @override
  String get promoteInsightsEmptyHint => 'روّج فيديو من خلاصتك لمشاهدة الأداء هنا.';

  @override
  String get promoteInsightsPerformanceTitle => 'الأداء';

  @override
  String get promoteInsightsPromotedImpressions => 'مرات الظهور المروّجة';

  @override
  String get promoteInsightsFollowersGained => 'متابعون جدد';

  @override
  String get promoteInsightsSpend => 'إنفاق الترويج';

  @override
  String get promoteInsightsEngagementRate => 'معدل التفاعل';

  @override
  String get promoteInsightsShares => 'مشاركات';

  @override
  String get promoteInsightsCostPerImpression => 'التكلفة / ظهور';

  @override
  String get promoteInsightsCostPerView => 'التكلفة / مشاهدة';

  @override
  String get promoteInsightsUniqueViewers => 'مشاهدون فريدون';

  @override
  String get promoteInsightsChartTitle => 'مرات الظهور (آخر 7 أيام)';

  @override
  String get promoteInsightsNoChartData => 'لا توجد بيانات ظهور بعد';

  @override
  String get promoteInsightsCampaignProgress => 'تقدم الحملة';

  @override
  String get promoteInsightsImpressions => 'مرات الظهور';

  @override
  String get promoteInsightsBudget => 'الميزانية';

  @override
  String get promoteInsightsPauseCampaign => 'إيقاف الحملة';

  @override
  String get promoteInsightsResumeCampaign => 'استئناف الحملة';

  @override
  String get promoteInsightsCampaignHistory => 'سجل الحملات';

  @override
  String get promoteInsightsCampaignHistoryHint => 'اضغط على حملة لتصفية الإحصائيات';

  @override
  String get promoteInsightsAllCampaigns => 'جميع الحملات';

  @override
  String get promoteInsightsMultipleCampaigns => 'حملات متعددة';

  @override
  String get promoteInsightsViewInsights => 'عرض الإحصائيات';

  @override
  String get promoteInsightsObjectiveViews => 'مشاهدات الفيديو';

  @override
  String get promoteInsightsObjectiveFollowers => 'متابعون';

  @override
  String get promoteInsightsObjectiveEngagement => 'تفاعل';

  @override
  String get promoteInsightsObjectiveChallenges => 'تحديات';

  @override
  String get promoteInsightsObjectiveProfileVisits => 'زيارات الملف';

  @override
  String get promoteInsightsObjectiveSales => 'مبيعات';

  @override
  String get promoteInsightsStatusActive => 'نشطة';

  @override
  String get promoteInsightsStatusPaused => 'متوقفة';

  @override
  String get promoteInsightsStatusPendingPayment => 'بانتظار الدفع';

  @override
  String get promoteInsightsStatusCompleted => 'مكتملة';

  @override
  String get promoteInsightsStatusCancelled => 'ملغاة';

  @override
  String promoteInsightsCampaignProgressSummary(String percent, String spent) {
    return '$percent · $spent مُنفَق';
  }

  @override
  String get settingsPromotedPosts => 'المنشورات المروّجة';

  @override
  String get soundLabel => 'الصوت';

  @override
  String get soundNoneSelected => 'بدون';

  @override
  String get soundPickerTitle => 'إضافة صوت';

  @override
  String get soundSearchHint => 'ابحث عن أصوات';

  @override
  String get soundTabTrending => 'الرائج';

  @override
  String get soundTabBrowse => 'تصفح';

  @override
  String get soundTabMine => 'أصواتي';

  @override
  String get soundTabHot => 'الأكثر رواجاً';

  @override
  String get soundTabForYou => 'لك';

  @override
  String get soundTabFavorites => 'المفضلة';

  @override
  String get soundTabRecent => 'الأخيرة';

  @override
  String get soundTabAll => 'الكل';

  @override
  String get soundPickerEmpty => 'لا توجد أصوات';

  @override
  String get soundPickFromFiles => 'اختر من الملفات';

  @override
  String get soundTrimTooltip => 'قص';

  @override
  String get soundFavoriteTooltip => 'المفضلة';

  @override
  String soundSecondsSelected(int count) {
    return '$count ث محددة';
  }

  @override
  String get soundUseThis => 'استخدام';

  @override
  String get soundUseThisSound => 'استخدم هذا الصوت';

  @override
  String get soundUseSoundCta => 'استخدام الصوت';

  @override
  String get soundSave => 'حفظ';

  @override
  String get soundSaved => 'تم الحفظ';

  @override
  String get soundAddToStory => 'إضافة إلى القصة';

  @override
  String get soundFindRelatedHint => 'البحث عن محتوى مشابه';

  @override
  String get soundOriginalBadge => 'أصلي';

  @override
  String get soundConfirmSelection => 'استخدام الصوت المحدد';

  @override
  String get soundClearSelection => 'إزالة الموسيقى';

  @override
  String get soundDetailTitle => 'الصوت';

  @override
  String get soundVideosUsing => 'فيديوهات تستخدم هذا الصوت';

  @override
  String get soundNoVideosYet => 'لا توجد فيديوهات بعد';

  @override
  String soundOriginalLink(String name) {
    return 'الأصل: $name';
  }

  @override
  String soundUseCount(int count) {
    return '$count فيديو';
  }

  @override
  String soundUseCountThousands(String count) {
    return '$count ألف فيديو';
  }

  @override
  String soundUseCountMillions(String count) {
    return '$count مليون فيديو';
  }

  @override
  String soundPostsCount(int count) {
    return '$count منشور';
  }

  @override
  String soundPostsCountThousands(String count) {
    return '$count ألف منشور';
  }

  @override
  String soundPostsCountMillions(String count) {
    return '$count مليون منشور';
  }

  @override
  String get interestSelectionTitle => 'اختر اهتماماتك';

  @override
  String get interestSelectionSubtitle => 'اختر بعض الفئات حتى نُخصّص تجربتك.';

  @override
  String get interestSelectionSkip => 'تخطي';

  @override
  String get interestSelectionContinue => 'متابعة';

  @override
  String interestSelectionMinHint(int count) {
    return 'اختر $count اهتمامات على الأقل';
  }

  @override
  String interestSelectionCountHint(int selected, int min) {
    return '$selected/$min مهتم';
  }

  @override
  String get interestSelectionNotInterestedHint => 'اضغط مرة أخرى لتحديد غير مهتم (اختياري).';

  @override
  String get interestSelectionNotInterestedLegend => 'غير مهتم';

  @override
  String get interestSelectionInterestedLegend => 'مهتم';

  @override
  String get interestSelectionSave => 'حفظ';

  @override
  String get settingsInterests => 'الاهتمامات';

  @override
  String get settingsMyProducts => 'منتجاتي';

  @override
  String get shopGoToMyProducts => 'الذهاب إلى منتجاتي';

  @override
  String get shopMakeAuction => 'عرض في البث المباشر';

  @override
  String get shopMyProductsSearchHint => 'ابحث في منتجاتي...';

  @override
  String get shopFilterAll => 'الكل';

  @override
  String get shopNoMatchingProducts => 'لا توجد منتجات مطابقة';

  @override
  String get shopSortQuantityHigh => 'الكمية: الأعلى';

  @override
  String get shopSortQuantityLow => 'الكمية: الأقل';

  @override
  String get shopFilters => 'فلاتر';

  @override
  String get shopMediaType => 'الوسائط';

  @override
  String get shopMediaImage => 'صورة';

  @override
  String get shopMediaVideo => 'فيديو';

  @override
  String get shopMediaCarousel => 'ألبوم';

  @override
  String get shopMinPriceCoins => 'أقل عملات';

  @override
  String get shopMaxPriceCoins => 'أكثر عملات';

  @override
  String get shopApplyFilters => 'تطبيق';

  @override
  String get shopClearFilters => 'مسح';

  @override
  String get retry => 'حاول مرة أخرى';

  @override
  String get seeTranslation => 'عرض الترجمة';

  @override
  String get seeOriginal => 'عرض النص الأصلي';

  @override
  String get translationFailed => 'تعذر الترجمة';

  @override
  String get postLinksTitle => 'الروابط';

  @override
  String get tryEffectAction => 'تجربة التأثير';

  @override
  String get effectsSubtitle => 'المؤثرات';

  @override
  String get templateExportPreparing => 'جارٍ التحضير…';

  @override
  String get templateExportUploading => 'جارٍ الرفع…';

  @override
  String get templateExportUploaded => 'تم الرفع';

  @override
  String get templateExportPreparingSlots => 'جارٍ تجهيز الخانات…';

  @override
  String get templateExportRendering => 'جارٍ تجهيز الفيديو…';

  @override
  String get templateExportAlmostDone => 'أوشك على الانتهاء…';

  @override
  String get templateExportDownloading => 'جارٍ التنزيل…';

  @override
  String get templateExportDone => 'تم';

  @override
  String get templateExportFailed => 'فشل تصدير القالب — حاول مرة أخرى';

  @override
  String get templateCouldNotLoad => 'تعذر تحميل القالب';

  @override
  String get templatePreviewFailed => 'فشل معاينة القالب';

  @override
  String get templateHandoffFailed => 'تعذر تجهيز فيديو القالب';

  @override
  String get templateApplying => 'جارٍ تطبيق القالب…';

  @override
  String get templateAddMediaToPreview => 'أضف وسائط للمعاينة';

  @override
  String get templateNeedMediaFirst => 'التقط أو أضف صورة/فيديو أولاً';

  @override
  String get mediaStudioTemplates => 'القوالب';

  @override
  String get pinToTop => 'تثبيت في الأعلى';

  @override
  String get unpin => 'إلغاء التثبيت';

  @override
  String get pinnedToTopSuccess => 'تم التثبيت في أعلى الملف الشخصي';

  @override
  String get unpinnedSuccess => 'تم إلغاء التثبيت من الملف الشخصي';

  @override
  String get closeFriendsTab => 'الأصدقاء المقربون';

  @override
  String get addCloseFriendsTitle => 'إضافة أصدقاء مقربين';

  @override
  String get addCloseFriendsSubtitle => 'اختر أصدقاء لإضافتهم إلى قائمة الأصدقاء المقربين';

  @override
  String get searchCloseFriendsHint => 'البحث عن أصدقاء مقربين...';

  @override
  String get noCloseFriendsYet => 'لم يتم إضافة أصدقاء مقربين بعد.';

  @override
  String get profileLinksTitle => 'الروابط';

  @override
  String get noLinksAddedYet => 'لم يتم إضافة روابط بعد.';

  @override
  String get accountTypePersonal => 'شخصي';

  @override
  String get accountTypeCreator => 'منشئ محتوى';

  @override
  String get accountTypeBusiness => 'أعمال';

  @override
  String get badgeOfficial => 'رسمي';

  @override
  String get badgeCreator => 'منشئ محتوى';

  @override
  String get addToHighlights => 'إضافة إلى الأبرز';

  @override
  String get newHighlight => 'هايلايت جديد';

  @override
  String get editCover => 'تعديل الغلاف';

  @override
  String get highlightsTitle => 'الأبرز';

  @override
  String get noStoriesInArchive => 'لا توجد قصص في الأرشيف';

  @override
  String get removeFromHighlight => 'إزالة من الأبرز';

  @override
  String get highlightCreated => 'تم إنشاء الهايلايت';

  @override
  String get highlightUpdated => 'تم تحديث الهايلايت';

  @override
  String get chooseFromGallery => 'اختيار من المعرض';

  @override
  String get pasteImageUrl => 'لصق رابط الصورة';

  @override
  String get newHighlightButton => 'جديد';

  @override
  String get aboutThisStory => 'عن هذه القصة';

  @override
  String get editHighlight => 'تعديل الهايلايت';

  @override
  String get deleteHighlight => 'حذف الهايلايت';

  @override
  String get highlightDeleted => 'تم حذف الهايلايت';

  @override
  String get highlightEmptyRemoved => 'هذا الهايلايت فارغ وتم إزالته';

  @override
  String get highlightNameLabel => 'اسم الهايلايت';

  @override
  String get highlightNameHint => 'مثل: سفر، ذكريات';

  @override
  String get coverUpdated => 'تم تحديث الغلاف';

  @override
  String get failedToUploadCover => 'فشل تحميل صورة الغلاف';

  @override
  String get failedToLoadHighlightDetails => 'فشل تحميل تفاصيل الهايلايت';

  @override
  String get failedToAddStoryToHighlight => 'فشل إضافة القصة إلى الهايلايت';

  @override
  String get marketplaceTitle => 'السوق';

  @override
  String get marketplaceLikedProducts => 'المنتجات المفضلة';

  @override
  String get marketplaceNoLikedProducts => 'لا توجد منتجات مفضلة بعد';

  @override
  String get marketplaceTagline => 'اشترِ. امتلك. أعد البيع.';

  @override
  String get marketplaceSearchHint => 'ابحث عن منتجات، علامات تجارية، فئات...';

  @override
  String get marketplaceHeroTitle => 'اشترِ. امتلك. أعد البيع.';

  @override
  String get marketplaceHeroSubtitle => 'اشترِ المنتجات وأعد بيع المشتريات المؤهلة عبر مزادات Bimo-Bond.';

  @override
  String get marketplaceExploreCta => 'استكشف السوق';

  @override
  String get marketplaceCategories => 'الفئات';

  @override
  String get marketplaceRecommended => 'موصى به لك';

  @override
  String get marketplaceEndingSoon => 'مزادات تنتهي قريباً';

  @override
  String get marketplaceNoAuctions => 'لا توجد مزادات نشطة تنتهي قريباً';

  @override
  String get marketplaceLiveAuction => 'مزاد مباشر';

  @override
  String get marketplaceAuctionLabel => 'مزاد';

  @override
  String get marketplaceCurrentBid => 'المزايدة الحالية';

  @override
  String marketplaceBidCount(int count) {
    return '$count مزايدة';
  }

  @override
  String get marketplaceViewAuction => 'عرض المزاد';

  @override
  String get marketplaceFilters => 'الفلاتر';

  @override
  String get marketplaceFilterPrice => 'السعر';

  @override
  String get marketplaceMin => 'الحد الأدنى';

  @override
  String get marketplaceMax => 'الحد الأقصى';

  @override
  String get marketplaceFilterListingType => 'نوع العرض';

  @override
  String get marketplaceInStockOnly => 'متوفر فقط';

  @override
  String get marketplaceClearFilters => 'مسح';

  @override
  String get marketplaceApplyFilters => 'تطبيق';

  @override
  String get marketplaceSortPopular => 'الأكثر شعبية';

  @override
  String get marketplaceSortEndingSoon => 'ينتهي قريباً';

  @override
  String marketplaceProductCount(int count) {
    return '$count منتج';
  }

  @override
  String get marketplaceTabPurchased => 'مشتريات';

  @override
  String get marketplaceTabPending => 'قيد التوصيل';

  @override
  String get marketplaceTabDelivered => 'تم التسليم';

  @override
  String get marketplaceTabAuctioned => 'في المزاد';

  @override
  String get marketplaceTabSold => 'مباع';

  @override
  String get marketplaceNoProducts => 'لا توجد منتجات في هذا القسم';

  @override
  String get marketplacePurchaseConfirmed => 'تم تأكيد الشراء';

  @override
  String get marketplaceDeliveryLabel => 'التوصيل';

  @override
  String get marketplaceDeliveryPending => 'قيد الانتظار';

  @override
  String get marketplaceDeliveryShipped => 'تم الشحن';

  @override
  String get marketplaceDeliveryDelivered => 'تم التسليم';

  @override
  String get marketplaceTrackDelivery => 'تتبع التوصيل';

  @override
  String get marketplaceSellAtAuction => 'بيع في المزاد';

  @override
  String get marketplacePurchasePrice => 'سعر الشراء';

  @override
  String get marketplaceStartingPrice => 'سعر البداية';

  @override
  String get marketplaceReservePrice => 'سعر احتياطي';

  @override
  String get marketplaceBuyNowPrice => 'سعر الشراء الفوري';

  @override
  String get marketplaceAuctionDuration => 'مدة المزاد';

  @override
  String get marketplaceDescription => 'الوصف';

  @override
  String get marketplaceAuctionPreview => 'معاينة المزاد';

  @override
  String get marketplacePublishAuction => 'نشر المزاد';

  @override
  String get marketplaceAuctionPublished => 'تم نشر المزاد';

  @override
  String get marketplacePlaceBid => 'قدّم مزايدة';

  @override
  String get marketplaceYourBid => 'مزايدتك';

  @override
  String get marketplaceConfirmBid => 'تأكيد المزايدة';

  @override
  String get marketplaceEndsIn => 'ينتهي خلال';

  @override
  String get marketplaceBidHistory => 'سجل المزايدات';

  @override
  String get marketplaceNoBidsYet => 'لا توجد مزايدات بعد';

  @override
  String get marketplaceSpecifications => 'المواصفات';

  @override
  String get marketplaceVerifiedProduct => 'منتج موثّق';

  @override
  String get marketplaceSecurePayment => 'دفع آمن';

  @override
  String get marketplaceBuyerProtection => 'حماية المشتري';

  @override
  String get marketplaceDeliveryTracking => 'تتبع التوصيل';

  @override
  String get templateEditorSound => 'الصوت';

  @override
  String get templateEditorText => 'نص';

  @override
  String get templateEditorEffects => 'مؤثرات';

  @override
  String get templateEditorFilters => 'فلاتر';

  @override
  String get templateEditorTransitions => 'انتقالات';

  @override
  String get templateEditorStickers => 'ملصقات';

  @override
  String get templateEditorCopy => 'نسخ';

  @override
  String get templateEditorDelete => 'حذف';

  @override
  String get templateEditorLayers => 'طبقات';

  @override
  String get templateEditorNone => 'بدون';

  @override
  String get templateEditorTrending => 'الرائج';

  @override
  String get templateEditorApply => 'تطبيق';

  @override
  String get templateEditorDefault => 'افتراضي';

  @override
  String get templateEditorPhoto => 'صورة';

  @override
  String get templateEditorVideo => 'فيديو';

  @override
  String get templateEditorFont => 'خط';

  @override
  String get templateEditorAddText => 'إضافة نص';

  @override
  String get templateEditorReplaceText => 'استبدال النص';

  @override
  String get templateEditorReplaceSticker => 'استبدال الملصق';

  @override
  String get templateEditorReplaceFilter => 'استبدال الفلتر';

  @override
  String get templateEditorReplaceEffect => 'استبدال المؤثر';

  @override
  String get templateEditorReplaceTransition => 'استبدال الانتقال';

  @override
  String get templateEditorReplaceMusic => 'استبدال الموسيقى';

  @override
  String templateEditorAddFilterClip(int clip) {
    return 'إضافة فلتر · مقطع $clip';
  }

  @override
  String templateEditorAddEffectClip(int clip) {
    return 'إضافة مؤثر · مقطع $clip';
  }

  @override
  String get templateEditorAddTransition => 'إضافة انتقال';

  @override
  String get templateEditorFilterLayers => 'طبقات الفلاتر';

  @override
  String get templateEditorEffectLayers => 'طبقات المؤثرات';

  @override
  String get templateEditorServerPreview => 'معاينة السيرفر';

  @override
  String get templateEditorContinueWithRender => 'اضغط ← للمتابعة بهذا التصيير';

  @override
  String get templateEditorTypeBelow => 'اكتب بالأسفل…';

  @override
  String get templateEditorTypeCaption => 'اكتب التعليق…';

  @override
  String get templateEditorDragPinchResize => 'اسحب للتحريك · اضغط للتصغير/التكبير';

  @override
  String get templateEditorTapMediaToPlace => 'اضغط على الوسائط للوضع · اسحب للتحريك';

  @override
  String get templateEditorPickStickerBelow => 'اختر ملصقاً من الأسفل';

  @override
  String get templateEditorTapStickerBelow => 'اضغط على ملصق بالأسفل';

  @override
  String get templateEditorDragResizeSticker => 'اسحب للتحريك · اضغط أو ± للتحجيم';

  @override
  String templateEditorMaxFiltersPerClip(int count) {
    return 'حد أقصى $count فلاتر لكل مقطع';
  }

  @override
  String templateEditorMaxEffectsPerClip(int count) {
    return 'حد أقصى $count مؤثرات لكل مقطع';
  }

  @override
  String get templateEditorTransitionsNeedClips => 'الانتقالات تحتاج مقطعين على الأقل';

  @override
  String get templateEditorAddMediaAllSlots => 'أضف وسائط لجميع الخانات قبل التصيير.';

  @override
  String get templateEditorCouldNotRender => 'تعذر التصيير على السيرفر';

  @override
  String get templateEditorExportFailed => 'فشل التصدير';

  @override
  String get templateEditorPresetNone => 'بدون';

  @override
  String get templateEditorPresetCinematic => 'سينمائي';

  @override
  String get templateEditorPresetWarm => 'دافئ';

  @override
  String get templateEditorPresetCool => 'بارد';

  @override
  String get templateEditorPresetVintage => 'كلاسيكي';

  @override
  String get templateEditorPresetVivid => 'حيوي';

  @override
  String get templateEditorPresetFade => 'تلاشي';

  @override
  String get templateEditorPresetBw => 'أبيض وأسود';

  @override
  String get templateEditorPresetZoomIn => 'تكبير';

  @override
  String get templateEditorPresetZoomOut => 'تصغير';

  @override
  String get templateEditorPresetShake => 'اهتزاز';

  @override
  String get templateEditorPresetPulse => 'نبض';

  @override
  String get templateEditorPresetCrossfade => 'تلاشي متقاطع';

  @override
  String get templateEditorPresetFlash => 'وميض';

  @override
  String get templateEditorPresetSlideLeft => 'انزلاق لليسار';

  @override
  String get templateEditorPresetSlideRight => 'انزلاق لليمين';

  @override
  String get templateEditorPresetZoom => 'زوم';

  @override
  String get templateEditorPresetBlur => 'ضبابية';

  @override
  String get templateEditorPresetGlitch => 'خلل';

  @override
  String get templateEditorPresetFilmBurn => 'حرق فيلم';

  @override
  String get templateEditorClipReplace => 'استبدال';

  @override
  String get templateEditorClipVolume => 'الصوت';

  @override
  String get templateEditorClipReduceNoise => 'تقليل الضوضاء';

  @override
  String get templateEditorClipRotate => 'تدوير';

  @override
  String get templateEditorClipBeautify => 'تجميل';

  @override
  String get templateEditorClipAdjust => 'ضبط';

  @override
  String get templateEditorClipOverlay => 'تراكب';

  @override
  String get templateEditorClipReverse => 'عكس';

  @override
  String get templateEditorClipFreeze => 'تجميد';

  @override
  String get templateEditorClipMask => 'قناع';

  @override
  String get templateEditorClipOpacity => 'الشفافية';

  @override
  String get templateEditorClipVoiceEffect => 'تأثير صوت';

  @override
  String get templateEditorClipAnimation => 'رسوم متحركة';

  @override
  String get templateEditorClipCutout => 'قص';

  @override
  String get templateEditorClipBackground => 'خلفية';

  @override
  String get templateEditorClipMagic => 'سحر';

  @override
  String get templateEditorClipComingSoon => 'قريباً';

  @override
  String get livePromotionPromotedLabel => 'مُروَّج';

  @override
  String get lpTitle => 'ترويج البث المباشر';

  @override
  String get lpMine => 'ترويجات البث المباشر';

  @override
  String get lpPreLive => 'ابدأ بثك العام أولاً، ثم افتح المشاركة ← الترويج. معاينة الكاميرا هذه لا تحتوي على بث محفوظ يمكن ترويجه.';

  @override
  String get lpUnavailable => 'ترويج البث غير متاح مؤقتاً. يُرجى المحاولة لاحقاً.';

  @override
  String get lpEligibility => 'يمكن لمضيف بث عام مخطّط أو جارٍ ترويجه بحساب غير خاص وغير محظور. يجب تأكيد أهلية البث أولاً.';

  @override
  String get lpDisabled => 'ترويج البث معطّل حالياً.';

  @override
  String get lpObjective => 'هدفك';

  @override
  String get lpViews => 'مشاهدون أكثر';

  @override
  String get lpFollowers => 'متابعون أكثر';

  @override
  String get lpAudience => 'الجمهور';

  @override
  String get lpAutomatic => 'جمهور تلقائي';

  @override
  String get lpCustomAudience => 'جمهور مخصّص';

  @override
  String get lpAutomaticHint => 'دع الخدمة تختار الأشخاص المرجّح أن يشاهدوا بثك.';

  @override
  String get lpGenders => 'الجنس';

  @override
  String get lpAgeMin => 'العمر الأدنى (اختياري)';

  @override
  String get lpAgeMax => 'العمر الأعلى (اختياري)';

  @override
  String get lpCountries => 'الدول';

  @override
  String get lpLanguages => 'اللغات';

  @override
  String get lpCategories => 'الاهتمامات';

  @override
  String get lpOptionsUnavailable => 'خيارات الجمهور غير متاحة. أعد المحاولة لتحميلها.';

  @override
  String get lpGeo => 'الاستهداف الجغرافي (اختياري)';

  @override
  String get lpLatitude => 'خط العرض';

  @override
  String get lpLongitude => 'خط الطول';

  @override
  String get lpRadius => 'نصف القطر بالكيلومتر';

  @override
  String get lpPickMap => 'اختيار على الخريطة';

  @override
  String get lpClearGeo => 'مسح الموقع';

  @override
  String get lpBudget => 'الميزانية';

  @override
  String get lpCustomBudget => 'ميزانية مخصّصة';

  @override
  String get lpPackage => 'باقة';

  @override
  String get lpPackagesUnavailable => 'الباقات غير متاحة. يمكنك إعداد ميزانية مخصّصة.';

  @override
  String get lpCoins => 'عملات';

  @override
  String get lpDuration => 'المدة بالأيام';

  @override
  String get lpEstimates => 'النتائج التقديرية';

  @override
  String get lpEstimateHint => 'التقديرات غير مضمونة. يعتمد الوصول الفعلي على بثك والجمهور.';

  @override
  String get lpNoEstimates => 'التقديرات غير متاحة.';

  @override
  String get lpCreate => 'إنشاء حملة';

  @override
  String get lpCreateHint => 'إنشاء الحملة لا يدفع تكلفتها. ستراجع الدفع وتؤكده في خطوة منفصلة.';

  @override
  String get lpSave => 'حفظ التغييرات';

  @override
  String get lpEdit => 'تعديل الحملة';

  @override
  String get lpPay => 'مراجعة الدفع';

  @override
  String get lpConfirmPay => 'تأكيد الدفع';

  @override
  String get lpCost => 'تكلفة الحملة';

  @override
  String get lpBalance => 'رصيد العملات الحالي';

  @override
  String get lpUnknown => 'غير متاح';

  @override
  String get lpRetry => 'إعادة المحاولة';

  @override
  String get lpRefresh => 'تحديث';

  @override
  String get lpCancel => 'إلغاء الحملة';

  @override
  String get lpCancelHint => 'هل تريد إلغاء الحملة؟ يعيد الخادم العملات المدفوعة غير المستخدمة. قد يستغرق ظهور الرصيد المحدّث بعض الوقت.';

  @override
  String get lpBack => 'رجوع';

  @override
  String get lpPause => 'إيقاف مؤقت';

  @override
  String get lpResume => 'استئناف';

  @override
  String get lpEmpty => 'لا توجد حملات ترويج بث بعد';

  @override
  String get lpEmptyHint => 'افتح المشاركة ← الترويج أثناء استضافة بث عام.';

  @override
  String get lpLoadMore => 'تحميل المزيد';

  @override
  String get lpPending => 'بانتظار الدفع';

  @override
  String get lpActive => 'نشطة';

  @override
  String get lpPaused => 'متوقفة مؤقتاً';

  @override
  String get lpCompleted => 'مكتملة';

  @override
  String get lpCancelled => 'ملغاة';

  @override
  String get lpUnknownStatus => 'الحالة غير معروفة — حدّث الصفحة';

  @override
  String get lpImpressions => 'مرات الظهور';

  @override
  String get lpSpend => 'العملات المصروفة';

  @override
  String get lpRemaining => 'العملات المتبقية';

  @override
  String get lpPaymentUnknown => 'جارٍ التحقق من الدفع. حدّث الحملة والرصيد قبل أي إجراء آخر. لا تدفع مجدداً ما دامت النتيجة غير مؤكدة.';

  @override
  String get lpCleanup => 'انتهى البث. يجري تحديث حالة الحملة وردّ الرصيد غير المستخدم إن وُجد.';

  @override
  String get lpInsufficient => 'رصيد العملات غير كافٍ. اشحن رصيدك ثم حدّثه قبل تأكيد الدفع.';

  @override
  String get lpTopUp => 'شحن العملات';

  @override
  String get lpValidation => 'تحقّق من اختيار ميزانية واحدة بحد أدنى ٥ عملات، والمدة (١ أو ٣ أو ٧ أو ١٤ يوماً)، وترتيب الأعمار، وإدخال إحداثيات صحيحة كاملة مع نصف قطر موجب.';

  @override
  String get lpInteger => 'أدخل عدداً صحيحاً.';

  @override
  String get lpNumber => 'أدخل رقماً صالحاً ومحدوداً.';

  @override
  String get lpClose => 'إغلاق الترويج';

  @override
  String get liveMetricUnavailable => 'غير متاح';

  @override
  String get liveSummaryTitle => 'تقرير البث';

  @override
  String get liveSummaryEmpty => 'تقرير البث غير متاح.';

  @override
  String get liveSummaryDuration => 'المدة (ثانية)';

  @override
  String get liveSummaryPeak => 'أعلى عدد مشاهدين';

  @override
  String get liveSummarySessions => 'جلسات المشاهدة';

  @override
  String get liveSummaryLikes => 'الإعجابات';

  @override
  String get liveSummaryComments => 'التعليقات';

  @override
  String get liveSummaryCoins => 'العملات المكتسبة';

  @override
  String get liveSummaryGifters => 'أبرز مرسلي الهدايا';

  @override
  String get liveSummaryUnique => 'المشاهدون الفريدون';

  @override
  String get liveSummaryWatch => 'وقت المشاهدة (ثانية)';

  @override
  String get liveSummaryAverage => 'متوسط المشاهدة (ثانية)';

  @override
  String get liveSummaryFollowers => 'المتابعون الجدد';

  @override
  String get liveSummaryShares => 'المشاركات';

  @override
  String get liveSummaryOrders => 'طلبات المتجر';

  @override
  String get liveSummaryRevenue => 'إيرادات المتجر (عملات)';

  @override
  String get liveSummaryTraffic => 'مصادر الزيارات';

  @override
  String get liveGiftGoalLabel => 'هدف الهدايا';

  @override
  String get liveFanClubPriceUnavailable => 'أسعار شرائح الاشتراك غير مؤكدة حاليًا. الانضمام غير متاح.';

  @override
  String get liveDiscoveryForYou => 'لك';

  @override
  String get liveDiscoveryFollowing => 'المتابَعون';

  @override
  String get liveDiscoveryNearby => 'بالقرب منك';

  @override
  String get liveDiscoveryAudio => 'الصوت';

  @override
  String get liveDiscoveryFilter => 'تصفية البثوث';

  @override
  String get liveDiscoveryTopic => 'الموضوع';

  @override
  String get liveDiscoveryCategory => 'معرّف التصنيف';

  @override
  String get liveLocationUnavailable => 'فعّل خدمة الموقع واسمح بالوصول إليه لعرض البثوث القريبة.';

  @override
  String get liveGalleryReorder => 'اسحب لتغيير الترتيب';

  @override
  String get liveLeagueTitle => 'دوري المضيف';

  @override
  String get liveLeagueProgress => 'التقدم نحو الدوري التالي';

  @override
  String get liveReplayTitle => 'الإعادة والقصاصات';

  @override
  String get liveRecordingStatus => 'حالة التسجيل';

  @override
  String get liveReplayStatus => 'حالة الإعادة';

  @override
  String get liveReplayUnavailable => 'يتطلب التشغيل استجابة مؤكدة من خدمة الإعادة.';

  @override
  String get liveCouponCode => 'رمز الكوبون';

  @override
  String get liveApplyCoupon => 'تطبيق الكوبون';

  @override
  String get liveDeal => 'عرض البث';

  @override
  String get liveDealPrice => 'سعر الفلاش (عملات)';

  @override
  String get liveDealEnd => 'وقت انتهاء الفلاش (ISO)';

  @override
  String get liveDealDiscount => 'خصم الكوبون (عملات)';

  @override
  String get liveDealSave => 'حفظ العرض';

  @override
  String get liveDealSold => 'المباع';

  @override
  String get liveCouponAvailable => 'يتوفر كوبون';

  @override
  String get liveTicketEnabled => 'دخول بتذكرة';

  @override
  String get liveTicketPrice => 'سعر التذكرة (عملات)';

  @override
  String liveTicketBuy(int coins) {
    return 'شراء التذكرة مقابل $coins عملة';
  }

  @override
  String get liveTicketRequiredDetail => 'يتطلب هذا البث تذكرة للدخول.';

  @override
  String get liveTicketUnavailable => 'تعذر التحقق من إمكانية الدخول. حدّث الحالة.';

  @override
  String get livePaymentUnresolved => 'دفعتك بانتظار التأكيد. تحقق من حالتها قبل الدفع مرة أخرى.';

  @override
  String get liveTicketChecking => 'جارٍ التحقق من إمكانية الدخول…';

  @override
  String get liveTicketTitle => 'الدخول إلى البث';

  @override
  String get liveTicketRefresh => 'التحقق من حالة التذكرة';

  @override
  String get liveEntryBack => 'رجوع';

  @override
  String get shopCouponLabel => 'كوبون البث';

  @override
  String get shopCouponHint => 'أدخل رمز الكوبون';

  @override
  String get shopCouponApply => 'تطبيق';

  @override
  String get shopPreviewChanged => 'تغيرت تفاصيل الطلب. راجع المجموع المحدّث قبل الدفع.';

  @override
  String get liveFanClubTiers => 'شرائح العضوية';

  @override
  String liveFanClubJoinTier(String tier) {
    return 'اشترك في $tier';
  }

  @override
  String liveFanClubPriceCoins(int coins) {
    return '$coins عملة لكل 30 يومًا';
  }

  @override
  String get liveFanClubCurrentTier => 'عضويتك الحالية';

  @override
  String liveFanClubLoyalty(String badge) {
    return 'الولاء: $badge';
  }

  @override
  String get liveFanClubEmotes => 'ملصقات النادي';

  @override
  String liveFanClubEmoteLocked(String tier) {
    return 'يفتح مع $tier';
  }

  @override
  String get liveFanClubConfirmTitle => 'تأكيد الاشتراك';

  @override
  String liveFanClubConfirmBody(int coins, String tier) {
    return 'سيتم خصم $coins عملة من محفظتك مقابل عضوية $tier لمدة 30 يومًا.';
  }

  @override
  String get liveFanClubConfirmAction => 'خصم ومتابعة';

  @override
  String get liveFanClubAwaitingConfirmation => 'اشتراك سابق لم يتأكد بعد. تحقق من عضويتك قبل محاولة جديدة.';

  @override
  String get liveFanClubHostSettings => 'إعدادات النادي';

  @override
  String get liveFanClubHostPrice => 'سعر العضوية الأساسية (عملات)';

  @override
  String get liveFanClubHostName => 'اسم النادي';

  @override
  String get liveFanClubHostEnabled => 'تفعيل نادي المعجبين';

  @override
  String get liveFanClubAddEmote => 'إضافة ملصق';

  @override
  String get liveFanClubEmoteCode => 'رمز الملصق';

  @override
  String get liveFanClubEmoteImage => 'رابط الصورة';

  @override
  String get liveFanClubEmoteMinTier => 'أقل شريحة';

  @override
  String get liveFanClubSave => 'حفظ';

  @override
  String get liveReplayRefresh => 'تحديث';

  @override
  String liveReplayViews(int count) {
    return 'عدد المشاهدات: $count';
  }

  @override
  String liveReplayExpires(String date) {
    return 'تنتهي في $date';
  }

  @override
  String get liveReplayPreparing => 'التسجيل قيد التجهيز، والإعادة غير جاهزة بعد.';

  @override
  String get liveReplayGone => 'لم تعد الإعادة متاحة.';

  @override
  String get liveReplayPublish => 'نشر رابط الإعادة';

  @override
  String get liveReplayRemove => 'حذف الإعادة';

  @override
  String get liveReplayUrl => 'رابط ملف الإعادة';

  @override
  String get liveClipSelect => 'اختر بداية ونهاية المقطع';

  @override
  String liveClipRange(String start, String end, int seconds) {
    return 'من $start إلى $end ($seconds ثانية)';
  }

  @override
  String get liveClipPreview => 'معاينة الاختيار';

  @override
  String get liveClipCreate => 'إنشاء مقطع';

  @override
  String get liveClipPublish => 'نشر المقطع';

  @override
  String get liveClipTitle => 'عنوان المقطع';

  @override
  String get liveClipDescription => 'وصف المنشور';

  @override
  String get liveClipsTitle => 'المقاطع';

  @override
  String get liveClipsEmpty => 'لا توجد مقاطع بعد.';

  @override
  String get liveClipOpenPost => 'فتح المنشور';

  @override
  String get liveGamesTitle => 'الألعاب الرسمية';

  @override
  String get liveGamesStart => 'بدء لعبة';

  @override
  String get liveGamesActiveOne => 'توجد لعبة نشطة بالفعل.';

  @override
  String get liveGamesNone => 'لا توجد لعبة الآن.';

  @override
  String get liveGameQuiz => 'أسئلة سريعة';

  @override
  String get liveGameWheel => 'عجلة الجوائز';

  @override
  String get liveGameLuckyDraw => 'السحب المحظوظ';

  @override
  String get liveGameQuestion => 'السؤال';

  @override
  String liveGameOption(int index) {
    return 'خيار $index';
  }

  @override
  String get liveGameCorrectOption => 'الإجابة الصحيحة';

  @override
  String liveGamePrize(int index) {
    return 'جائزة $index';
  }

  @override
  String get liveGameAddOption => 'إضافة خيار';

  @override
  String get liveGameAddPrize => 'إضافة جائزة';

  @override
  String get liveGameEnd => 'إنهاء اللعبة';

  @override
  String get liveGamePlay => 'شارك';

  @override
  String get liveGamePlayed => 'شاركت بالفعل';

  @override
  String get liveGameAnswerHidden => 'تظهر الإجابة بعد إنهاء المضيف للعبة.';

  @override
  String get liveGameWaitingResult => 'بانتظار نتيجة السيرفر…';

  @override
  String liveGameWinner(String name) {
    return 'الفائز: $name';
  }

  @override
  String liveGameResultPrize(String prize) {
    return 'الجائزة: $prize';
  }

  @override
  String liveGamePlays(int count) {
    return 'عدد المشاركات: $count';
  }

  @override
  String get liveGameUnsupported => 'نوع لعبة غير مدعوم في هذا الإصدار.';

  @override
  String get shopLiveDealTitle => 'عرض خاص بالبث';

  @override
  String get shopLiveDealFlashPrice => 'سعر الفلاش (عملات)';

  @override
  String get shopLiveDealFlashEnds => 'ينتهي بعد (دقائق)';

  @override
  String get shopLiveDealCouponCode => 'رمز الكوبون';

  @override
  String get shopLiveDealCouponOff => 'خصم الكوبون (عملات)';

  @override
  String get shopLiveDealSave => 'حفظ العرض';

  @override
  String get shopLiveDealClearFlash => 'إلغاء عرض الفلاش';

  @override
  String get shopLiveDealClearCoupon => 'إلغاء الكوبون';

  @override
  String get shopLiveDealNote => 'السعر النهائي يحسبه السيرفر ويظهر في معاينة الدفع.';

  @override
  String get shopLiveDealNeedsBoth => 'أدخل السعر ومدة الانتهاء معًا، والرمز والخصم معًا.';

  @override
  String get shopLiveDealSaved => 'تم تحديث العرض';
}
