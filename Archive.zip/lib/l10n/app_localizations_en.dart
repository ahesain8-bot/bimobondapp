// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Bimobond App';

  @override
  String get helloWorld => 'Hello World!';

  @override
  String get loginTitle => 'Login';

  @override
  String get loginScreenTitle => 'Log in to BimoBond';

  @override
  String get loginWithPhone => 'Use phone number';

  @override
  String get loginWithEmailUsername => 'Use email or username';

  @override
  String get loginEmailUsernameHint => 'Email or username';

  @override
  String get continueWithGoogle => 'Continue with Google';

  @override
  String get continueWithApple => 'Continue with Apple';

  @override
  String get signInSubtitle => 'Sign in to continue';

  @override
  String get emailLabel => 'Email';

  @override
  String get passwordLabel => 'Password';

  @override
  String get loginButton => 'Login';

  @override
  String get dontHaveAccount => 'Don\'t have an account? ';

  @override
  String get signUp => 'Sign Up';

  @override
  String get orDivider => 'OR';

  @override
  String get continueAsGuest => 'Continue as Guest';

  @override
  String get continueWith => 'Continue with';

  @override
  String get notificationErrorTitle => 'Error';

  @override
  String get notificationSuccessTitle => 'Success';

  @override
  String get signUpTitle => 'Create Account';

  @override
  String get signUpScreenTitle => 'Sign up to BimoBond';

  @override
  String get signUpSubtitle => 'Enter your details to create a new account';

  @override
  String get fullNameLabel => 'Full Name';

  @override
  String get usernameLabel => 'Username';

  @override
  String get countryLabel => 'Country';

  @override
  String get nationalityLabel => 'Nationality';

  @override
  String get ageLabel => 'Age';

  @override
  String get addressLabel => 'Address';

  @override
  String get phoneLabel => 'Phone';

  @override
  String get mobileNumberLabel => 'Mobile Number';

  @override
  String get confirmPasswordLabel => 'Confirm Password';

  @override
  String get createAccountBtn => 'Create Account';

  @override
  String get alreadyHaveAccount => 'Already have an account? ';

  @override
  String get phoneLoginTitle => 'Phone Login';

  @override
  String get phoneLoginSubtitle => 'Enter your phone number to receive a verification code';

  @override
  String get phoneLoginUsageNote => 'Your phone number may be used to connect you to people you may know, improve ads, and more depending on your settings.';

  @override
  String get emailLoginUsageNote => 'Your email may be used to connect you to people you may know, improve ads, and more depending on your settings.';

  @override
  String get phoneHint => '+20 123 456 7890';

  @override
  String get termsAndConditionsPart1 => 'By continuing, you agree to our ';

  @override
  String get termsAndConditionsPart2 => 'Terms & Conditions';

  @override
  String get loginLegalNotePart1 => 'By continuing, you agree to our ';

  @override
  String get loginTermsOfService => 'Terms of Service';

  @override
  String get loginLegalNotePart2 => ' and confirm that you have read our ';

  @override
  String get loginPrivacyPolicy => 'Privacy Policy';

  @override
  String get verifyPhoneTitle => 'Verify Phone';

  @override
  String get emailVerificationTitle => 'Verify Your Email';

  @override
  String emailVerificationSent(Object email) {
    return 'We sent a verification link to $email.';
  }

  @override
  String get emailVerificationContinue => 'Open your email and verify your account before continuing.';

  @override
  String get emailVerificationButton => 'I have verified my email';

  @override
  String get emailVerificationResendError => 'Unable to resend verification email. Please sign in again.';

  @override
  String get emailVerificationResendSuccess => 'Verification email resent. Check your inbox and spam folder.';

  @override
  String get emailVerificationResendFailed => 'Failed to resend verification email. Please try again.';

  @override
  String get emailVerificationStatusError => 'Unable to verify email status. Please sign in again.';

  @override
  String get emailVerificationNotVerified => 'Email not verified yet. Please open your email and verify your account.';

  @override
  String get emailVerificationCheckFailed => 'Could not check verification status. Please try again.';

  @override
  String get emailVerificationResendButton => 'Resend verification email';

  @override
  String get emailVerificationResending => 'Resending...';

  @override
  String get enterCodeSentTo => 'Enter the 6-digit code sent to';

  @override
  String get verificationCodeLabel => 'Verification Code';

  @override
  String get verifyAndLoginBtn => 'Verify & Login';

  @override
  String get didNotReceiveCode => 'Didn\'t receive a code? ';

  @override
  String get resendCode => 'Resend';

  @override
  String resendCodeIn(int seconds) {
    return 'Resend in ${seconds}s';
  }

  @override
  String get back => 'Back';

  @override
  String get continueAction => 'Continue';

  @override
  String get emailRequired => 'Email is required';

  @override
  String get invalidEmail => 'Enter a valid email';

  @override
  String get passwordRequired => 'Password is required';

  @override
  String get passwordTooShort => 'Password must be at least 6 characters';

  @override
  String get passwordSignUpTooShort => 'Password must be at least 8 characters';

  @override
  String get passwordTooLong => 'Password must be at most 20 characters';

  @override
  String get passwordsDoNotMatch => 'Passwords do not match';

  @override
  String get forgotPassword => 'Forgot Password?';

  @override
  String get forgotPasswordTitle => 'Forgot Password';

  @override
  String get forgotPasswordSubtitle => 'Enter your email and we\'ll send a 6-digit code to reset your password.';

  @override
  String get forgotPasswordButton => 'Send Reset Code';

  @override
  String get forgotPasswordSuccess => 'If an account exists for that email, a reset code was sent.';

  @override
  String get forgotPasswordFailed => 'Failed to send reset code. Please try again.';

  @override
  String get forgotPasswordUserNotFound => 'No account found with this email address.';

  @override
  String get resetPasswordTitle => 'Reset Password';

  @override
  String get resetPasswordSubtitle => 'Enter the 6-digit code sent to';

  @override
  String get resetPasswordButton => 'Reset Password';

  @override
  String get resetPasswordSuccess => 'Password reset successfully. Please sign in.';

  @override
  String get newPasswordLabel => 'New Password';

  @override
  String get otpSentSuccess => 'Verification code sent.';

  @override
  String get otpVerifiedSuccess => 'Email verified successfully.';

  @override
  String get loginFailed => 'Login failed. Please try again.';

  @override
  String get verificationFailed => 'Verification failed';

  @override
  String get invalidOtpCode => 'Invalid OTP code';

  @override
  String get googleLoginFailed => 'Google login failed';

  @override
  String get googleLoginSheetTitle => 'Sign in with Google';

  @override
  String get googleLoginSheetSubtitle => 'Use your Google account to sign in quickly and securely.';

  @override
  String get googleLoginContinue => 'Continue with Google';

  @override
  String get updateProfileFailed => 'Failed to update profile';

  @override
  String get signupFailed => 'Signup failed. Please try again.';

  @override
  String get profileUpdatedSuccessfully => 'Profile updated successfully!';

  @override
  String get enterSixDigitCode => 'Please enter a 6-digit code';

  @override
  String get postAdded => 'Post added!';

  @override
  String get addPost => 'Add Post';

  @override
  String get postButton => 'Post';

  @override
  String get loginSuccess => 'Login successful!';

  @override
  String get signupSuccess => 'Signup successful! Please check your email to verify your account.';

  @override
  String get signUpWithEmailPassword => 'Sign up with Email and Password';

  @override
  String get signUpEmailStepTitle => 'What\'s your email?';

  @override
  String get signUpNameStepTitle => 'What\'s your name?';

  @override
  String get signUpPasswordStepTitle => 'Create a password';

  @override
  String get nextAction => 'Next';

  @override
  String get passwordStrengthLabel => 'Password strength';

  @override
  String get passwordStrengthWeak => 'Weak';

  @override
  String get passwordStrengthFair => 'Fair';

  @override
  String get passwordStrengthGood => 'Good';

  @override
  String get passwordStrengthStrong => 'Strong';

  @override
  String get passwordStrengthHint => 'Your password must have 8 to 20 characters and include a mix of letters, numbers, and symbols.';

  @override
  String get passwordReqLength => '8 to 20 characters';

  @override
  String get passwordReqLetter => '1 letter';

  @override
  String get passwordReqNumber => '1 number';

  @override
  String get passwordReqSpecialChar => '1 special character (e.g. ! @ # \$ % & *)';

  @override
  String get passwordRequirementsNotMet => 'Password must meet all requirements';

  @override
  String get following => 'Following';

  @override
  String get followers => 'Followers';

  @override
  String get connectionsTitle => 'Connections';

  @override
  String get connectionsEmptyFollowers => 'No followers yet';

  @override
  String get connectionsEmptyFollowing => 'Not following anyone yet';

  @override
  String get connectionsEmptyFriends => 'No friends yet';

  @override
  String get connectionsFollowBack => 'Follow back';

  @override
  String get profileMessageButton => 'Message';

  @override
  String get likes => 'Likes';

  @override
  String get profilePostsTab => 'Posts';

  @override
  String get profilePostAuction => 'Auction';

  @override
  String get profileLikesTab => 'Likes';

  @override
  String get noPostsYet => 'No posts yet';

  @override
  String get noLikedPosts => 'No liked posts';

  @override
  String get noSavedPosts => 'No saved posts';

  @override
  String get noRepostedPosts => 'No reposts yet';

  @override
  String get noOnlyMePosts => 'No only me posts yet';

  @override
  String get repostTitle => 'Repost';

  @override
  String get repostSubtitle => 'Share this post to your profile';

  @override
  String get repostAction => 'Repost';

  @override
  String get repostUndo => 'Undo repost';

  @override
  String get savePost => 'Save post';

  @override
  String get unsavePost => 'Remove from saved';

  @override
  String get repostQuoteHint => 'Add a comment (optional)';

  @override
  String get repostComposeTitle => 'Add to your repost';

  @override
  String get repostComposeHint => 'Say something...';

  @override
  String get repostComposeAdd => 'Add';

  @override
  String get postRepostersHeader => 'Reposts';

  @override
  String get repostSuccess => 'Reposted';

  @override
  String get repostRemoved => 'Repost removed';

  @override
  String get cannotRepostOwnPost => 'You can\'t repost your own post';

  @override
  String repostCountLabel(int count) {
    return '$count reposts';
  }

  @override
  String repostedByUser(Object name) {
    return '$name reposted';
  }

  @override
  String postRepostersTitle(int count) {
    return 'Reposts · $count';
  }

  @override
  String get postRepostersEmpty => 'No reposts yet';

  @override
  String get profileRepostsTab => 'Reposts';

  @override
  String get editProfile => 'Edit profile';

  @override
  String get noBio => 'No bio yet.';

  @override
  String get profileAvatarViewPhoto => 'Open profile photo';

  @override
  String get profileAvatarViewStory => 'View story';

  @override
  String get profileAvatarNoPhoto => 'No profile photo';

  @override
  String get story => 'Story';

  @override
  String get addStoryTitle => 'Add story';

  @override
  String get shareStoryButton => 'Share story';

  @override
  String get storyAddText => 'Text';

  @override
  String get storyTextDone => 'Done';

  @override
  String get storyCaptionHint => 'Add a caption (optional)';

  @override
  String get storyLoadMore => 'Load more';

  @override
  String get storyShowLess => 'Show less';

  @override
  String storyPickMediaError(String error) {
    return 'Could not pick media: $error';
  }

  @override
  String get storyExpired => 'Story expired';

  @override
  String storyTimeMinutesAgo(int count) {
    return '${count}m ago';
  }

  @override
  String storyTimeHoursAgo(int count) {
    return '${count}h ago';
  }

  @override
  String storyTimeDaysAgo(int count) {
    return '${count}d ago';
  }

  @override
  String get storyAddCommentHint => 'Add comment...';

  @override
  String get storySendMessageHint => 'Write a message...';

  @override
  String get storySendMessageTitle => 'Reply with a message';

  @override
  String get storyViewersTitle => 'Viewers';

  @override
  String get storyViewerUnknown => 'Viewer';

  @override
  String get storyMessagesTitle => 'Messages on this story';

  @override
  String get storyMessagesEmpty => 'No messages on this story yet';

  @override
  String get storyMessageSendFailed => 'Could not send message. Try again.';

  @override
  String storyMessageSent(String name) {
    return 'Message sent to $name';
  }

  @override
  String get storyPreviewLabel => 'Story';

  @override
  String get postPreviewLabel => 'Post';

  @override
  String get storyMessageOnStory => 'Replied to your story';

  @override
  String get storyMessageOnPost => 'Replied to your post';

  @override
  String get personalInfo => 'Personal Info';

  @override
  String get genderLabel => 'Gender';

  @override
  String get male => 'Male';

  @override
  String get female => 'Female';

  @override
  String get selectCountry => 'Select Country';

  @override
  String get changeProfilePhoto => 'Change profile photo';

  @override
  String get takePhoto => 'Take Photo';

  @override
  String get importFromLibrary => 'Import';

  @override
  String get uploadFromLibrary => 'Upload from library';

  @override
  String get removeCurrentPhoto => 'Remove current photo';

  @override
  String get changePhoto => 'Change photo';

  @override
  String get enterYourName => 'Enter your name';

  @override
  String get enterUsername => 'Enter username';

  @override
  String get addBioToProfile => 'Add a bio to your profile';

  @override
  String get selectGender => 'Select gender';

  @override
  String get instagramProfileUrl => 'Username or profile link';

  @override
  String get youtubeChannelUrl => 'Username or channel link';

  @override
  String get egypt => 'Egypt';

  @override
  String get saudiArabia => 'Saudi Arabia';

  @override
  String get uae => 'UAE';

  @override
  String get usa => 'USA';

  @override
  String get uk => 'UK';

  @override
  String get kuwait => 'Kuwait';

  @override
  String get qatar => 'Qatar';

  @override
  String get bioLabel => 'Bio';

  @override
  String get instagramLabel => 'Instagram';

  @override
  String get youtubeLabel => 'YouTube';

  @override
  String fieldIsRequired(String field) {
    return '$field is required';
  }

  @override
  String get edit => 'Edit';

  @override
  String get feedFollowingTab => 'Following';

  @override
  String get feedForYou => 'For You';

  @override
  String get feedLive => 'Live';

  @override
  String get feedShop => 'Shop';

  @override
  String get shopTitle => 'Shop';

  @override
  String get shopFeatured => 'Featured';

  @override
  String get shopFlashDeals => 'Flash Deals';

  @override
  String get shopForYou => 'For You';

  @override
  String get shopCart => 'Cart';

  @override
  String get shopCheckout => 'Checkout';

  @override
  String get shopOrders => 'Orders';

  @override
  String get shopBuyNow => 'Buy Now';

  @override
  String get shopAddToCart => 'Add to Cart';

  @override
  String get shopEmpty => 'No products found';

  @override
  String get shopRetry => 'Retry';

  @override
  String get shopAllCategories => 'All';

  @override
  String get shopProducts => 'Products';

  @override
  String get shopNoProductsYet => 'No products yet';

  @override
  String get shopEmptyHint => 'Try a different category or search term.';

  @override
  String get shopSeeAll => 'See all';

  @override
  String get shopSearchHint => 'Search products...';

  @override
  String get shopSearchForProducts => 'Search for products';

  @override
  String get shopRecentSearches => 'Recent';

  @override
  String shopNoResultsFor(String query) {
    return 'No results for \"$query\"';
  }

  @override
  String get shopSort => 'Sort';

  @override
  String get shopSortNewest => 'Newest';

  @override
  String get shopSortOldest => 'Oldest';

  @override
  String get shopSortPriceLow => 'Price: Low';

  @override
  String get shopSortPriceHigh => 'Price: High';

  @override
  String get shopSortTitleAsc => 'Title A-Z';

  @override
  String get shopSortTitleDesc => 'Title Z-A';

  @override
  String get shopCartEmpty => 'Your cart is empty';

  @override
  String get shopSubtotal => 'Subtotal';

  @override
  String get shopCommission => 'Commission';

  @override
  String get shopCheckoutAction => 'Checkout';

  @override
  String get shopShippingDetails => 'Shipping Details';

  @override
  String get shopPayWithCoins => 'Pay with coins';

  @override
  String get shopFirstName => 'First name';

  @override
  String get shopFirstNameHint => 'Enter your first name';

  @override
  String get shopLastName => 'Last name';

  @override
  String get shopLastNameHint => 'Enter your last name';

  @override
  String get shopStreet => 'Street';

  @override
  String get shopStreetHint => 'Enter your street';

  @override
  String get shopStreetNo => 'Street no.';

  @override
  String get shopStreetNoHint => 'No.';

  @override
  String get shopApartmentNo => 'Apartment no.';

  @override
  String get shopApartmentNoHint => 'Apt.';

  @override
  String get shopCity => 'City';

  @override
  String get shopCityHint => 'Enter your city';

  @override
  String get shopPostcode => 'Postcode';

  @override
  String get shopPostcodeHint => 'Enter your postcode';

  @override
  String get shopCountry => 'Country';

  @override
  String get shopCountryHint => 'Enter your country';

  @override
  String get shopPhone => 'Phone';

  @override
  String get shopPhoneHint => 'Enter your phone';

  @override
  String get shopFieldRequired => 'Required';

  @override
  String get shopYourBalance => 'Your balance';

  @override
  String get shopDueNow => 'Due now';

  @override
  String get shopBuyCoins => 'Buy coins';

  @override
  String shopPayCoinsAmount(int count) {
    return 'Pay $count coins';
  }

  @override
  String shopNeedMoreCoins(int count) {
    return 'You need $count more coins.';
  }

  @override
  String get shopNotEnoughCoins => 'Not enough coins. Buy more to continue.';

  @override
  String shopCoinsLabel(int count) {
    return '$count coins';
  }

  @override
  String get shopProductNotFound => 'Product not found';

  @override
  String get shopAddFavorite => 'Add favorite';

  @override
  String get shopRemoveFavorite => 'Remove favorite';

  @override
  String get shopShare => 'Share';

  @override
  String get shopReadMore => 'Read more';

  @override
  String get shopShowLess => 'Show less';

  @override
  String get shopVariants => 'Variants';

  @override
  String get shopQuantity => 'Quantity';

  @override
  String get shopOutOfStock => 'Out of stock';

  @override
  String get shopSelectVariantFirst => 'Select a variant first';

  @override
  String get shopAddedToCart => 'Added to cart';

  @override
  String get shopLiveBadge => 'LIVE';

  @override
  String get shopBestPrice => 'Best price';

  @override
  String get shopPurchases => 'Purchases';

  @override
  String get shopSales => 'Sales';

  @override
  String get shopNoPurchasesYet => 'No purchases yet';

  @override
  String get shopNoSalesYet => 'No sales yet';

  @override
  String get shopStatusPending => 'Pending';

  @override
  String get shopStatusPaid => 'Paid';

  @override
  String get shopStatusCancelled => 'Cancelled';

  @override
  String get shopStatusRefunded => 'Refunded';

  @override
  String get shopStatusUnknown => 'Unknown';

  @override
  String get shopFulfillmentNone => 'Not started';

  @override
  String get shopFulfillmentAwaitingShipment => 'Awaiting shipment';

  @override
  String get shopFulfillmentShipped => 'Shipped';

  @override
  String get shopFulfillmentDelivered => 'Delivered';

  @override
  String get shopFulfillmentAccepted => 'Accepted';

  @override
  String get shopFulfillmentDisputed => 'Disputed';

  @override
  String get shopStatus => 'Status';

  @override
  String get shopFulfillment => 'Fulfillment';

  @override
  String get shopTracking => 'Tracking';

  @override
  String get shopItems => 'Items';

  @override
  String shopQty(int count) {
    return 'Qty: $count';
  }

  @override
  String get shopTotalPaid => 'Total paid';

  @override
  String get shopShipping => 'Shipping';

  @override
  String get shopShip => 'Ship';

  @override
  String get shopShipOrder => 'Ship order';

  @override
  String get shopTrackingNumber => 'Tracking number';

  @override
  String get shopShippingNote => 'Shipping note';

  @override
  String get shopReceive => 'Receive';

  @override
  String get shopAccept => 'Accept';

  @override
  String get shopDispute => 'Dispute';

  @override
  String get shopDisputeOrder => 'Dispute order';

  @override
  String get shopNoteOptional => 'Note (optional)';

  @override
  String get shopCancel => 'Cancel';

  @override
  String get shopLiveAddProduct => 'Add product';

  @override
  String get shopLiveNoProductsToAdd => 'No products available to add';

  @override
  String get shopLiveEmptyHost => 'No products yet — tap Add product';

  @override
  String get shopLiveEmptyViewer => 'No products in this live yet';

  @override
  String get shopPinned => 'Pinned';

  @override
  String get shopPin => 'Pin';

  @override
  String get shopUnpin => 'Unpin';

  @override
  String get shopRemove => 'Remove';

  @override
  String get shopBuy => 'Buy';

  @override
  String shopItemsCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count items',
      one: '1 item',
    );
    return '$_temp0';
  }

  @override
  String get noPostsFound => 'No posts found';

  @override
  String get navHome => 'Home';

  @override
  String get pressBackAgainToExit => 'Press back again to exit';

  @override
  String get navFriends => 'Friends';

  @override
  String get navAuctions => 'Auctions';

  @override
  String get auctionsSearchHint => 'Search auctions...';

  @override
  String get postsSearchTitle => 'Search posts';

  @override
  String get postsSearchHint => 'Search posts...';

  @override
  String get searchAction => 'Search';

  @override
  String get searchHistorySeeMore => 'See more';

  @override
  String get searchHistorySeeLess => 'See less';

  @override
  String get searchHistoryClear => 'Clear';

  @override
  String get searchHistoryEmpty => 'No recent searches';

  @override
  String get searchSeeAll => 'See all';

  @override
  String get searchSeeLess => 'See less';

  @override
  String get searchYouMayLike => 'You may like';

  @override
  String get searchNoResults => 'No posts found';

  @override
  String get searchTabTop => 'Top';

  @override
  String get searchTabUsers => 'Users';

  @override
  String get searchTabVideos => 'Videos';

  @override
  String get searchTabLive => 'LIVE';

  @override
  String get searchTabSounds => 'Sounds';

  @override
  String get searchTabPlaces => 'Places';

  @override
  String get searchComingSoon => 'Coming soon';

  @override
  String get auctionsFiltersTitle => 'Filters';

  @override
  String get auctionsFiltersApply => 'Apply filters';

  @override
  String get auctionsFiltersReset => 'Reset';

  @override
  String get auctionsFiltersCategories => 'Categories';

  @override
  String get auctionsFiltersPriceRange => 'Price range (USD)';

  @override
  String get auctionsFiltersMinPrice => 'Min price';

  @override
  String get auctionsFiltersMaxPrice => 'Max price';

  @override
  String get auctionsFiltersLiveStatus => 'Auction status';

  @override
  String get auctionsFilterLive => 'Live';

  @override
  String get auctionsFilterEnded => 'Ended';

  @override
  String get endedAuctionsNow => 'Ended auctions';

  @override
  String get auctionsFiltersTimeRemaining => 'Time remaining';

  @override
  String get auctionsFiltersInvalidPriceRange => 'Min price cannot be greater than max price';

  @override
  String get auctionsTimeRemainingAny => 'Any time';

  @override
  String get auctionsTimeRemaining1Hour => 'Ending within 1 hour';

  @override
  String get auctionsTimeRemaining6Hours => 'Ending within 6 hours';

  @override
  String get auctionsTimeRemaining24Hours => 'Ending within 24 hours';

  @override
  String get auctionsTimeRemaining7Days => 'Ending within 7 days';

  @override
  String get auctionsTimeRemaining30Days => 'Ending within 30 days';

  @override
  String get popularCategories => 'Popular categories';

  @override
  String get viewAll => 'View all';

  @override
  String get auctionCategoryWatches => 'Luxury watches';

  @override
  String get auctionCategoryCars => 'Sports cars';

  @override
  String get auctionCategoryArt => 'Rare art';

  @override
  String get auctionCategoryJewelry => 'Jewelry';

  @override
  String get auctionCategoryAll => 'All';

  @override
  String get activeAuctionsNow => 'Active auctions now';

  @override
  String get liveBadge => 'Live';

  @override
  String get auctionActiveBadge => 'Active';

  @override
  String get auctionTapToEnter => 'Tap to enter';

  @override
  String get auctionFinishedBadge => 'Finished';

  @override
  String get auctionCancelAction => 'Cancel auction';

  @override
  String get auctionCancelTitle => 'Cancel this auction?';

  @override
  String get auctionCancelMessage => 'Gift contributions may be refunded if escrow is enabled. This cannot be undone.';

  @override
  String get auctionCancelSuccess => 'Auction cancelled';

  @override
  String get auctionSellerRequiredTitle => 'Seller verification required';

  @override
  String get auctionSellerRequiredMessage => 'Complete seller verification before hosting auctions.';

  @override
  String get auctionSellerPendingMessage => 'Your seller verification is still under review.';

  @override
  String get auctionSellerRejectedMessage => 'Your seller verification was rejected. Please resubmit.';

  @override
  String get auctionSellerCompleteAction => 'Complete verification';

  @override
  String get sellerVerificationTitle => 'Seller verification';

  @override
  String get sellerVerificationSubtitle => 'Upload your passport and address details to host auctions.';

  @override
  String get sellerVerificationSubtitleSimple => 'Enter your ID number and upload a passport photo.';

  @override
  String get sellerVerificationIdentitySection => 'Identity';

  @override
  String get sellerVerificationPassportSection => 'Passport';

  @override
  String get sellerVerificationContactSection => 'Contact & address';

  @override
  String get sellerVerificationFullLegalName => 'Full legal name';

  @override
  String get sellerVerificationDateOfBirth => 'Date of birth';

  @override
  String get sellerVerificationNationality => 'Nationality';

  @override
  String get sellerVerificationNationalId => 'ID number';

  @override
  String get sellerVerificationNationalIdOptional => 'National ID (optional)';

  @override
  String get sellerVerificationNationalIdRequired => 'ID number is required';

  @override
  String get sellerVerificationPassportNumber => 'Passport number';

  @override
  String get sellerVerificationPassportCountry => 'Passport country';

  @override
  String get sellerVerificationPassportExpiry => 'Passport expiry date';

  @override
  String get sellerVerificationPassportFront => 'Passport front photo';

  @override
  String get sellerVerificationPassportPhoto => 'Passport photo';

  @override
  String get sellerVerificationPassportBackOptional => 'Passport back (optional)';

  @override
  String get sellerVerificationSelfieOptional => 'Selfie (optional)';

  @override
  String get sellerVerificationContactPhone => 'Contact phone';

  @override
  String get sellerVerificationAddressLine1 => 'Address line 1';

  @override
  String get sellerVerificationAddressLine2Optional => 'Address line 2 (optional)';

  @override
  String get sellerVerificationCity => 'City';

  @override
  String get sellerVerificationRegionOptional => 'Region / state (optional)';

  @override
  String get sellerVerificationCountry => 'Country';

  @override
  String get sellerVerificationPostalOptional => 'Postal code (optional)';

  @override
  String get sellerVerificationPickDate => 'Select date';

  @override
  String get sellerVerificationTapToUpload => 'Tap to upload';

  @override
  String get sellerVerificationUploading => 'Uploading…';

  @override
  String get sellerVerificationUploaded => 'Uploaded';

  @override
  String get sellerVerificationSubmit => 'Submit for review';

  @override
  String get sellerVerificationSubmitted => 'Verification submitted. We\'ll review it soon.';

  @override
  String get sellerVerificationDobRequired => 'Date of birth is required';

  @override
  String get sellerVerificationExpiryRequired => 'Passport expiry date is required';

  @override
  String get sellerVerificationExpiryFuture => 'Passport must not be expired';

  @override
  String get sellerVerificationPassportFrontRequired => 'Passport photo is required';

  @override
  String get auctionTimeLeft => 'Time left';

  @override
  String get auctionStartsIn => 'Starts in';

  @override
  String auctionAddedBy(String username) {
    return 'Added by $username';
  }

  @override
  String auctionCountdownDayCount(int days) {
    return '$days day';
  }

  @override
  String get auctionTimerHour => 'h';

  @override
  String get auctionTimerMinute => 'm';

  @override
  String get auctionTimerSecond => 's';

  @override
  String auctionCountdownWithDays(int days, String time) {
    return '$days day $time';
  }

  @override
  String get auctionTargetReachedMessage => 'Target price reached. Auction ended.';

  @override
  String get auctionBiddingClosed => 'Bidding closed';

  @override
  String auctionTargetPrice(String amount, String currency) {
    return 'Target $amount $currency';
  }

  @override
  String get liveStreamsTitle => 'Live Streams';

  @override
  String get searchLiveStreamsHint => 'Search live streams...';

  @override
  String get liveFilterAll => 'All';

  @override
  String get liveFilterRealEstate => 'Real Estate';

  @override
  String get liveFilterAuctions => 'Auctions';

  @override
  String get liveFilterTrending => 'Trending';

  @override
  String get liveFilterInvestments => 'Investments';

  @override
  String get liveStreamTitle1 => 'Live Real Estate Q&A';

  @override
  String get liveStreamTitle2 => 'Luxury Auction Showcase';

  @override
  String get liveStreamTitle3 => 'Investment Tips Live';

  @override
  String liveHostName(int number) {
    return 'Host $number';
  }

  @override
  String liveViewersCount(int count) {
    return '$count';
  }

  @override
  String get joinLiveStream => 'Join live';

  @override
  String get liveDetailsTitle => 'Live stream';

  @override
  String get liveFollow => 'Follow';

  @override
  String get liveFollowing => 'Following';

  @override
  String liveViewersShort(String count) {
    return '$count viewers';
  }

  @override
  String get liveTopBid => 'Highest price';

  @override
  String get liveTargetPrice => 'Target price';

  @override
  String get currencyUsd => 'USD';

  @override
  String get currencySar => 'SAR';

  @override
  String liveHighestBidAmount(String amount, String currency) {
    return '$amount $currency';
  }

  @override
  String get liveAddCommentOrBid => 'Add comment or bid...';

  @override
  String liveBidAmount(int amount) {
    return 'Bid $amount SAR';
  }

  @override
  String get liveCommentSample => 'This property looks amazing!';

  @override
  String get liveChatYou => 'You';

  @override
  String get liveSendGift => 'Send Gift';

  @override
  String get liveSelectGift => 'Select a Gift';

  @override
  String get liveSendToHost => 'Send to Host';

  @override
  String liveGiftSent(String name, String icon) {
    return 'Sent $name $icon';
  }

  @override
  String get liveGiftCommentGeneric => 'Sent a gift';

  @override
  String get liveGiftRose => 'Rose';

  @override
  String get liveGiftCoffee => 'Coffee';

  @override
  String get liveGiftDonut => 'Donut';

  @override
  String get liveGiftHeart => 'Heart';

  @override
  String get liveGiftParty => 'Party';

  @override
  String get liveGiftCrown => 'Crown';

  @override
  String get liveGiftRocket => 'Rocket';

  @override
  String get liveGiftDiamond => 'Diamond';

  @override
  String get liveVipBadge => 'VIP';

  @override
  String liveCoinsBalance(int count) {
    return '$count';
  }

  @override
  String get liveGiftPriceLabel => 'PRICE';

  @override
  String liveGiftPriceAmount(String amount, String currency) {
    return '$amount $currency';
  }

  @override
  String liveGiftBuy(String price) {
    return 'Buy — $price';
  }

  @override
  String get liveGiftBuyMore => 'Buy more';

  @override
  String get liveGiftBuying => 'Buying…';

  @override
  String get liveGiftSending => 'Sending…';

  @override
  String liveGiftPurchaseSuccess(String name) {
    return 'Purchased $name';
  }

  @override
  String get liveGiftLoginRequired => 'Sign in to buy or send gifts';

  @override
  String get liveGiftNoRecipient => 'Open a live or auction post to send a gift';

  @override
  String get liveGiftCannotSendToSelf => 'You cannot send a gift to your own auction';

  @override
  String get liveGiftCatalogEmpty => 'No gifts available';

  @override
  String get liveGiftRetry => 'Retry';

  @override
  String liveGiftOwned(int count) {
    return '×$count';
  }

  @override
  String get liveGiftLevelBanner => 'Send a Gift to activate your gifter level and rewards';

  @override
  String get liveGiftPinHint => 'Pin Gifts you like to the top';

  @override
  String get liveGiftPinAction => 'Pin';

  @override
  String get liveGiftUnpinAction => 'Unpin';

  @override
  String get liveGiftTabGifts => 'Gifts';

  @override
  String get liveGiftTabSongs => 'Songs';

  @override
  String get liveGiftTabInteractive => 'Interactive';

  @override
  String get liveGiftTabComingSoon => 'Coming soon';

  @override
  String get liveGiftSendAction => 'Send';

  @override
  String get liveGiftRecharge => 'Recharge';

  @override
  String get firstRechargeTitle => 'First recharge offer';

  @override
  String firstRechargeSubtitle(int days) {
    return 'Rewards are only available with cash recharge. Offer ends in $days days.';
  }

  @override
  String get firstRechargeRoseTitle => 'Get Rose x3 in your Backpack';

  @override
  String get firstRechargeRoseBody => 'Get 1 now and the rest after 24 hours, each available for 7 days';

  @override
  String get firstRechargeBonusTitle => 'Get bonus Coins';

  @override
  String get firstRechargeBonusBody => 'Use Coins on virtual items such as Gifts';

  @override
  String get firstRechargeGetCoins => 'Get Coins';

  @override
  String get firstRechargeGetCoinsHint => 'Recharge to get Gifts and bonus Coins.';

  @override
  String get firstRechargePolicy => 'By continuing, you agree to the Virtual Items Policy. You will also lose the extra bonus if you withdraw from this purchase.';

  @override
  String firstRechargeCta(String coins, String price) {
    return 'Get $coins ($price)';
  }

  @override
  String get auctionGiftsTitle => 'Auction gifts';

  @override
  String get auctionGiftsEmpty => 'No gifts sent on this auction yet';

  @override
  String auctionGiftsSummary(String current, String target, String currency) {
    return '$current / $target $currency';
  }

  @override
  String auctionGiftsContribution(String amount, String currency) {
    return '+$amount $currency';
  }

  @override
  String liveQuickBid(int amount) {
    return '+$amount';
  }

  @override
  String get highestCurrentBid => 'Highest current bid';

  @override
  String get bidsLabel => 'Bids';

  @override
  String get auctionGiftsLabel => 'Gifts';

  @override
  String get bidNow => 'Bid now';

  @override
  String get navAdd => 'Add';

  @override
  String get navChat => 'Chat';

  @override
  String get navProfile => 'Profile';

  @override
  String get describePostHint => 'Add a description...';

  @override
  String get addDescriptionHint => 'Add a description...';

  @override
  String get hashtagsLabel => 'Hashtags';

  @override
  String get mentionsLabel => 'Mention';

  @override
  String get whoCanWatchLabel => 'Who can view this post';

  @override
  String get allowCommentsLabel => 'Allow comments';

  @override
  String get allowReuseLabel => 'Allow reuse of content';

  @override
  String get allowReuseSubtitle => 'Duet, Stitch, stickers, and add to Story';

  @override
  String get videoPrivacySection => 'Video privacy';

  @override
  String get advancedSettings => 'Advanced settings';

  @override
  String get addPostSettingsTitle => 'Settings';

  @override
  String get everyoneCanViewPost => 'Everyone can view this post';

  @override
  String get friendsCanViewPost => 'Friends can view this post';

  @override
  String get onlyYouCanViewPost => 'Only you can view this post';

  @override
  String get friendsPrivacySubtitle => 'Followers you follow back';

  @override
  String get draftsLabel => 'Drafts';

  @override
  String get moreOptionsLabel => 'More options';

  @override
  String get previewLabel => 'Preview';

  @override
  String get editCoverLabel => 'Edit cover';

  @override
  String get locationLabelShort => 'Location';

  @override
  String get addPostDraftsComingSoon => 'Drafts coming soon';

  @override
  String get allowDuetLabel => 'Allow Duet';

  @override
  String get allowStitchLabel => 'Allow Stitch';

  @override
  String get addLocationLabel => 'Add location';

  @override
  String get selectCity => 'Select city';

  @override
  String get selectCityHint => 'Search cities';

  @override
  String get selectCountryHint => 'Search countries';

  @override
  String get locationSearchHint => 'Search countries or cities';

  @override
  String get clearLocation => 'Clear location';

  @override
  String get everyoneLabel => 'Everyone';

  @override
  String get friendsLabel => 'Friends';

  @override
  String get onlyMeLabel => 'Only me';

  @override
  String get videoLabel => 'Video';

  @override
  String get recordVideo => 'Record video';

  @override
  String get imagesLabel => 'Images';

  @override
  String get imageFromLibrary => 'Upload images from library';

  @override
  String get videoFromLibrary => 'Import videos from library';

  @override
  String get tapToSelectMedia => 'Tap to upload from library';

  @override
  String get pleaseSelectMediaFirst => 'Please select media first';

  @override
  String get loginRequired => 'Login Required';

  @override
  String get loginRequiredMessage => 'Please login to like, comment or save posts';

  @override
  String get cancel => 'Cancel';

  @override
  String get login => 'Login';

  @override
  String get commentsTitle => 'Comments';

  @override
  String commentsCount(int count) {
    return '$count comments';
  }

  @override
  String get postLikesEmpty => 'No likes yet';

  @override
  String get postViewsEmpty => 'No views yet';

  @override
  String postViewWatchedDuration(int seconds) {
    return '${seconds}s watched';
  }

  @override
  String get viewsLabel => 'Views';

  @override
  String get commentsSortNewest => 'Newest';

  @override
  String get commentsSortOldest => 'Oldest';

  @override
  String get commentsSortTop => 'Top';

  @override
  String get noCommentsYet => 'No comments yet. Be the first!';

  @override
  String get addCommentHint => 'Add comment...';

  @override
  String get justNow => 'Just now';

  @override
  String inboxTimeMinutes(int count) {
    return '${count}m';
  }

  @override
  String inboxTimeHours(int count) {
    return '${count}h';
  }

  @override
  String inboxTimeDays(int count) {
    return '${count}d';
  }

  @override
  String get replyAction => 'Reply';

  @override
  String replyingTo(String username) {
    return 'Replying to $username';
  }

  @override
  String viewReplies(int count) {
    return 'View $count replies';
  }

  @override
  String get hideReplies => 'Hide replies';

  @override
  String get loadMoreReplies => 'Load more replies';

  @override
  String get deleteCommentTitle => 'Delete comment?';

  @override
  String get deleteCommentMessage => 'This comment will be permanently removed.';

  @override
  String get deleteAction => 'Delete';

  @override
  String get editPost => 'Edit post';

  @override
  String get deletePost => 'Delete post';

  @override
  String get deletePostTitle => 'Delete post?';

  @override
  String get deletePostMessage => 'This post will be permanently removed. Only you can delete your own posts.';

  @override
  String get postOptionShare => 'Share';

  @override
  String get postOptionReport => 'Report';

  @override
  String get postOptionNotInterested => 'Not interested';

  @override
  String get feedInterestPromptQuestion => 'Are you interested in this kind of content?';

  @override
  String get feedInterestPromptYes => 'Yes';

  @override
  String get feedInterestPromptNo => 'No';

  @override
  String get feedInterestPromptThanks => 'Thanks — we\'ll show more like this';

  @override
  String get postOptionDownload => 'Download';

  @override
  String get postOptionAddToStory => 'Add to story';

  @override
  String get postOptionShareAsGif => 'Share as GIF';

  @override
  String get postOptionCreateGroup => 'Create group';

  @override
  String get postLinkCopied => 'Link copied to clipboard';

  @override
  String get postReportTitle => 'Report post?';

  @override
  String get postReportMessage => 'Tell us if this post breaks our community guidelines.';

  @override
  String get postReportSubmitted => 'Thanks for reporting. We\'ll review this post.';

  @override
  String get postReportReasonSpam => 'Spam';

  @override
  String get postReportReasonHarassment => 'Harassment or bullying';

  @override
  String get postReportReasonHateSpeech => 'Hate speech';

  @override
  String get postReportReasonViolence => 'Violence or dangerous content';

  @override
  String get postReportReasonNudity => 'Nudity or sexual content';

  @override
  String get postReportReasonFalseInfo => 'False information';

  @override
  String get postReportReasonScam => 'Scam or fraud';

  @override
  String get postReportReasonCopyright => 'Copyright infringement';

  @override
  String get postReportReasonOther => 'Other';

  @override
  String get postNotInterestedApplied => 'We\'ll show fewer posts like this';

  @override
  String get postDownloadStarted => 'Downloading…';

  @override
  String get postDownloadSaved => 'Saved to app downloads';

  @override
  String get postDownloadFailed => 'Could not download media';

  @override
  String get postShareAsGifUnavailable => 'GIF share is only available for videos';

  @override
  String get postShareSheetTitle => 'Share post';

  @override
  String get postShareSendToTitle => 'Send to';

  @override
  String get postShareSearchHint => 'Search';

  @override
  String get postShareRecentChats => 'Recent chats';

  @override
  String get postShareSearchUsers => 'Search friends and users';

  @override
  String get postShareNoUsers => 'No users found';

  @override
  String get postShareToApps => 'Share to apps';

  @override
  String get postShareMessenger => 'Messenger';

  @override
  String get postShareFacebook => 'Facebook';

  @override
  String get postShareInstagram => 'Instagram';

  @override
  String get postShareWhatsApp => 'WhatsApp';

  @override
  String get postShareTelegram => 'Telegram';

  @override
  String get postShareTwitter => 'X';

  @override
  String get postShareSms => 'SMS';

  @override
  String get postShareEmail => 'Email';

  @override
  String get postShareCopyLink => 'Copy link';

  @override
  String get postShareMore => 'More';

  @override
  String get postOptionCast => 'Cast';

  @override
  String get postShareInstagramHint => 'Link copied — paste in Instagram';

  @override
  String get postOptionCastUnavailable => 'Casting is not available yet';

  @override
  String get postShareSendFailed => 'Could not send post';

  @override
  String postShareSentTo(String name) {
    return 'Sent to $name';
  }

  @override
  String get postShareSend => 'Send';

  @override
  String postShareSendToCount(int count) {
    return 'Send ($count)';
  }

  @override
  String postShareSentCount(int count) {
    return 'Sent to $count people';
  }

  @override
  String get postQuickShareTitle => 'Recent friends';

  @override
  String get postQuickShareSubtitle => 'Select friends, tap again to cancel, then send';

  @override
  String get postAddToStoryHint => 'Create your story — the post is ready to share';

  @override
  String get postCreateGroupHint => 'Pick contacts to start a group chat';

  @override
  String get postUpdatedSuccessfully => 'Post updated successfully';

  @override
  String get postDeletedSuccessfully => 'Post deleted successfully';

  @override
  String get saveButton => 'Save';

  @override
  String get categoryLabel => 'Category';

  @override
  String get selectCategoryHint => 'Choose a category';

  @override
  String get hashtagsHint => 'Type #tag in your caption (e.g. #travel #food)';

  @override
  String get mentionsHint => 'Type @username in your caption (e.g. @jane_doe)';

  @override
  String get mediaLabel => 'Media';

  @override
  String get settingsAndPrivacy => 'Settings and privacy';

  @override
  String get settingsSectionAccount => 'Account';

  @override
  String get settingsSecurity => 'Security';

  @override
  String get settingsPrivacy => 'Privacy';

  @override
  String get privacyPrivateAccount => 'Private account';

  @override
  String get privacyPrivateAccountSubtitle => 'Only approved followers can see your posts and stories.';

  @override
  String get privacyWhoCanMessage => 'Who can message you';

  @override
  String get privacyMessageEveryone => 'Everyone';

  @override
  String get privacyMessageFollowers => 'People you follow';

  @override
  String get privacyMessageFriends => 'Friends';

  @override
  String get privacyMessageNobody => 'No one';

  @override
  String get privacyAllowComments => 'Allow comments';

  @override
  String get privacyAllowCommentsSubtitle => 'People can comment on your posts.';

  @override
  String get privacyUpdated => 'Privacy settings updated';

  @override
  String get privacySectionAccount => 'Account privacy';

  @override
  String get privacySectionInteractions => 'Interactions';

  @override
  String get settingsSectionContent => 'Content & display';

  @override
  String get settingsLanguage => 'Language';

  @override
  String get settingsNotifications => 'Notifications';

  @override
  String get settingsDarkMode => 'Dark mode';

  @override
  String get settingsSectionSupport => 'Support';

  @override
  String get settingsHelpCenter => 'Help center';

  @override
  String get settingsAbout => 'About';

  @override
  String get settingsLogout => 'Log out';

  @override
  String get settingsSelectLanguage => 'Select language';

  @override
  String get settingsAppearance => 'Appearance';

  @override
  String get settingsLightMode => 'Light mode';

  @override
  String get settingsDarkModeOption => 'Dark mode';

  @override
  String get settingsLanguageEnglish => 'English';

  @override
  String get settingsLanguageArabic => 'Arabic';

  @override
  String get settingsOn => 'On';

  @override
  String get settingsOff => 'Off';

  @override
  String get settingsLogoutTitle => 'Log out?';

  @override
  String get settingsLogoutMessage => 'You will need to sign in again to use your account.';

  @override
  String get settingsComingSoon => 'Coming soon';

  @override
  String get settingsChatWallpaper => 'Chat wallpaper';

  @override
  String get settingsSectionAdmin => 'Admin';

  @override
  String get settingsAdminActivity => 'User activity';

  @override
  String get adminActivityTitle => 'Activity';

  @override
  String get adminActivityEmpty => 'No activity yet';

  @override
  String get adminActivityJustNow => 'Just now';

  @override
  String get adminActivityNoDetails => 'No details';

  @override
  String adminActivityOnPost(String post) {
    return 'On post: $post';
  }

  @override
  String get adminActivityTypeCreatePost => 'Created a post';

  @override
  String get adminActivityTypeComment => 'Commented';

  @override
  String get adminActivityTypeLikePost => 'Liked a post';

  @override
  String get adminActivityTypeSendGift => 'Sent a gift';

  @override
  String get chatWallpaperTitle => 'Chat wallpaper';

  @override
  String get chatWallpaperSubtitle => 'Choose a background pattern for your chats. Colors follow your app theme.';

  @override
  String get chatWallpaperPlus => 'Plus';

  @override
  String get chatWallpaperSquares => 'Squares';

  @override
  String get chatWallpaperMaze => 'Maze';

  @override
  String get chatWallpaperChooseFromPhotos => 'Choose from Photos';

  @override
  String get chatWallpaperUploadDeviceSubtitle => 'Upload personal photo from device';

  @override
  String get chatWallpaperDefault => 'Default (No Wallpaper)';

  @override
  String get chatWallpaperCatalog => 'Wallpapers Catalog';

  @override
  String get chatWallpaperUpdated => 'Personal background updated';

  @override
  String get chatSettingsTitle => 'Details';

  @override
  String get chatSettingsProfile => 'Profile';

  @override
  String get chatSettingsMute => 'Mute';

  @override
  String get chatSettingsMuted => 'Muted';

  @override
  String get chatSettingsReport => 'Report';

  @override
  String get chatSettingsMuteNotifications => 'Mute notifications';

  @override
  String get chatSettingsPinToTop => 'Pin to top';

  @override
  String get chatSettingsWallpaperSubtitle => 'Custom theme background';

  @override
  String get chatSettingsSearch => 'Search in conversation';

  @override
  String chatSettingsBlock(String username) {
    return 'Block @$username';
  }

  @override
  String get chatSettingsBlocked => 'Blocked';

  @override
  String get unblock => 'Unblock';

  @override
  String get chatYouBlockedUser => 'You blocked this user. Unblock to send a message.';

  @override
  String get userNotFound => 'User not found';

  @override
  String get chatSettingsDeleteHistory => 'Delete chat history';

  @override
  String get chatSettingsSearchHint => 'Type keyword...';

  @override
  String chatSettingsSearching(String query) {
    return 'Searching for \"$query\"...';
  }

  @override
  String chatSettingsReportTitle(String username) {
    return 'Report @$username';
  }

  @override
  String get chatSettingsReportSpam => 'Spam or Scam';

  @override
  String get chatSettingsReportHarassment => 'Harassment or Bullying';

  @override
  String get chatSettingsReportInappropriate => 'Inappropriate Content';

  @override
  String chatSettingsReportSubmitted(String reason) {
    return 'Report submitted: $reason';
  }

  @override
  String chatSettingsBlockTitle(String username) {
    return 'Block @$username?';
  }

  @override
  String get chatSettingsBlockMessage => 'They won\'t be able to message you or view your profile.';

  @override
  String get chatSettingsDeleteTitle => 'Delete chat history?';

  @override
  String get chatSettingsDeleteMessage => 'This will remove the chat history for you. This action cannot be undone.';

  @override
  String get messagesTitle => 'Messages';

  @override
  String get messagesInboxTitle => 'Inbox';

  @override
  String get messagesNewChatTitle => 'New chat';

  @override
  String get messagesNewChatSearchHint => 'Search';

  @override
  String get closeAction => 'Close';

  @override
  String get chatSendMessageHint => 'Send a message...';

  @override
  String get chatActiveYesterday => 'Active yesterday';

  @override
  String get messagesSwitchAccount => 'Switch Account';

  @override
  String get messagesNewConversation => 'New conversation';

  @override
  String get messagesSearchHint => 'Search messages or people';

  @override
  String get messagesYourStory => 'Your Story';

  @override
  String get messagesPeopleYouMayKnow => 'People you may know';

  @override
  String get messagesSeeAll => 'See all';

  @override
  String get messagesFollow => 'Follow';

  @override
  String get messagesFollowing => 'Following';

  @override
  String get messagesRecentMentions => 'Recent Mentions';

  @override
  String get messagesActivityFollowers => 'Followers';

  @override
  String get messagesActivityActivities => 'Activities';

  @override
  String get messagesActivityTitle => 'Activity';

  @override
  String get messagesNewFollowers => 'New followers';

  @override
  String get messagesActivityComments => 'Comments';

  @override
  String get messagesActivityMentions => 'Mentions';

  @override
  String get messagesActivityNotifications => 'Notifications';

  @override
  String get activityTabLikes => 'Likes';

  @override
  String get activityAllCaughtUp => 'You\'re all caught up';

  @override
  String get activityClearNotificationsMessage => 'Remove all read notifications from your activity feed?';

  @override
  String get activityOpenCommentsSubtitle => 'See comments on your posts';

  @override
  String get activityInboxSubtitle => 'Likes, comments and more';

  @override
  String get messagesRecentMessages => 'Recent Messages';

  @override
  String get messagesAllChats => 'All Chats';

  @override
  String get messagesAll => 'All';

  @override
  String get messagesNoResults => 'No results found';

  @override
  String get messagesInboxNoMessagesYet => 'No messages yet';

  @override
  String get messagesInboxYouPrefix => 'You';

  @override
  String get messagesInboxLastPhoto => 'Photo';

  @override
  String get messagesInboxLastVideo => 'Video';

  @override
  String get messagesInboxLastVoice => 'Voice message';

  @override
  String get messagesInboxLastGift => 'Gift';

  @override
  String get messagesInboxLastShare => 'Shared a post';

  @override
  String get messagesInboxMessageDeleted => 'Message deleted';

  @override
  String get messagesInboxGroupFallback => 'Group';

  @override
  String get messagesInboxUserFallback => 'User';

  @override
  String get messagesPreviewProperty => 'Hi, is the property still available?';

  @override
  String get messagesPreviewOffer => 'New offer has been sent';

  @override
  String get messagesPreviewThanks => 'Thank you for your interest';

  @override
  String get messagesPreviewCar => 'When can I check the car?';

  @override
  String get messagesMentionVilla => 'Great post describing the villa! @myself';

  @override
  String get messagesMentionCheck => 'Check this out @myself';

  @override
  String get messagesSuggestionBioDesigner => 'Interior Designer | Arch';

  @override
  String get messagesSuggestionBioJeddah => 'Top listings in Jeddah';

  @override
  String get messagesSuggestionBioLuxury => 'Worldwide luxury estates';

  @override
  String get messagesSuggestionFriendsOfFriends => 'Suggested for you';

  @override
  String get messagesSuggestionPopular => 'Popular creator';

  @override
  String messagesSuggestionMutualFriends(num count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count mutual friends',
      one: '1 mutual friend',
    );
    return '$_temp0';
  }

  @override
  String get messagesSuggestionsEmpty => 'No suggestions right now';

  @override
  String get userCommentsTitle => 'My Comments';

  @override
  String get userCommentsEmpty => 'You haven\'t commented on any posts yet';

  @override
  String get userCommentReplyLabel => 'Reply';

  @override
  String get userCommentAction => 'commented';

  @override
  String userCommentOnPost(String author) {
    return 'On post by $author';
  }

  @override
  String get userLikesTitle => 'Likes';

  @override
  String get userLikesEmpty => 'No one has liked your posts yet';

  @override
  String get userLikeReceivedAction => 'liked your post';

  @override
  String get userMentionsTitle => 'My Mentions';

  @override
  String get userMentionsEmpty => 'No one has mentioned you yet';

  @override
  String get userMentionAction => 'mentioned you';

  @override
  String get userMentionInComment => 'in a comment';

  @override
  String get userFollowersTitle => 'Followers';

  @override
  String get userFollowerAction => 'followed you';

  @override
  String get chatMessageDeleted => 'This message was deleted';

  @override
  String get chatActionReply => 'Reply';

  @override
  String get chatActionReact => 'React';

  @override
  String get chatActionDelete => 'Delete';

  @override
  String get chatDeleteMessageTitle => 'Delete message?';

  @override
  String get chatDeleteMessageMessage => 'This message will be hidden for everyone in the chat.';

  @override
  String get chatActiveNow => 'Active now';

  @override
  String get chatAddComment => 'Write message';

  @override
  String get chatRecording => 'Recording...';

  @override
  String get chatSlideUpToCancel => 'Slide up to cancel';

  @override
  String get chatRecordingPermissionDenied => 'Allow microphone access to record voice messages.';

  @override
  String get chatRecordingPermissionTitle => 'Microphone access';

  @override
  String get chatRecordingPermissionSettingsMessage => 'Voice messages need the microphone. Open Settings, tap Permissions, and allow Microphone for Bimo Bond.';

  @override
  String get chatRecordingOpenSettings => 'Open Settings';

  @override
  String get chatRecordingAllowMicrophone => 'Allow';

  @override
  String get chatRecordingPluginUnavailable => 'Voice recording is not ready. Stop the app completely, then run it again (not hot reload).';

  @override
  String get chatVoiceTooShort => 'Hold longer to record a voice message.';

  @override
  String get chatVoicePlaybackFailed => 'Could not play this voice message.';

  @override
  String get chatAttachmentSendFailed => 'Could not send attachment. Please try again.';

  @override
  String get chatLocationPermissionDenied => 'Location permission is required to share your position.';

  @override
  String get chatContactsPermissionDenied => 'Contacts permission is required to share a contact.';

  @override
  String get chatFeatureComingSoon => 'Coming soon.';

  @override
  String get chatMessageLocation => 'Location';

  @override
  String get messagesInboxLastLocation => 'Location';

  @override
  String get messagesInboxLastFile => 'File';

  @override
  String get messagesInboxLastContact => 'Contact';

  @override
  String get chatSeedGreeting => 'Hi! How can I help you?';

  @override
  String get chatSeedInterested => 'I am interested in the property shown';

  @override
  String get chatSeedFinalPrice => 'Can I know the final price?';

  @override
  String get chatSeedAutoReply => 'Thanks for reaching out! We will get back to you soon with more details.';

  @override
  String get chatUserBio => 'Interested in real estate and design.';

  @override
  String get chatMoreGallery => 'Import';

  @override
  String get chatMoreCamera => 'Camera';

  @override
  String get chatMoreVideo => 'Video';

  @override
  String get chatMoreLocation => 'Location';

  @override
  String get chatMoreContact => 'Contact';

  @override
  String get chatMoreFile => 'File';

  @override
  String get chatMoreGift => 'Gift';

  @override
  String get chatMorePoll => 'Poll';

  @override
  String get chatGiftSheetTitle => 'Send a gift';

  @override
  String get chatGiftSheetSubtitle => 'Choose a gift from your inventory';

  @override
  String get chatGiftInventoryEmpty => 'You don\'t own any gifts yet. Buy gifts in your wallet first.';

  @override
  String get chatGiftSentLabel => 'Gift sent';

  @override
  String get chatMessageContact => 'Contact';

  @override
  String get chatPollSheetTitle => 'Create a poll';

  @override
  String get chatPollQuestionHint => 'Ask a question';

  @override
  String get chatPollOptionsLabel => 'Options';

  @override
  String chatPollOptionHint(int index) {
    return 'Option $index';
  }

  @override
  String get chatPollAddOption => 'Add option';

  @override
  String get chatPollAllowMultiple => 'Allow multiple answers';

  @override
  String get chatPollSend => 'Send poll';

  @override
  String get chatPollQuestionRequired => 'Enter a question for your poll.';

  @override
  String get chatPollOptionsRequired => 'Add at least two options.';

  @override
  String get chatPollEnded => 'Poll ended';

  @override
  String chatPollVotesCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count votes',
      one: '1 vote',
      zero: 'No votes yet',
    );
    return '$_temp0';
  }

  @override
  String get messagesInboxLastPoll => 'Poll';

  @override
  String get chatLastMessage1 => 'Can I know the final price?';

  @override
  String get chatLastMessage2 => 'Thanks for the update!';

  @override
  String get chatLastMessage3 => 'Is the property still available?';

  @override
  String get chatLastMessage4 => 'Sent a photo';

  @override
  String get chatLastMessage5 => 'See you tomorrow 👋';

  @override
  String get mediaStudioAutoCut => 'AutoCut';

  @override
  String get addPostAsAuction => 'Show on live';

  @override
  String get auctionItemName => 'Item name';

  @override
  String get auctionItemNameHint => 'e.g. Antique Pocket Watch';

  @override
  String get auctionStartingPrice => 'Starting price (USD)';

  @override
  String get auctionTargetPriceLabel => 'Target price (USD)';

  @override
  String get auctionStartDate => 'Auction starts';

  @override
  String get auctionEndDate => 'Auction ends';

  @override
  String get auctionEndBeforeStart => 'End date must be after start date';

  @override
  String get auctionTargetBelowStart => 'Target price must be greater than starting price';

  @override
  String get auctionInvalidPrice => 'Enter a valid price';

  @override
  String get hashtagFeedSubtitle => 'Posts with this hashtag';

  @override
  String get noHashtagPosts => 'No posts for this hashtag yet';

  @override
  String get trendingHashtags => 'Trending hashtags';

  @override
  String get searchHashtagsHint => 'Search hashtags';

  @override
  String get noHashtagsFound => 'No hashtags found';

  @override
  String hashtagPostCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count posts',
      one: '1 post',
      zero: 'No posts',
    );
    return '$_temp0';
  }

  @override
  String get notificationsEmpty => 'No notifications yet';

  @override
  String get notificationsEmptySubtitle => 'When someone interacts with you, you\'ll see it here.';

  @override
  String get notificationsEmptyUnread => 'You\'re all caught up — no unread notifications.';

  @override
  String get notificationsEmptyRead => 'No read notifications yet.';

  @override
  String notificationsFilterUnreadCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count unread notifications',
      one: '1 unread notification',
    );
    return '$_temp0';
  }

  @override
  String get notificationsRetry => 'Try again';

  @override
  String get notificationsOk => 'OK';

  @override
  String get notificationsLoadError => 'Couldn\'t load notifications';

  @override
  String get notificationsMarkAllRead => 'Mark all read';

  @override
  String get notificationsClearRead => 'Clear read';

  @override
  String get notificationsFilterAll => 'All';

  @override
  String get notificationsFilterUnread => 'Unread';

  @override
  String get notificationsFilterRead => 'Read';

  @override
  String get notificationsFilterViewAll => 'View all';

  @override
  String get notificationsFilterActivity => 'Activity';

  @override
  String get notificationsFilterAuctions => 'Auctions';

  @override
  String get notificationsFilterInvites => 'Invites';

  @override
  String get notificationsAccept => 'Accept';

  @override
  String get notificationsDecline => 'Decline';

  @override
  String get notificationsEmptyActivity => 'No activity notifications yet.';

  @override
  String get notificationsEmptyAuctions => 'No auction notifications yet.';

  @override
  String get notificationsEmptyInvites => 'No invite notifications yet.';

  @override
  String get notificationContextPost => 'Post';

  @override
  String get notificationMediaVideo => 'Video';

  @override
  String get notificationMediaImage => 'Image';

  @override
  String get notificationActionFollowedYou => 'followed you';

  @override
  String get notificationActionFollowRequest => 'requested to follow you';

  @override
  String get notificationActionFollowAccepted => 'accepted your follow request';

  @override
  String get notificationActionPostLike => 'liked your post';

  @override
  String get notificationActionPostComment => 'commented on your post';

  @override
  String get notificationActionCommentReply => 'replied to your comment';

  @override
  String get notificationActionCommentLike => 'liked your comment';

  @override
  String get notificationActionMention => 'mentioned you';

  @override
  String get notificationActionRepost => 'reposted your post';

  @override
  String get notificationActionGift => 'sent you a gift';

  @override
  String get notificationActionAuctionUpdate => 'updated an auction you follow';

  @override
  String get notificationActionAuctionWon => 'you won an auction';

  @override
  String get notificationSomeone => 'Someone';

  @override
  String get notificationTitleDefault => 'Notification';

  @override
  String get notificationTitleNewFollower => 'New follower';

  @override
  String get notificationTitleFollowRequest => 'Follow request';

  @override
  String get notificationTitleFollowAccepted => 'Follow request accepted';

  @override
  String get notificationTitlePostLike => 'New like';

  @override
  String get notificationTitlePostComment => 'New comment';

  @override
  String get notificationTitleCommentReply => 'New reply';

  @override
  String get notificationTitleCommentLike => 'Comment liked';

  @override
  String get notificationTitleMention => 'Mention';

  @override
  String get notificationTitleRepost => 'Repost';

  @override
  String get notificationTitleGift => 'Gift received';

  @override
  String get notificationTitleAuctionUpdate => 'Auction update';

  @override
  String get notificationTitleAuctionWon => 'Auction won';

  @override
  String get notificationBodyDefault => 'You have a new notification';

  @override
  String notificationBodyNewFollower(String name) {
    return '$name started following you';
  }

  @override
  String notificationBodyFollowRequest(String name) {
    return '$name requested to follow you';
  }

  @override
  String notificationBodyFollowAccepted(String name) {
    return '$name accepted your follow request';
  }

  @override
  String notificationBodyPostLike(String name) {
    return '$name liked your post';
  }

  @override
  String notificationBodyPostComment(String name) {
    return '$name commented on your post';
  }

  @override
  String notificationBodyCommentReply(String name) {
    return '$name replied to your comment';
  }

  @override
  String notificationBodyCommentLike(String name) {
    return '$name liked your comment';
  }

  @override
  String notificationBodyMention(String name) {
    return '$name mentioned you';
  }

  @override
  String notificationBodyRepost(String name) {
    return '$name reposted your post';
  }

  @override
  String notificationBodyGift(String name) {
    return '$name sent you a gift';
  }

  @override
  String get notificationBodyAuctionUpdate => 'An auction you follow was updated';

  @override
  String get notificationBodyAuctionWon => 'You won an auction';

  @override
  String get walletTitle => 'Wallet';

  @override
  String get walletBalanceLabel => 'Coins Balance';

  @override
  String get walletChoosePackage => 'Choose a Package';

  @override
  String get walletCustomAmountTitle => 'Custom amount';

  @override
  String get walletCustomCoinsLabel => 'How many coins?';

  @override
  String get walletCustomCoinsHint => 'e.g. 500';

  @override
  String get walletCustomCoinsReceive => 'You receive';

  @override
  String walletCustomCoinsValue(String coins) {
    return '$coins coins';
  }

  @override
  String get walletCustomYouPay => 'You pay';

  @override
  String get walletPackageQuotes => 'Package quotes';

  @override
  String get walletPackageQuotePrice => 'Package price';

  @override
  String get walletPricingPreviewCost => 'Total cost';

  @override
  String get walletPricingPreviewLoading => 'Calculating...';

  @override
  String get walletCustomAmountInvalid => 'Enter a valid coin amount.';

  @override
  String walletPurchaseSuccess(int amount) {
    return 'Successfully purchased $amount coins!';
  }

  @override
  String get walletTopUpButton => 'Top Up';

  @override
  String get walletProcessing => 'Processing payment...';

  @override
  String get walletCardNumber => 'Card Number';

  @override
  String get walletExpiry => 'Expiry Date (MM/YY)';

  @override
  String get walletCvv => 'CVV';

  @override
  String get walletCardHolder => 'Cardholder Name';

  @override
  String walletPayButton(String price) {
    return 'Pay $price';
  }

  @override
  String get coinsHubTitle => 'Coins';

  @override
  String get coinsAvailableBalance => 'Available balance';

  @override
  String coinsWalletAccountName(String name) {
    return '$name\'s Account';
  }

  @override
  String get coinsBalanceRefresh => 'Refresh balance';

  @override
  String get coinsBalanceFooterHint => 'UPDATED ON OPEN';

  @override
  String coinsBalanceFooter(String date, String hint) {
    return '$date | $hint';
  }

  @override
  String get coinsTabBuy => 'Buy';

  @override
  String get coinsTabMarket => 'Market';

  @override
  String get coinsTabVault => 'Vault';

  @override
  String get coinsUnit => 'coins';

  @override
  String get coinsHistoryTitle => 'Recent activity';

  @override
  String get coinsMarketSuccess => 'Gift added to your vault!';

  @override
  String get coinsVaultEmpty => 'No gifts in your vault yet. Visit the market to buy gifts with coins.';

  @override
  String get coinsVaultOwned => 'In vault';

  @override
  String get coinsInsufficientBalance => 'Not enough coins. Buy more in the Buy tab.';

  @override
  String get walletAccountingPurchase => 'Bought coins';

  @override
  String get walletAccountingGiftPurchase => 'Bought gift';

  @override
  String get walletAccountingGiftReceived => 'Received gift';

  @override
  String get walletAccountingPromotion => 'Post promotion';

  @override
  String get walletAccountingAdmin => 'Balance adjustment';

  @override
  String get balanceTitle => 'Balance';

  @override
  String get balanceDefaultUserName => 'User';

  @override
  String balanceUserTitle(String name) {
    return '$name\'s balance';
  }

  @override
  String get balanceEstimatedBalance => 'Estimated balance';

  @override
  String get balanceView => 'View';

  @override
  String get balanceGet => 'Get';

  @override
  String get balanceScheduledPayouts => 'Scheduled payouts';

  @override
  String get balanceViewFullSchedule => 'View full schedule >';

  @override
  String get balanceSetupPaymentsBanner => 'To receive payouts from Creator Rewards Program, set up payments.';

  @override
  String get balanceSetup => 'Set up';

  @override
  String get balanceSetupRequired => 'Setup required';

  @override
  String get balancePastPayouts => 'Past payouts >';

  @override
  String get balanceTransactions => 'Transactions';

  @override
  String balanceTransactionPreview(String title, String amount) {
    return '$title: $amount >';
  }

  @override
  String get balanceFirstCoinOfferTitle => 'First Coin purchase offer';

  @override
  String get balanceFirstCoinOfferSubtitle => 'Get bonus Coins and a 99% off animated Gift from your first purchase';

  @override
  String get balanceGetNow => 'Get now →';

  @override
  String get balanceMonetization => 'Monetization';

  @override
  String get balanceViewMore => 'View more >';

  @override
  String get balanceMonetizationLive => 'LIVE';

  @override
  String get balanceMonetizationActivities => 'Activities';

  @override
  String get balanceServices => 'Services';

  @override
  String get balancePaymentMethods => 'Payment methods';

  @override
  String get balanceRequired => 'Required';

  @override
  String get balanceTaxInformation => 'Tax information';

  @override
  String get balanceIdentityVerification => 'Identity verification';

  @override
  String get balanceMonetizationCenter => 'Monetization Center';

  @override
  String get balanceExplore => 'Explore >';

  @override
  String get balanceProgramCreatorRewards => 'Creator Rewards Program';

  @override
  String get balanceProgramTiktokGo => 'TikTok GO rewards';

  @override
  String get balanceProgramSeries => 'Series';

  @override
  String get balanceSetupPaymentsTitle => 'Set up payments';

  @override
  String get balanceSetupPaymentsMessage => 'Ensure your information is accurate to receive payouts on time. You can change this at any time.';

  @override
  String get balancePayoutMethodTitle => 'Payout method';

  @override
  String get balancePayoutMethodSubtitle => 'Select where to receive payouts.';

  @override
  String get balanceTaxInfoTitle => 'Tax information';

  @override
  String get balanceTaxInfoSubtitle => 'Required for compliance purposes.';

  @override
  String get balanceIdentityTitle => 'Identity verification';

  @override
  String get balanceIdentitySubtitle => 'Get your ID ready.';

  @override
  String get balanceAddPayoutMethod => 'Add payout method';

  @override
  String get balanceCountryRegion => 'Country / region';

  @override
  String get balanceCountryRegionNote => 'You can only register for one country or region. Make sure your selection is correct.';

  @override
  String get balanceChoosePayoutMethod => 'Choose payout method';

  @override
  String get balancePayoutZaloPay => 'ZaloPay (VND)';

  @override
  String get balancePayoutZaloPayDetails => 'Service fee 1.5% | Min. withdrawal 2 USD | Arrives in 1 business day';

  @override
  String get balancePayoutBank => 'Bank transfer (VND)';

  @override
  String get balancePayoutBankDetails => 'Service fee 2.9 USD | Min. withdrawal 8 USD | Arrives in 3-5 business days';

  @override
  String get balancePayoutPayPal => 'PayPal (USD)';

  @override
  String get balancePayoutPayPalDetails => 'Service fee 1.5% + 0.1 USD | Min. withdrawal 1 USD | Arrives in 1 business day';

  @override
  String get balanceTransactionHistory => 'Transaction history';

  @override
  String get balanceTransactionDetails => 'Transaction details';

  @override
  String get balanceTransactionNotFound => 'Transaction not found';

  @override
  String get balanceNoTransactions => 'No transactions yet';

  @override
  String get balanceTabAll => 'All';

  @override
  String get balanceTabRevenue => 'Revenue';

  @override
  String get balanceTabExpense => 'Expense';

  @override
  String get balanceTabPayout => 'Payout';

  @override
  String get balanceTabRefund => 'Refund';

  @override
  String get balanceDetailStatus => 'Status';

  @override
  String get balanceStatusCompleted => 'Completed';

  @override
  String get balanceDetailType => 'Type';

  @override
  String get balanceDetailActivityType => 'Activity type';

  @override
  String get balanceDetailPaymentMethod => 'Payment method';

  @override
  String get balanceDetailCreated => 'Created';

  @override
  String get balanceDetailUpdated => 'Updated';

  @override
  String get balanceDetailTransactionId => 'Transaction ID';

  @override
  String get balanceCopied => 'Copied to clipboard';

  @override
  String get balanceNeedHelp => 'Need help? >';

  @override
  String get deleteChatTitle => 'Delete chat';

  @override
  String get deleteChatMessage => 'Are you sure you want to delete this conversation? This action cannot be undone.';

  @override
  String get deleteChatConfirm => 'Delete';

  @override
  String get deleteForEveryone => 'Delete for everyone';

  @override
  String get cameraFlip => 'Flip';

  @override
  String get cameraFlash => 'Flash';

  @override
  String get cameraSwitch => 'Switch camera';

  @override
  String get cameraSpeed => 'Speed';

  @override
  String get cameraBeauty => 'Retouch';

  @override
  String get cameraFilters => 'Filters';

  @override
  String get cameraTimer => 'Timer';

  @override
  String get cameraSetCountdown => 'Set countdown';

  @override
  String get cameraStartCountdown => 'Start countdown';

  @override
  String get cameraDragRecordingLimit => 'Drag to set recording limit';

  @override
  String get cameraMusic => 'Music';

  @override
  String get cameraEffects => 'Effects';

  @override
  String get cameraUpload => 'Upload from library';

  @override
  String get cameraOriginalSound => 'Original Sound';

  @override
  String get cameraSeconds => 'seconds';

  @override
  String get cameraRecording => 'Recording';

  @override
  String get cameraMusicComingSoon => 'Music selection is coming soon.';

  @override
  String get cameraPermissionDenied => 'Camera and microphone permissions are required to record.';

  @override
  String get cameraStarting => 'Starting camera...';

  @override
  String get cameraOpenSettings => 'Open settings';

  @override
  String get cameraUnavailable => 'No camera was found on this device.';

  @override
  String cameraInitError(String error) {
    return 'Could not start the camera: $error';
  }

  @override
  String cameraCaptureError(String error) {
    return 'Capture failed: $error';
  }

  @override
  String get cameraCategoryTrending => 'Trending';

  @override
  String get cameraCategoryNew => 'New';

  @override
  String get cameraCategoryPortrait => 'Portrait';

  @override
  String get cameraCategoryVibe => 'Vibe';

  @override
  String get cameraCategoryLandscape => 'Landscape';

  @override
  String get cameraFilterOriginal => 'Original';

  @override
  String get cameraFilterWarm => 'Warm';

  @override
  String get cameraFilterCool => 'Cool';

  @override
  String get cameraFilterSunny => 'Sunny';

  @override
  String get cameraFilterPink => 'Pink';

  @override
  String get cameraFilterMoody => 'Moody';

  @override
  String get cameraFilterBw => 'B&W';

  @override
  String get cameraFilterRetro => 'Retro';

  @override
  String get cameraFilterFlashVintage => 'Flash';

  @override
  String get cameraFilterBeautyGlow => 'Glow';

  @override
  String get cameraFilterNaturalBright => 'Natural';

  @override
  String get cameraFilterGoldenHour => 'Golden';

  @override
  String get openCameraStudio => 'Open camera';

  @override
  String get cameraModePhoto => 'PHOTO';

  @override
  String get cameraModeVideo => 'Video';

  @override
  String get cameraModeLive => 'LIVE';

  @override
  String get cameraModeText => 'TEXT';

  @override
  String get cameraAddSound => 'Add sound';

  @override
  String get cameraMuteOriginalSound => 'Mute original sound';

  @override
  String get cameraLayout => 'Layout';

  @override
  String get cameraAspectRatio => 'Ratio';

  @override
  String get cameraTabPost => 'Post';

  @override
  String get cameraTabCreative => 'Create';

  @override
  String get cameraDuration10m => '10m';

  @override
  String get cameraZoom => 'Zoom';

  @override
  String get cameraZoomOut => 'Zoom out';

  @override
  String get cameraZoomIn => 'Zoom in';

  @override
  String get cameraGoLive => 'Go LIVE';

  @override
  String get cameraLiveTitleHint => 'Add a title';

  @override
  String get cameraLiveComingSoon => 'Live streaming is coming soon.';

  @override
  String get cameraEffectCrown => 'Crown';

  @override
  String get cameraEffectBunny => 'Bunny';

  @override
  String get cameraEffectSunglasses => 'Shades';

  @override
  String get cameraEffectDog => 'Dog';

  @override
  String get cameraEffectHearts => 'Hearts';

  @override
  String get cameraEffectSparkle => 'Sparkle';

  @override
  String get cameraEffectNeon => 'Neon';

  @override
  String get cameraEffectGlitch => 'Glitch';

  @override
  String get cameraEffectGlasses => 'Glasses';

  @override
  String get cameraEffectMoustache => 'Moustache';

  @override
  String get cameraEffectBigEyes => 'Big Eyes';

  @override
  String get cameraEffectBigLips => 'Big Lips';

  @override
  String get cameraEffectNose => 'Nose';

  @override
  String get cameraFilterPure => 'Pure';

  @override
  String get cameraFilterBright => 'Bright';

  @override
  String get cameraFilterClean => 'Clean';

  @override
  String get cameraFilterSoft => 'Soft';

  @override
  String get cameraFilterSunset => 'Sunset';

  @override
  String get cameraCategoryLife => 'Life';

  @override
  String get mediaEditorShare => 'Share';

  @override
  String get mediaEditorText => 'Text';

  @override
  String get mediaEditorStickers => 'Stickers';

  @override
  String get mediaEditorCrop => 'Crop';

  @override
  String get mediaEditorEdit => 'Edit';

  @override
  String get mediaEditorMore => 'More';

  @override
  String get mediaEditorComingSoon => 'Coming soon';

  @override
  String get mediaEditorDone => 'Done';

  @override
  String get mediaEditorTrim => 'Trim';

  @override
  String get videoEditorSplit => 'Split';

  @override
  String get videoEditorDeleteSegment => 'Delete';

  @override
  String get mediaEditorReset => 'Reset';

  @override
  String get mediaEditorDiscard => 'Discard';

  @override
  String get mediaEditorSaveDraft => 'Save draft';

  @override
  String get mediaEditorContinueEditing => 'Continue editing';

  @override
  String get mediaEditorSendToFriends => 'Send to friends';

  @override
  String get mediaEditorDiscardTitle => 'Discard changes?';

  @override
  String get mediaPhotoEditorFace => 'Beauty';

  @override
  String get mediaPhotoEditorMakeup => 'Makeup';

  @override
  String get mediaPhotoEditorLipstick => 'Lipstick';

  @override
  String get mediaPhotoEditorBlush => 'Blush';

  @override
  String get mediaPhotoEditorEyeliner => 'Eyeliner';

  @override
  String get mediaPhotoEditorEyeshadow => 'Shadow';

  @override
  String get mediaPhotoEditorFoundation => 'Foundation';

  @override
  String get mediaPhotoEditorContour => 'Contour';

  @override
  String get mediaPhotoEditorUnderEye => 'Under-eye';

  @override
  String get mediaPhotoEditorBrightenEye => 'Brighten eye';

  @override
  String get mediaPhotoEditorMagic => 'Magic';

  @override
  String get mediaPhotoEditorOff => 'Off';

  @override
  String get mediaPhotoEditorSmooth => 'Smooth';

  @override
  String get mediaPhotoEditorSaturation => 'Saturation';

  @override
  String get mediaPhotoEditorBrightness => 'Brightness';

  @override
  String get mediaPhotoEditorContrast => 'Contrast';

  @override
  String get mediaPhotoEditorShape => 'Shape';

  @override
  String get mediaPhotoEditorEyes => 'Eyes';

  @override
  String get mediaPhotoEditorTooth => 'Tooth';

  @override
  String get mediaPhotoEditorMouth => 'Mouth';

  @override
  String get mediaPhotoEditorExposure => 'Exposure';

  @override
  String get mediaPhotoEditorWhiteBalance => 'Warmth';

  @override
  String get mediaPhotoEditorHighlights => 'Highlights';

  @override
  String get mediaPhotoEditorShadows => 'Shadows';

  @override
  String get mediaPhotoEditorNose => 'Nose';

  @override
  String get mediaPhotoEditorOn => 'On';

  @override
  String get mediaTextHint => 'Type something';

  @override
  String get promotePostTitle => 'Promote post';

  @override
  String get promotionScreenTitle => 'Promotion';

  @override
  String get promotePostAction => 'Promote';

  @override
  String get promoteGoalTitle => 'Choose your goal';

  @override
  String get promoteAudienceTitle => 'Define your audience';

  @override
  String get promoteAgeRange => 'Age range';

  @override
  String get promoteGeoTarget => 'Target people nearby';

  @override
  String get promoteGeoTargetHint => 'Use your current location for local reach';

  @override
  String get promoteGeoMapHint => 'Tap the map to choose your target area. Default is your location.';

  @override
  String get promoteGeoUseMyLocation => 'Use my location';

  @override
  String get promoteGeoPlaceLoading => 'Looking up place…';

  @override
  String get promoteGeoCity => 'City';

  @override
  String get promoteGeoRegion => 'Region';

  @override
  String get promoteGeoTown => 'Town';

  @override
  String get promoteGeoCountry => 'Country';

  @override
  String get promoteGeoContinent => 'Continent';

  @override
  String get promoteBudgetTitle => 'Select budget';

  @override
  String get promoteProcessing => 'Processing...';

  @override
  String promotePostCta(String price) {
    return 'Promote for $price';
  }

  @override
  String promotePostSuccess(String balance) {
    return 'Promotion started! Wallet balance: $balance';
  }

  @override
  String get promotedBadge => 'Promoted';

  @override
  String get promoteLanguages => 'Languages';

  @override
  String get promoteInterests => 'Interests';

  @override
  String promoteRadiusKm(int km) {
    return 'Radius: $km km';
  }

  @override
  String get promotePayFailedTitle => 'Payment failed';

  @override
  String get promoteRetryPay => 'Retry payment';

  @override
  String get promoteAudienceCustomize => 'Customize audience';

  @override
  String get promoteAudienceAllGenders => 'All genders';

  @override
  String get promoteAudienceNearby => 'Nearby';

  @override
  String get promoteAudienceGender => 'Gender';

  @override
  String get promotePostNoCaption => 'No caption';

  @override
  String get promotePopularBadge => 'POPULAR';

  @override
  String promoteImpressions(int count) {
    return '$count impressions';
  }

  @override
  String get promoteStepGoalHeading => 'What is your goal?';

  @override
  String get promoteStepGoalSubtitle => 'Choose a goal for promoting this video.';

  @override
  String get promoteStepAudienceSubtitle => 'Select how you want to reach your audience for your promotion.';

  @override
  String get promoteAudienceDefault => 'Default audience';

  @override
  String get promoteAudienceDefaultHint => 'We\'ll choose the best audience for you';

  @override
  String get promoteAudienceCreateOwn => 'Create your own';

  @override
  String get promoteStepLocationHeading => 'Choose your target area';

  @override
  String get promoteStepLocationSubtitle => 'Detect your location and set a radius to reach people nearby.';

  @override
  String get promoteStepBudgetSubtitle => 'Choose a promotion package for your campaign.';

  @override
  String promoteBudgetTotal(String price) {
    return '$price total';
  }

  @override
  String promoteEstimatedViews(String min, String max) {
    return '$min – $max';
  }

  @override
  String get promoteEstimatedViewsLabel => 'Estimated video views';

  @override
  String get promoteOverviewTitle => 'Overview';

  @override
  String get promoteOverviewGoal => 'Goal';

  @override
  String get promoteOverviewAudience => 'Audience';

  @override
  String get promoteOverviewLocation => 'Location';

  @override
  String get promoteOverviewBudget => 'Budget';

  @override
  String get promoteLocationOff => 'Location targeting off';

  @override
  String get promoteLocationPending => 'Location not set';

  @override
  String promoteAudienceNearbyWithRadius(int km) {
    return 'Nearby · $km km';
  }

  @override
  String get promoteLocationModeRegional => 'Regionally';

  @override
  String get promoteLocationModeRegionalHint => 'Choose country, region, and town';

  @override
  String get promoteLocationModeMap => 'On map';

  @override
  String get promoteLocationModeMapHint => 'Detect GPS and pick a radius on the map';

  @override
  String get promoteSelectCountry => 'Country';

  @override
  String get promoteSelectCountryHint => 'Select country';

  @override
  String get promoteSelectRegion => 'Region';

  @override
  String get promoteSelectRegionHint => 'Select region';

  @override
  String get promoteSelectTown => 'Town';

  @override
  String get promoteSelectTownHint => 'Select town';

  @override
  String promoteLocationRegionalSummary(String town, String region, String country) {
    return '$town · $region · $country';
  }

  @override
  String get promoteLocationCountryRequired => 'Please select a country.';

  @override
  String get promoteLocationRegionRequired => 'Please select a region.';

  @override
  String get promoteLocationTownRequired => 'Please select a town.';

  @override
  String get promoteLocationTownCoordinatesRequired => 'This town has no coordinates. Please choose another town.';

  @override
  String get promoteLocationMapRequired => 'Please allow location or pick a point on the map.';

  @override
  String get promoteOverviewSubtotal => 'Subtotal';

  @override
  String get promoteOverviewTotal => 'Total';

  @override
  String get promoteNext => 'Next';

  @override
  String get promotePayStart => 'Pay and start promotion';

  @override
  String get promoteQuickPack => 'Ready-to-use promotion pack';

  @override
  String promoteStepOf(int current, int total) {
    return 'Step $current of $total';
  }

  @override
  String get promoteInsightsDashboardTitle => 'Promoted posts';

  @override
  String get promoteInsightsTitle => 'Promotion insights';

  @override
  String get promoteInsightsEmptyTitle => 'No promoted posts yet';

  @override
  String get promoteInsightsEmptyHint => 'Promote a video from your feed to see performance here.';

  @override
  String get promoteInsightsPerformanceTitle => 'Performance';

  @override
  String get promoteInsightsPromotedImpressions => 'Promoted impressions';

  @override
  String get promoteInsightsFollowersGained => 'Followers gained';

  @override
  String get promoteInsightsSpend => 'Promotion spend';

  @override
  String get promoteInsightsEngagementRate => 'Engagement rate';

  @override
  String get promoteInsightsShares => 'Shares';

  @override
  String get promoteInsightsCostPerImpression => 'Cost / impression';

  @override
  String get promoteInsightsCostPerView => 'Cost / view';

  @override
  String get promoteInsightsUniqueViewers => 'Unique viewers';

  @override
  String get promoteInsightsChartTitle => 'Impressions (last 7 days)';

  @override
  String get promoteInsightsNoChartData => 'No impression data yet';

  @override
  String get promoteInsightsCampaignProgress => 'Campaign progress';

  @override
  String get promoteInsightsImpressions => 'Impressions';

  @override
  String get promoteInsightsBudget => 'Budget';

  @override
  String get promoteInsightsPauseCampaign => 'Pause campaign';

  @override
  String get promoteInsightsResumeCampaign => 'Resume campaign';

  @override
  String get promoteInsightsCampaignHistory => 'Campaign history';

  @override
  String get promoteInsightsCampaignHistoryHint => 'Tap a campaign to filter stats';

  @override
  String get promoteInsightsAllCampaigns => 'All campaigns';

  @override
  String get promoteInsightsMultipleCampaigns => 'Multiple campaigns';

  @override
  String get promoteInsightsViewInsights => 'View insights';

  @override
  String get promoteInsightsObjectiveViews => 'Video views';

  @override
  String get promoteInsightsObjectiveFollowers => 'Followers';

  @override
  String get promoteInsightsObjectiveEngagement => 'Engagement';

  @override
  String get promoteInsightsObjectiveChallenges => 'Challenges';

  @override
  String get promoteInsightsObjectiveProfileVisits => 'Profile visits';

  @override
  String get promoteInsightsObjectiveSales => 'Sales';

  @override
  String get promoteInsightsStatusActive => 'Active';

  @override
  String get promoteInsightsStatusPaused => 'Paused';

  @override
  String get promoteInsightsStatusPendingPayment => 'Pending payment';

  @override
  String get promoteInsightsStatusCompleted => 'Completed';

  @override
  String get promoteInsightsStatusCancelled => 'Cancelled';

  @override
  String promoteInsightsCampaignProgressSummary(String percent, String spent) {
    return '$percent · $spent spent';
  }

  @override
  String get settingsPromotedPosts => 'Promoted posts';

  @override
  String get soundLabel => 'Sound';

  @override
  String get soundNoneSelected => 'None';

  @override
  String get soundPickerTitle => 'Add sound';

  @override
  String get soundSearchHint => 'Search sounds';

  @override
  String get soundTabTrending => 'Trending';

  @override
  String get soundTabBrowse => 'Browse';

  @override
  String get soundTabMine => 'My sounds';

  @override
  String get soundTabHot => 'Hot';

  @override
  String get soundTabForYou => 'For You';

  @override
  String get soundTabFavorites => 'Favorites';

  @override
  String get soundTabRecent => 'Recent';

  @override
  String get soundTabAll => 'All';

  @override
  String get soundPickerEmpty => 'No sounds found';

  @override
  String get soundPickFromFiles => 'Pick from files';

  @override
  String get soundTrimTooltip => 'Trim';

  @override
  String get soundFavoriteTooltip => 'Favorite';

  @override
  String soundSecondsSelected(int count) {
    return '${count}s selected';
  }

  @override
  String get soundUseThis => 'Use';

  @override
  String get soundUseThisSound => 'Use this sound';

  @override
  String get soundUseSoundCta => 'Use sound';

  @override
  String get soundSave => 'Save';

  @override
  String get soundSaved => 'Saved';

  @override
  String get soundAddToStory => 'Add to Story';

  @override
  String get soundFindRelatedHint => 'Find related content';

  @override
  String get soundOriginalBadge => 'Original';

  @override
  String get soundConfirmSelection => 'Use selected sound';

  @override
  String get soundClearSelection => 'Remove music';

  @override
  String get soundDetailTitle => 'Sound';

  @override
  String get soundVideosUsing => 'Videos using this sound';

  @override
  String get soundNoVideosYet => 'No videos yet';

  @override
  String soundOriginalLink(String name) {
    return 'Original: $name';
  }

  @override
  String soundUseCount(int count) {
    return '$count videos';
  }

  @override
  String soundUseCountThousands(String count) {
    return '${count}K videos';
  }

  @override
  String soundUseCountMillions(String count) {
    return '${count}M videos';
  }

  @override
  String soundPostsCount(int count) {
    return '$count posts';
  }

  @override
  String soundPostsCountThousands(String count) {
    return '${count}K posts';
  }

  @override
  String soundPostsCountMillions(String count) {
    return '${count}M posts';
  }

  @override
  String get interestSelectionTitle => 'Choose your interests';

  @override
  String get interestSelectionSubtitle => 'Pick a few categories so we can personalize your experience.';

  @override
  String get interestSelectionSkip => 'Skip';

  @override
  String get interestSelectionContinue => 'Continue';

  @override
  String interestSelectionMinHint(int count) {
    return 'Select at least $count interests';
  }

  @override
  String interestSelectionCountHint(int selected, int min) {
    return '$selected/$min interested';
  }

  @override
  String get interestSelectionNotInterestedHint => 'Tap again to mark as not interested (optional).';

  @override
  String get interestSelectionNotInterestedLegend => 'Not interested';

  @override
  String get interestSelectionInterestedLegend => 'Interested';

  @override
  String get interestSelectionSave => 'Save';

  @override
  String get settingsInterests => 'Interests';

  @override
  String get settingsMyProducts => 'My Products';

  @override
  String get shopGoToMyProducts => 'Go to My Products';

  @override
  String get shopMakeAuction => 'Show on live';

  @override
  String get shopMyProductsSearchHint => 'Search my products...';

  @override
  String get shopFilterAll => 'All';

  @override
  String get shopNoMatchingProducts => 'No matching products';

  @override
  String get shopSortQuantityHigh => 'Qty: High';

  @override
  String get shopSortQuantityLow => 'Qty: Low';

  @override
  String get shopFilters => 'Filters';

  @override
  String get shopMediaType => 'Media';

  @override
  String get shopMediaImage => 'Image';

  @override
  String get shopMediaVideo => 'Video';

  @override
  String get shopMediaCarousel => 'Carousel';

  @override
  String get shopMinPriceCoins => 'Min coins';

  @override
  String get shopMaxPriceCoins => 'Max coins';

  @override
  String get shopApplyFilters => 'Apply';

  @override
  String get shopClearFilters => 'Clear';

  @override
  String get retry => 'Try again';

  @override
  String get seeTranslation => 'See translation';

  @override
  String get seeOriginal => 'See original';

  @override
  String get translationFailed => 'Could not translate';

  @override
  String get postLinksTitle => 'Links';

  @override
  String get tryEffectAction => 'Try effect';

  @override
  String get effectsSubtitle => 'Effects';

  @override
  String get templateExportPreparing => 'Preparing…';

  @override
  String get templateExportUploading => 'Uploading…';

  @override
  String get templateExportUploaded => 'Uploaded';

  @override
  String get templateExportPreparingSlots => 'Preparing slots…';

  @override
  String get templateExportRendering => 'Rendering…';

  @override
  String get templateExportAlmostDone => 'Almost done…';

  @override
  String get templateExportDownloading => 'Downloading…';

  @override
  String get templateExportDone => 'Done';

  @override
  String get templateExportFailed => 'Template export failed — try again';

  @override
  String get templateCouldNotLoad => 'Could not load template';

  @override
  String get templatePreviewFailed => 'Template preview failed';

  @override
  String get templateHandoffFailed => 'Could not hand off template video';

  @override
  String get templateApplying => 'Applying template…';

  @override
  String get templateAddMediaToPreview => 'Add media to preview';

  @override
  String get templateNeedMediaFirst => 'Take or add a photo/video first';

  @override
  String get mediaStudioTemplates => 'Templates';

  @override
  String get pinToTop => 'Pin to top';

  @override
  String get unpin => 'Unpin';

  @override
  String get pinnedToTopSuccess => 'Pinned to top of profile';

  @override
  String get unpinnedSuccess => 'Unpinned from profile';

  @override
  String get closeFriendsTab => 'Close Friends';

  @override
  String get addCloseFriendsTitle => 'Add Close Friends';

  @override
  String get addCloseFriendsSubtitle => 'Choose friends to add to your close friends list';

  @override
  String get searchCloseFriendsHint => 'Search close friends...';

  @override
  String get noCloseFriendsYet => 'No close friends added yet.';

  @override
  String get profileLinksTitle => 'Links';

  @override
  String get noLinksAddedYet => 'No links added yet.';

  @override
  String get accountTypePersonal => 'Personal';

  @override
  String get accountTypeCreator => 'Creator';

  @override
  String get accountTypeBusiness => 'Business';

  @override
  String get badgeOfficial => 'Official';

  @override
  String get badgeCreator => 'Creator';

  @override
  String get addToHighlights => 'Add to highlights';

  @override
  String get newHighlight => 'New highlight';

  @override
  String get editCover => 'Edit cover';

  @override
  String get highlightsTitle => 'Highlights';

  @override
  String get noStoriesInArchive => 'No stories found in archive';

  @override
  String get removeFromHighlight => 'Remove from Highlight';

  @override
  String get highlightCreated => 'Highlight created';

  @override
  String get highlightUpdated => 'Highlight updated';

  @override
  String get chooseFromGallery => 'Choose from Gallery';

  @override
  String get pasteImageUrl => 'Paste Image URL';

  @override
  String get newHighlightButton => 'New';

  @override
  String get aboutThisStory => 'About this story';

  @override
  String get editHighlight => 'Edit highlight';

  @override
  String get deleteHighlight => 'Delete Highlight';

  @override
  String get highlightDeleted => 'Highlight deleted';

  @override
  String get highlightEmptyRemoved => 'This highlight is empty and was removed';

  @override
  String get highlightNameLabel => 'Highlight Name';

  @override
  String get highlightNameHint => 'e.g. Travel, Memories';

  @override
  String get coverUpdated => 'Cover updated';

  @override
  String get failedToUploadCover => 'Failed to upload cover image';

  @override
  String get failedToLoadHighlightDetails => 'Failed to load highlight details';

  @override
  String get failedToAddStoryToHighlight => 'Failed to add story to highlight';

  @override
  String get marketplaceTitle => 'Marketplace';

  @override
  String get marketplaceLikedProducts => 'Liked Products';

  @override
  String get marketplaceNoLikedProducts => 'No liked products yet';

  @override
  String get marketplaceTagline => 'Buy. Own. Resell.';

  @override
  String get marketplaceSearchHint => 'Search products, brands, categories...';

  @override
  String get marketplaceHeroTitle => 'Buy. Own. Resell.';

  @override
  String get marketplaceHeroSubtitle => 'Purchase products and resell eligible purchases through Bimo-Bond auctions.';

  @override
  String get marketplaceExploreCta => 'Explore Marketplace';

  @override
  String get marketplaceCategories => 'Categories';

  @override
  String get marketplaceRecommended => 'Recommended for You';

  @override
  String get marketplaceEndingSoon => 'Ending Soon Auctions';

  @override
  String get marketplaceNoAuctions => 'No active auctions ending soon';

  @override
  String get marketplaceLiveAuction => 'LIVE AUCTION';

  @override
  String get marketplaceAuctionLabel => 'AUCTION';

  @override
  String get marketplaceCurrentBid => 'Current Bid';

  @override
  String marketplaceBidCount(int count) {
    return '$count Bids';
  }

  @override
  String get marketplaceViewAuction => 'View Auction';

  @override
  String get marketplaceFilters => 'Filters';

  @override
  String get marketplaceFilterPrice => 'Price';

  @override
  String get marketplaceMin => 'Min';

  @override
  String get marketplaceMax => 'Max';

  @override
  String get marketplaceFilterListingType => 'Listing type';

  @override
  String get marketplaceInStockOnly => 'In stock only';

  @override
  String get marketplaceClearFilters => 'Clear';

  @override
  String get marketplaceApplyFilters => 'Apply';

  @override
  String get marketplaceSortPopular => 'Popular';

  @override
  String get marketplaceSortEndingSoon => 'Ending Soon';

  @override
  String marketplaceProductCount(int count) {
    return '$count Products';
  }

  @override
  String get marketplaceTabPurchased => 'Purchased';

  @override
  String get marketplaceTabPending => 'Pending Delivery';

  @override
  String get marketplaceTabDelivered => 'Delivered';

  @override
  String get marketplaceTabAuctioned => 'Auctioned';

  @override
  String get marketplaceTabSold => 'Sold';

  @override
  String get marketplaceNoProducts => 'No products in this tab';

  @override
  String get marketplacePurchaseConfirmed => 'Purchase Confirmed';

  @override
  String get marketplaceDeliveryLabel => 'Delivery';

  @override
  String get marketplaceDeliveryPending => 'Pending';

  @override
  String get marketplaceDeliveryShipped => 'Shipped';

  @override
  String get marketplaceDeliveryDelivered => 'Delivered';

  @override
  String get marketplaceTrackDelivery => 'Track Delivery';

  @override
  String get marketplaceSellAtAuction => 'Sell at Auction';

  @override
  String get marketplacePurchasePrice => 'Purchase price';

  @override
  String get marketplaceStartingPrice => 'Starting Price';

  @override
  String get marketplaceReservePrice => 'Reserve Price';

  @override
  String get marketplaceBuyNowPrice => 'Buy Now Price';

  @override
  String get marketplaceAuctionDuration => 'Auction Duration';

  @override
  String get marketplaceDescription => 'Description';

  @override
  String get marketplaceAuctionPreview => 'Auction Preview';

  @override
  String get marketplacePublishAuction => 'Publish Auction';

  @override
  String get marketplaceAuctionPublished => 'Auction published';

  @override
  String get marketplacePlaceBid => 'Place Bid';

  @override
  String get marketplaceYourBid => 'Your Bid';

  @override
  String get marketplaceConfirmBid => 'Confirm Bid';

  @override
  String get marketplaceEndsIn => 'Ends in';

  @override
  String get marketplaceBidHistory => 'Bid history';

  @override
  String get marketplaceNoBidsYet => 'No bids yet';

  @override
  String get marketplaceSpecifications => 'Specifications';

  @override
  String get marketplaceVerifiedProduct => 'Verified Product';

  @override
  String get marketplaceSecurePayment => 'Secure Payment';

  @override
  String get marketplaceBuyerProtection => 'Buyer Protection';

  @override
  String get marketplaceDeliveryTracking => 'Delivery Tracking';

  @override
  String get templateEditorSound => 'Sound';

  @override
  String get templateEditorText => 'Text';

  @override
  String get templateEditorEffects => 'Effects';

  @override
  String get templateEditorFilters => 'Filters';

  @override
  String get templateEditorTransitions => 'Transitions';

  @override
  String get templateEditorStickers => 'Stickers';

  @override
  String get templateEditorCopy => 'Copy';

  @override
  String get templateEditorDelete => 'Delete';

  @override
  String get templateEditorLayers => 'Layers';

  @override
  String get templateEditorNone => 'None';

  @override
  String get templateEditorTrending => 'Trending';

  @override
  String get templateEditorApply => 'Apply';

  @override
  String get templateEditorDefault => 'Default';

  @override
  String get templateEditorPhoto => 'Photo';

  @override
  String get templateEditorVideo => 'Video';

  @override
  String get templateEditorFont => 'Font';

  @override
  String get templateEditorAddText => 'Add text';

  @override
  String get templateEditorReplaceText => 'Replace text';

  @override
  String get templateEditorReplaceSticker => 'Replace sticker';

  @override
  String get templateEditorReplaceFilter => 'Replace filter';

  @override
  String get templateEditorReplaceEffect => 'Replace effect';

  @override
  String get templateEditorReplaceTransition => 'Replace transition';

  @override
  String get templateEditorReplaceMusic => 'Replace music';

  @override
  String templateEditorAddFilterClip(int clip) {
    return 'Add filter · clip $clip';
  }

  @override
  String templateEditorAddEffectClip(int clip) {
    return 'Add effect · clip $clip';
  }

  @override
  String get templateEditorAddTransition => 'Add transition';

  @override
  String get templateEditorFilterLayers => 'Filter layers';

  @override
  String get templateEditorEffectLayers => 'Effect layers';

  @override
  String get templateEditorServerPreview => 'Server preview';

  @override
  String get templateEditorContinueWithRender => 'Tap → to continue with this render';

  @override
  String get templateEditorTypeBelow => 'Type below…';

  @override
  String get templateEditorTypeCaption => 'Type your caption…';

  @override
  String get templateEditorDragPinchResize => 'Drag to move · Pinch to resize';

  @override
  String get templateEditorTapMediaToPlace => 'Tap media to place · Drag to move';

  @override
  String get templateEditorPickStickerBelow => 'Pick a sticker below';

  @override
  String get templateEditorTapStickerBelow => 'Tap a sticker below';

  @override
  String get templateEditorDragResizeSticker => 'Drag to move · Pinch or ± to resize';

  @override
  String templateEditorMaxFiltersPerClip(int count) {
    return 'Max $count filters per clip';
  }

  @override
  String templateEditorMaxEffectsPerClip(int count) {
    return 'Max $count effects per clip';
  }

  @override
  String get templateEditorTransitionsNeedClips => 'Transitions need at least 2 clips';

  @override
  String get templateEditorAddMediaAllSlots => 'Add media to all slots before rendering.';

  @override
  String get templateEditorCouldNotRender => 'Could not render on server';

  @override
  String get templateEditorExportFailed => 'Export failed';

  @override
  String get templateEditorPresetNone => 'None';

  @override
  String get templateEditorPresetCinematic => 'Cinematic';

  @override
  String get templateEditorPresetWarm => 'Warm';

  @override
  String get templateEditorPresetCool => 'Cool';

  @override
  String get templateEditorPresetVintage => 'Vintage';

  @override
  String get templateEditorPresetVivid => 'Vivid';

  @override
  String get templateEditorPresetFade => 'Fade';

  @override
  String get templateEditorPresetBw => 'B&W';

  @override
  String get templateEditorPresetZoomIn => 'Zoom in';

  @override
  String get templateEditorPresetZoomOut => 'Zoom out';

  @override
  String get templateEditorPresetShake => 'Shake';

  @override
  String get templateEditorPresetPulse => 'Pulse';

  @override
  String get templateEditorPresetCrossfade => 'Crossfade';

  @override
  String get templateEditorPresetFlash => 'Flash';

  @override
  String get templateEditorPresetSlideLeft => 'Slide left';

  @override
  String get templateEditorPresetSlideRight => 'Slide right';

  @override
  String get templateEditorPresetZoom => 'Zoom';

  @override
  String get templateEditorPresetBlur => 'Blur';

  @override
  String get templateEditorPresetGlitch => 'Glitch';

  @override
  String get templateEditorPresetFilmBurn => 'Film burn';

  @override
  String get templateEditorClipReplace => 'Replace';

  @override
  String get templateEditorClipVolume => 'Volume';

  @override
  String get templateEditorClipReduceNoise => 'Reduce noise';

  @override
  String get templateEditorClipRotate => 'Rotate';

  @override
  String get templateEditorClipBeautify => 'Beautify';

  @override
  String get templateEditorClipAdjust => 'Adjust';

  @override
  String get templateEditorClipOverlay => 'Overlay';

  @override
  String get templateEditorClipReverse => 'Reverse';

  @override
  String get templateEditorClipFreeze => 'Freeze';

  @override
  String get templateEditorClipMask => 'Mask';

  @override
  String get templateEditorClipOpacity => 'Opacity';

  @override
  String get templateEditorClipVoiceEffect => 'Voice effect';

  @override
  String get templateEditorClipAnimation => 'Animation';

  @override
  String get templateEditorClipCutout => 'Cutout';

  @override
  String get templateEditorClipBackground => 'Background';

  @override
  String get templateEditorClipMagic => 'Magic';

  @override
  String get templateEditorClipComingSoon => 'Coming soon';

  @override
  String get livePromotionPromotedLabel => 'Promoted';

  @override
  String get lpTitle => 'Promote LIVE';

  @override
  String get lpMine => 'My LIVE promotions';

  @override
  String get lpPreLive => 'Start your public LIVE first, then open Share → Promote. This camera preview has no saved LIVE to promote.';

  @override
  String get lpUnavailable => 'LIVE promotions are temporarily unavailable. Please try again later.';

  @override
  String get lpEligibility => 'Only the host of a public planned or active LIVE can promote it, using an account that is neither private nor banned. Eligibility must be confirmed.';

  @override
  String get lpDisabled => 'LIVE promotions are currently disabled.';

  @override
  String get lpObjective => 'Your goal';

  @override
  String get lpViews => 'More viewers';

  @override
  String get lpFollowers => 'More followers';

  @override
  String get lpAudience => 'Audience';

  @override
  String get lpAutomatic => 'Automatic audience';

  @override
  String get lpCustomAudience => 'Custom audience';

  @override
  String get lpAutomaticHint => 'Let the service select people likely to watch your LIVE.';

  @override
  String get lpGenders => 'Genders';

  @override
  String get lpAgeMin => 'Minimum age (optional)';

  @override
  String get lpAgeMax => 'Maximum age (optional)';

  @override
  String get lpCountries => 'Countries';

  @override
  String get lpLanguages => 'Languages';

  @override
  String get lpCategories => 'Interests';

  @override
  String get lpOptionsUnavailable => 'Audience options are unavailable. Retry to load them.';

  @override
  String get lpGeo => 'Geographic targeting (optional)';

  @override
  String get lpLatitude => 'Latitude';

  @override
  String get lpLongitude => 'Longitude';

  @override
  String get lpRadius => 'Radius in km';

  @override
  String get lpPickMap => 'Choose on map';

  @override
  String get lpClearGeo => 'Clear location';

  @override
  String get lpBudget => 'Budget';

  @override
  String get lpCustomBudget => 'Custom budget';

  @override
  String get lpPackage => 'Package';

  @override
  String get lpPackagesUnavailable => 'Packages are unavailable. You can prepare a custom budget.';

  @override
  String get lpCoins => 'Coins';

  @override
  String get lpDuration => 'Duration in days';

  @override
  String get lpEstimates => 'Estimated results';

  @override
  String get lpEstimateHint => 'Estimates are not guaranteed. Actual delivery depends on your LIVE and audience.';

  @override
  String get lpNoEstimates => 'Estimates are unavailable.';

  @override
  String get lpCreate => 'Create campaign';

  @override
  String get lpCreateHint => 'Creating a campaign does not pay for it. You will review and confirm payment separately.';

  @override
  String get lpSave => 'Save changes';

  @override
  String get lpEdit => 'Edit campaign';

  @override
  String get lpPay => 'Review payment';

  @override
  String get lpConfirmPay => 'Confirm and pay';

  @override
  String get lpCost => 'Campaign cost';

  @override
  String get lpBalance => 'Current coin balance';

  @override
  String get lpUnknown => 'Unavailable';

  @override
  String get lpRetry => 'Retry';

  @override
  String get lpRefresh => 'Refresh';

  @override
  String get lpCancel => 'Cancel campaign';

  @override
  String get lpCancelHint => 'Cancel this campaign? The server refunds unused prepaid coins. The updated balance may take a moment to appear.';

  @override
  String get lpBack => 'Back';

  @override
  String get lpPause => 'Pause';

  @override
  String get lpResume => 'Resume';

  @override
  String get lpEmpty => 'No LIVE promotions yet';

  @override
  String get lpEmptyHint => 'Open Share → Promote while hosting a public LIVE.';

  @override
  String get lpLoadMore => 'Load more';

  @override
  String get lpPending => 'Pending payment';

  @override
  String get lpActive => 'Active';

  @override
  String get lpPaused => 'Paused';

  @override
  String get lpCompleted => 'Completed';

  @override
  String get lpCancelled => 'Cancelled';

  @override
  String get lpUnknownStatus => 'Status unavailable — refresh';

  @override
  String get lpImpressions => 'Impressions';

  @override
  String get lpSpend => 'Coins spent';

  @override
  String get lpRemaining => 'Coins remaining';

  @override
  String get lpPaymentUnknown => 'Payment is being verified. Refresh campaign and balance before taking further action. Do not pay again while the outcome is unknown.';

  @override
  String get lpCleanup => 'LIVE has ended. Campaign status and any unused balance refund are being updated.';

  @override
  String get lpInsufficient => 'Your coin balance is insufficient. Top up, then refresh before confirming payment.';

  @override
  String get lpTopUp => 'Top up coins';

  @override
  String get lpValidation => 'Check the budget mode, minimum 5 coins, duration (1, 3, 7 or 14 days), age order, and complete valid geographic coordinates with a positive radius.';

  @override
  String get lpInteger => 'Enter a whole number.';

  @override
  String get lpNumber => 'Enter a valid finite number.';

  @override
  String get lpClose => 'Close promotions';

  @override
  String get liveMetricUnavailable => 'Not available';

  @override
  String get liveSummaryTitle => 'LIVE summary';

  @override
  String get liveSummaryEmpty => 'No summary available.';

  @override
  String get liveSummaryDuration => 'Duration (seconds)';

  @override
  String get liveSummaryPeak => 'Peak viewers';

  @override
  String get liveSummarySessions => 'Viewer sessions';

  @override
  String get liveSummaryLikes => 'Likes';

  @override
  String get liveSummaryComments => 'Comments';

  @override
  String get liveSummaryCoins => 'Earned coins';

  @override
  String get liveSummaryGifters => 'Top gifters';

  @override
  String get liveSummaryUnique => 'Unique viewers';

  @override
  String get liveSummaryWatch => 'Watch time (seconds)';

  @override
  String get liveSummaryAverage => 'Average watch time (seconds)';

  @override
  String get liveSummaryFollowers => 'New followers';

  @override
  String get liveSummaryShares => 'Shares';

  @override
  String get liveSummaryOrders => 'Shop orders';

  @override
  String get liveSummaryRevenue => 'Shop revenue (coins)';

  @override
  String get liveSummaryTraffic => 'Traffic sources';

  @override
  String get liveGiftGoalLabel => 'Gift goal';

  @override
  String get liveFanClubPriceUnavailable => 'Subscription prices are not verified yet. Joining is unavailable.';

  @override
  String get liveDiscoveryForYou => 'For You';

  @override
  String get liveDiscoveryFollowing => 'Following';

  @override
  String get liveDiscoveryNearby => 'Nearby';

  @override
  String get liveDiscoveryAudio => 'Audio';

  @override
  String get liveDiscoveryFilter => 'Filter LIVE';

  @override
  String get liveDiscoveryTopic => 'Topic';

  @override
  String get liveDiscoveryCategory => 'Category ID';

  @override
  String get liveLocationUnavailable => 'Enable location services and allow location access to see nearby LIVE streams.';

  @override
  String get liveGalleryReorder => 'Drag to reorder';

  @override
  String get liveLeagueTitle => 'Host league';

  @override
  String get liveLeagueProgress => 'Progress to next tier';

  @override
  String get liveReplayTitle => 'Replay and clips';

  @override
  String get liveRecordingStatus => 'Recording status';

  @override
  String get liveReplayStatus => 'Replay status';

  @override
  String get liveReplayUnavailable => 'Playback needs a verified response from the replay service.';

  @override
  String get liveCouponCode => 'Coupon code';

  @override
  String get liveApplyCoupon => 'Apply coupon';

  @override
  String get liveDeal => 'LIVE deal';

  @override
  String get liveDealPrice => 'Flash price (coins)';

  @override
  String get liveDealEnd => 'Flash ends at (ISO time)';

  @override
  String get liveDealDiscount => 'Coupon discount (coins)';

  @override
  String get liveDealSave => 'Save deal';

  @override
  String get liveDealSold => 'Sold';

  @override
  String get liveCouponAvailable => 'Coupon available';

  @override
  String get liveTicketEnabled => 'Paid entry';

  @override
  String get liveTicketPrice => 'Ticket price (coins)';

  @override
  String liveTicketBuy(int coins) {
    return 'Buy ticket for $coins coins';
  }

  @override
  String get liveTicketRequiredDetail => 'This LIVE requires a ticket before entry.';

  @override
  String get liveTicketUnavailable => 'Could not check entry access. Please refresh.';

  @override
  String get livePaymentUnresolved => 'Your payment is awaiting confirmation. Check its status before paying again.';

  @override
  String get liveTicketChecking => 'Checking entry access…';

  @override
  String get liveTicketTitle => 'LIVE entry';

  @override
  String get liveTicketRefresh => 'Check ticket status';

  @override
  String get liveEntryBack => 'Back';

  @override
  String get shopCouponLabel => 'LIVE coupon';

  @override
  String get shopCouponHint => 'Enter a coupon code';

  @override
  String get shopCouponApply => 'Apply';

  @override
  String get shopPreviewChanged => 'Your checkout details changed. Review the updated total before paying.';

  @override
  String get liveFanClubTiers => 'Membership tiers';

  @override
  String liveFanClubJoinTier(String tier) {
    return 'Join $tier';
  }

  @override
  String liveFanClubPriceCoins(int coins) {
    return '$coins coins for 30 days';
  }

  @override
  String get liveFanClubCurrentTier => 'Your current membership';

  @override
  String liveFanClubLoyalty(String badge) {
    return 'Loyalty: $badge';
  }

  @override
  String get liveFanClubEmotes => 'Club emotes';

  @override
  String liveFanClubEmoteLocked(String tier) {
    return 'Unlocks with $tier';
  }

  @override
  String get liveFanClubConfirmTitle => 'Confirm membership';

  @override
  String liveFanClubConfirmBody(int coins, String tier) {
    return '$coins coins will be taken from your wallet for $tier membership for 30 days.';
  }

  @override
  String get liveFanClubConfirmAction => 'Pay and continue';

  @override
  String get liveFanClubAwaitingConfirmation => 'An earlier membership payment is not confirmed yet. Check your membership before trying again.';

  @override
  String get liveFanClubHostSettings => 'Club settings';

  @override
  String get liveFanClubHostPrice => 'Basic membership price (coins)';

  @override
  String get liveFanClubHostName => 'Club name';

  @override
  String get liveFanClubHostEnabled => 'Enable fan club';

  @override
  String get liveFanClubAddEmote => 'Add emote';

  @override
  String get liveFanClubEmoteCode => 'Emote code';

  @override
  String get liveFanClubEmoteImage => 'Image URL';

  @override
  String get liveFanClubEmoteMinTier => 'Minimum tier';

  @override
  String get liveFanClubSave => 'Save';

  @override
  String get liveReplayRefresh => 'Refresh';

  @override
  String liveReplayViews(int count) {
    return 'Views: $count';
  }

  @override
  String liveReplayExpires(String date) {
    return 'Expires on $date';
  }

  @override
  String get liveReplayPreparing => 'The recording is still being prepared; the replay is not ready yet.';

  @override
  String get liveReplayGone => 'This replay is no longer available.';

  @override
  String get liveReplayPublish => 'Publish replay URL';

  @override
  String get liveReplayRemove => 'Delete replay';

  @override
  String get liveReplayUrl => 'Replay file URL';

  @override
  String get liveClipSelect => 'Choose the clip start and end';

  @override
  String liveClipRange(String start, String end, int seconds) {
    return 'From $start to $end ($seconds seconds)';
  }

  @override
  String get liveClipPreview => 'Preview selection';

  @override
  String get liveClipCreate => 'Create clip';

  @override
  String get liveClipPublish => 'Publish clip';

  @override
  String get liveClipTitle => 'Clip title';

  @override
  String get liveClipDescription => 'Post description';

  @override
  String get liveClipsTitle => 'Clips';

  @override
  String get liveClipsEmpty => 'No clips yet.';

  @override
  String get liveClipOpenPost => 'Open post';

  @override
  String get liveGamesTitle => 'Official games';

  @override
  String get liveGamesStart => 'Start a game';

  @override
  String get liveGamesActiveOne => 'A game is already running.';

  @override
  String get liveGamesNone => 'No game right now.';

  @override
  String get liveGameQuiz => 'Quiz';

  @override
  String get liveGameWheel => 'Prize wheel';

  @override
  String get liveGameLuckyDraw => 'Lucky draw';

  @override
  String get liveGameQuestion => 'Question';

  @override
  String liveGameOption(int index) {
    return 'Option $index';
  }

  @override
  String get liveGameCorrectOption => 'Correct answer';

  @override
  String liveGamePrize(int index) {
    return 'Prize $index';
  }

  @override
  String get liveGameAddOption => 'Add option';

  @override
  String get liveGameAddPrize => 'Add prize';

  @override
  String get liveGameEnd => 'End game';

  @override
  String get liveGamePlay => 'Play';

  @override
  String get liveGamePlayed => 'You already played';

  @override
  String get liveGameAnswerHidden => 'The answer appears after the host ends the game.';

  @override
  String get liveGameWaitingResult => 'Waiting for the server result…';

  @override
  String liveGameWinner(String name) {
    return 'Winner: $name';
  }

  @override
  String liveGameResultPrize(String prize) {
    return 'Prize: $prize';
  }

  @override
  String liveGamePlays(int count) {
    return 'Plays: $count';
  }

  @override
  String get liveGameUnsupported => 'This game type is not supported in this build.';

  @override
  String get shopLiveDealTitle => 'Live-only deal';

  @override
  String get shopLiveDealFlashPrice => 'Flash price (coins)';

  @override
  String get shopLiveDealFlashEnds => 'Ends in (minutes)';

  @override
  String get shopLiveDealCouponCode => 'Coupon code';

  @override
  String get shopLiveDealCouponOff => 'Coupon amount (coins)';

  @override
  String get shopLiveDealSave => 'Save deal';

  @override
  String get shopLiveDealClearFlash => 'Clear flash deal';

  @override
  String get shopLiveDealClearCoupon => 'Clear coupon';

  @override
  String get shopLiveDealNote => 'The server calculates the final price; checkout preview shows it.';

  @override
  String get shopLiveDealNeedsBoth => 'Enter the price and the end time together, and the code and amount together.';

  @override
  String get shopLiveDealSaved => 'Deal updated';
}
