import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en')
  ];

  /// No description provided for @appTitle.
  ///
  /// In en, this message translates to:
  /// **'Bimobond App'**
  String get appTitle;

  /// No description provided for @helloWorld.
  ///
  /// In en, this message translates to:
  /// **'Hello World!'**
  String get helloWorld;

  /// No description provided for @loginTitle.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get loginTitle;

  /// No description provided for @loginScreenTitle.
  ///
  /// In en, this message translates to:
  /// **'Log in to BimoBond'**
  String get loginScreenTitle;

  /// No description provided for @loginWithPhone.
  ///
  /// In en, this message translates to:
  /// **'Use phone number'**
  String get loginWithPhone;

  /// No description provided for @loginWithEmailUsername.
  ///
  /// In en, this message translates to:
  /// **'Use email or username'**
  String get loginWithEmailUsername;

  /// No description provided for @loginEmailUsernameHint.
  ///
  /// In en, this message translates to:
  /// **'Email or username'**
  String get loginEmailUsernameHint;

  /// No description provided for @continueWithGoogle.
  ///
  /// In en, this message translates to:
  /// **'Continue with Google'**
  String get continueWithGoogle;

  /// No description provided for @continueWithApple.
  ///
  /// In en, this message translates to:
  /// **'Continue with Apple'**
  String get continueWithApple;

  /// No description provided for @signInSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Sign in to continue'**
  String get signInSubtitle;

  /// No description provided for @emailLabel.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get emailLabel;

  /// No description provided for @passwordLabel.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get passwordLabel;

  /// No description provided for @loginButton.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get loginButton;

  /// No description provided for @dontHaveAccount.
  ///
  /// In en, this message translates to:
  /// **'Don\'t have an account? '**
  String get dontHaveAccount;

  /// No description provided for @signUp.
  ///
  /// In en, this message translates to:
  /// **'Sign Up'**
  String get signUp;

  /// No description provided for @orDivider.
  ///
  /// In en, this message translates to:
  /// **'OR'**
  String get orDivider;

  /// No description provided for @continueAsGuest.
  ///
  /// In en, this message translates to:
  /// **'Continue as Guest'**
  String get continueAsGuest;

  /// No description provided for @continueWith.
  ///
  /// In en, this message translates to:
  /// **'Continue with'**
  String get continueWith;

  /// No description provided for @notificationErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Error'**
  String get notificationErrorTitle;

  /// No description provided for @notificationSuccessTitle.
  ///
  /// In en, this message translates to:
  /// **'Success'**
  String get notificationSuccessTitle;

  /// No description provided for @signUpTitle.
  ///
  /// In en, this message translates to:
  /// **'Create Account'**
  String get signUpTitle;

  /// No description provided for @signUpScreenTitle.
  ///
  /// In en, this message translates to:
  /// **'Sign up to BimoBond'**
  String get signUpScreenTitle;

  /// No description provided for @signUpSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Enter your details to create a new account'**
  String get signUpSubtitle;

  /// No description provided for @fullNameLabel.
  ///
  /// In en, this message translates to:
  /// **'Full Name'**
  String get fullNameLabel;

  /// No description provided for @usernameLabel.
  ///
  /// In en, this message translates to:
  /// **'Username'**
  String get usernameLabel;

  /// No description provided for @countryLabel.
  ///
  /// In en, this message translates to:
  /// **'Country'**
  String get countryLabel;

  /// No description provided for @nationalityLabel.
  ///
  /// In en, this message translates to:
  /// **'Nationality'**
  String get nationalityLabel;

  /// No description provided for @ageLabel.
  ///
  /// In en, this message translates to:
  /// **'Age'**
  String get ageLabel;

  /// No description provided for @addressLabel.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get addressLabel;

  /// No description provided for @phoneLabel.
  ///
  /// In en, this message translates to:
  /// **'Phone'**
  String get phoneLabel;

  /// No description provided for @mobileNumberLabel.
  ///
  /// In en, this message translates to:
  /// **'Mobile Number'**
  String get mobileNumberLabel;

  /// No description provided for @confirmPasswordLabel.
  ///
  /// In en, this message translates to:
  /// **'Confirm Password'**
  String get confirmPasswordLabel;

  /// No description provided for @createAccountBtn.
  ///
  /// In en, this message translates to:
  /// **'Create Account'**
  String get createAccountBtn;

  /// No description provided for @alreadyHaveAccount.
  ///
  /// In en, this message translates to:
  /// **'Already have an account? '**
  String get alreadyHaveAccount;

  /// No description provided for @phoneLoginTitle.
  ///
  /// In en, this message translates to:
  /// **'Phone Login'**
  String get phoneLoginTitle;

  /// No description provided for @phoneLoginSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Enter your phone number to receive a verification code'**
  String get phoneLoginSubtitle;

  /// No description provided for @phoneLoginUsageNote.
  ///
  /// In en, this message translates to:
  /// **'Your phone number may be used to connect you to people you may know, improve ads, and more depending on your settings.'**
  String get phoneLoginUsageNote;

  /// No description provided for @emailLoginUsageNote.
  ///
  /// In en, this message translates to:
  /// **'Your email may be used to connect you to people you may know, improve ads, and more depending on your settings.'**
  String get emailLoginUsageNote;

  /// No description provided for @phoneHint.
  ///
  /// In en, this message translates to:
  /// **'+20 123 456 7890'**
  String get phoneHint;

  /// No description provided for @termsAndConditionsPart1.
  ///
  /// In en, this message translates to:
  /// **'By continuing, you agree to our '**
  String get termsAndConditionsPart1;

  /// No description provided for @termsAndConditionsPart2.
  ///
  /// In en, this message translates to:
  /// **'Terms & Conditions'**
  String get termsAndConditionsPart2;

  /// No description provided for @loginLegalNotePart1.
  ///
  /// In en, this message translates to:
  /// **'By continuing, you agree to our '**
  String get loginLegalNotePart1;

  /// No description provided for @loginTermsOfService.
  ///
  /// In en, this message translates to:
  /// **'Terms of Service'**
  String get loginTermsOfService;

  /// No description provided for @loginLegalNotePart2.
  ///
  /// In en, this message translates to:
  /// **' and confirm that you have read our '**
  String get loginLegalNotePart2;

  /// No description provided for @loginPrivacyPolicy.
  ///
  /// In en, this message translates to:
  /// **'Privacy Policy'**
  String get loginPrivacyPolicy;

  /// No description provided for @verifyPhoneTitle.
  ///
  /// In en, this message translates to:
  /// **'Verify Phone'**
  String get verifyPhoneTitle;

  /// No description provided for @emailVerificationTitle.
  ///
  /// In en, this message translates to:
  /// **'Verify Your Email'**
  String get emailVerificationTitle;

  /// Displayed after sending verification email
  ///
  /// In en, this message translates to:
  /// **'We sent a verification link to {email}.'**
  String emailVerificationSent(Object email);

  /// No description provided for @emailVerificationContinue.
  ///
  /// In en, this message translates to:
  /// **'Open your email and verify your account before continuing.'**
  String get emailVerificationContinue;

  /// No description provided for @emailVerificationButton.
  ///
  /// In en, this message translates to:
  /// **'I have verified my email'**
  String get emailVerificationButton;

  /// No description provided for @emailVerificationResendError.
  ///
  /// In en, this message translates to:
  /// **'Unable to resend verification email. Please sign in again.'**
  String get emailVerificationResendError;

  /// No description provided for @emailVerificationResendSuccess.
  ///
  /// In en, this message translates to:
  /// **'Verification email resent. Check your inbox and spam folder.'**
  String get emailVerificationResendSuccess;

  /// No description provided for @emailVerificationResendFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to resend verification email. Please try again.'**
  String get emailVerificationResendFailed;

  /// No description provided for @emailVerificationStatusError.
  ///
  /// In en, this message translates to:
  /// **'Unable to verify email status. Please sign in again.'**
  String get emailVerificationStatusError;

  /// No description provided for @emailVerificationNotVerified.
  ///
  /// In en, this message translates to:
  /// **'Email not verified yet. Please open your email and verify your account.'**
  String get emailVerificationNotVerified;

  /// No description provided for @emailVerificationCheckFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not check verification status. Please try again.'**
  String get emailVerificationCheckFailed;

  /// No description provided for @emailVerificationResendButton.
  ///
  /// In en, this message translates to:
  /// **'Resend verification email'**
  String get emailVerificationResendButton;

  /// No description provided for @emailVerificationResending.
  ///
  /// In en, this message translates to:
  /// **'Resending...'**
  String get emailVerificationResending;

  /// No description provided for @enterCodeSentTo.
  ///
  /// In en, this message translates to:
  /// **'Enter the 6-digit code sent to'**
  String get enterCodeSentTo;

  /// No description provided for @verificationCodeLabel.
  ///
  /// In en, this message translates to:
  /// **'Verification Code'**
  String get verificationCodeLabel;

  /// No description provided for @verifyAndLoginBtn.
  ///
  /// In en, this message translates to:
  /// **'Verify & Login'**
  String get verifyAndLoginBtn;

  /// No description provided for @didNotReceiveCode.
  ///
  /// In en, this message translates to:
  /// **'Didn\'t receive a code? '**
  String get didNotReceiveCode;

  /// No description provided for @resendCode.
  ///
  /// In en, this message translates to:
  /// **'Resend'**
  String get resendCode;

  /// No description provided for @resendCodeIn.
  ///
  /// In en, this message translates to:
  /// **'Resend in {seconds}s'**
  String resendCodeIn(int seconds);

  /// No description provided for @back.
  ///
  /// In en, this message translates to:
  /// **'Back'**
  String get back;

  /// No description provided for @continueAction.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get continueAction;

  /// No description provided for @emailRequired.
  ///
  /// In en, this message translates to:
  /// **'Email is required'**
  String get emailRequired;

  /// No description provided for @invalidEmail.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid email'**
  String get invalidEmail;

  /// No description provided for @passwordRequired.
  ///
  /// In en, this message translates to:
  /// **'Password is required'**
  String get passwordRequired;

  /// No description provided for @passwordTooShort.
  ///
  /// In en, this message translates to:
  /// **'Password must be at least 6 characters'**
  String get passwordTooShort;

  /// No description provided for @passwordSignUpTooShort.
  ///
  /// In en, this message translates to:
  /// **'Password must be at least 8 characters'**
  String get passwordSignUpTooShort;

  /// No description provided for @passwordTooLong.
  ///
  /// In en, this message translates to:
  /// **'Password must be at most 20 characters'**
  String get passwordTooLong;

  /// No description provided for @passwordsDoNotMatch.
  ///
  /// In en, this message translates to:
  /// **'Passwords do not match'**
  String get passwordsDoNotMatch;

  /// No description provided for @forgotPassword.
  ///
  /// In en, this message translates to:
  /// **'Forgot Password?'**
  String get forgotPassword;

  /// No description provided for @forgotPasswordTitle.
  ///
  /// In en, this message translates to:
  /// **'Forgot Password'**
  String get forgotPasswordTitle;

  /// No description provided for @forgotPasswordSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Enter your email and we\'ll send a 6-digit code to reset your password.'**
  String get forgotPasswordSubtitle;

  /// No description provided for @forgotPasswordButton.
  ///
  /// In en, this message translates to:
  /// **'Send Reset Code'**
  String get forgotPasswordButton;

  /// No description provided for @forgotPasswordSuccess.
  ///
  /// In en, this message translates to:
  /// **'If an account exists for that email, a reset code was sent.'**
  String get forgotPasswordSuccess;

  /// No description provided for @forgotPasswordFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to send reset code. Please try again.'**
  String get forgotPasswordFailed;

  /// No description provided for @forgotPasswordUserNotFound.
  ///
  /// In en, this message translates to:
  /// **'No account found with this email address.'**
  String get forgotPasswordUserNotFound;

  /// No description provided for @resetPasswordTitle.
  ///
  /// In en, this message translates to:
  /// **'Reset Password'**
  String get resetPasswordTitle;

  /// No description provided for @resetPasswordSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Enter the 6-digit code sent to'**
  String get resetPasswordSubtitle;

  /// No description provided for @resetPasswordButton.
  ///
  /// In en, this message translates to:
  /// **'Reset Password'**
  String get resetPasswordButton;

  /// No description provided for @resetPasswordSuccess.
  ///
  /// In en, this message translates to:
  /// **'Password reset successfully. Please sign in.'**
  String get resetPasswordSuccess;

  /// No description provided for @newPasswordLabel.
  ///
  /// In en, this message translates to:
  /// **'New Password'**
  String get newPasswordLabel;

  /// No description provided for @otpSentSuccess.
  ///
  /// In en, this message translates to:
  /// **'Verification code sent.'**
  String get otpSentSuccess;

  /// No description provided for @otpVerifiedSuccess.
  ///
  /// In en, this message translates to:
  /// **'Email verified successfully.'**
  String get otpVerifiedSuccess;

  /// No description provided for @loginFailed.
  ///
  /// In en, this message translates to:
  /// **'Login failed. Please try again.'**
  String get loginFailed;

  /// No description provided for @verificationFailed.
  ///
  /// In en, this message translates to:
  /// **'Verification failed'**
  String get verificationFailed;

  /// No description provided for @invalidOtpCode.
  ///
  /// In en, this message translates to:
  /// **'Invalid OTP code'**
  String get invalidOtpCode;

  /// No description provided for @googleLoginFailed.
  ///
  /// In en, this message translates to:
  /// **'Google login failed'**
  String get googleLoginFailed;

  /// No description provided for @googleLoginSheetTitle.
  ///
  /// In en, this message translates to:
  /// **'Sign in with Google'**
  String get googleLoginSheetTitle;

  /// No description provided for @googleLoginSheetSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Use your Google account to sign in quickly and securely.'**
  String get googleLoginSheetSubtitle;

  /// No description provided for @googleLoginContinue.
  ///
  /// In en, this message translates to:
  /// **'Continue with Google'**
  String get googleLoginContinue;

  /// No description provided for @updateProfileFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to update profile'**
  String get updateProfileFailed;

  /// No description provided for @signupFailed.
  ///
  /// In en, this message translates to:
  /// **'Signup failed. Please try again.'**
  String get signupFailed;

  /// No description provided for @profileUpdatedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Profile updated successfully!'**
  String get profileUpdatedSuccessfully;

  /// No description provided for @enterSixDigitCode.
  ///
  /// In en, this message translates to:
  /// **'Please enter a 6-digit code'**
  String get enterSixDigitCode;

  /// No description provided for @postAdded.
  ///
  /// In en, this message translates to:
  /// **'Post added!'**
  String get postAdded;

  /// No description provided for @addPost.
  ///
  /// In en, this message translates to:
  /// **'Add Post'**
  String get addPost;

  /// No description provided for @postButton.
  ///
  /// In en, this message translates to:
  /// **'Post'**
  String get postButton;

  /// No description provided for @loginSuccess.
  ///
  /// In en, this message translates to:
  /// **'Login successful!'**
  String get loginSuccess;

  /// No description provided for @signupSuccess.
  ///
  /// In en, this message translates to:
  /// **'Signup successful! Please check your email to verify your account.'**
  String get signupSuccess;

  /// No description provided for @signUpWithEmailPassword.
  ///
  /// In en, this message translates to:
  /// **'Sign up with Email and Password'**
  String get signUpWithEmailPassword;

  /// No description provided for @signUpEmailStepTitle.
  ///
  /// In en, this message translates to:
  /// **'What\'s your email?'**
  String get signUpEmailStepTitle;

  /// No description provided for @signUpNameStepTitle.
  ///
  /// In en, this message translates to:
  /// **'What\'s your name?'**
  String get signUpNameStepTitle;

  /// No description provided for @signUpPasswordStepTitle.
  ///
  /// In en, this message translates to:
  /// **'Create a password'**
  String get signUpPasswordStepTitle;

  /// No description provided for @nextAction.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get nextAction;

  /// No description provided for @passwordStrengthLabel.
  ///
  /// In en, this message translates to:
  /// **'Password strength'**
  String get passwordStrengthLabel;

  /// No description provided for @passwordStrengthWeak.
  ///
  /// In en, this message translates to:
  /// **'Weak'**
  String get passwordStrengthWeak;

  /// No description provided for @passwordStrengthFair.
  ///
  /// In en, this message translates to:
  /// **'Fair'**
  String get passwordStrengthFair;

  /// No description provided for @passwordStrengthGood.
  ///
  /// In en, this message translates to:
  /// **'Good'**
  String get passwordStrengthGood;

  /// No description provided for @passwordStrengthStrong.
  ///
  /// In en, this message translates to:
  /// **'Strong'**
  String get passwordStrengthStrong;

  /// No description provided for @passwordStrengthHint.
  ///
  /// In en, this message translates to:
  /// **'Your password must have 8 to 20 characters and include a mix of letters, numbers, and symbols.'**
  String get passwordStrengthHint;

  /// No description provided for @passwordReqLength.
  ///
  /// In en, this message translates to:
  /// **'8 to 20 characters'**
  String get passwordReqLength;

  /// No description provided for @passwordReqLetter.
  ///
  /// In en, this message translates to:
  /// **'1 letter'**
  String get passwordReqLetter;

  /// No description provided for @passwordReqNumber.
  ///
  /// In en, this message translates to:
  /// **'1 number'**
  String get passwordReqNumber;

  /// No description provided for @passwordReqSpecialChar.
  ///
  /// In en, this message translates to:
  /// **'1 special character (e.g. ! @ # \$ % & *)'**
  String get passwordReqSpecialChar;

  /// No description provided for @passwordRequirementsNotMet.
  ///
  /// In en, this message translates to:
  /// **'Password must meet all requirements'**
  String get passwordRequirementsNotMet;

  /// No description provided for @following.
  ///
  /// In en, this message translates to:
  /// **'Following'**
  String get following;

  /// No description provided for @followers.
  ///
  /// In en, this message translates to:
  /// **'Followers'**
  String get followers;

  /// No description provided for @connectionsTitle.
  ///
  /// In en, this message translates to:
  /// **'Connections'**
  String get connectionsTitle;

  /// No description provided for @connectionsEmptyFollowers.
  ///
  /// In en, this message translates to:
  /// **'No followers yet'**
  String get connectionsEmptyFollowers;

  /// No description provided for @connectionsEmptyFollowing.
  ///
  /// In en, this message translates to:
  /// **'Not following anyone yet'**
  String get connectionsEmptyFollowing;

  /// No description provided for @connectionsEmptyFriends.
  ///
  /// In en, this message translates to:
  /// **'No friends yet'**
  String get connectionsEmptyFriends;

  /// No description provided for @connectionsFollowBack.
  ///
  /// In en, this message translates to:
  /// **'Follow back'**
  String get connectionsFollowBack;

  /// No description provided for @profileMessageButton.
  ///
  /// In en, this message translates to:
  /// **'Message'**
  String get profileMessageButton;

  /// No description provided for @likes.
  ///
  /// In en, this message translates to:
  /// **'Likes'**
  String get likes;

  /// No description provided for @profilePostsTab.
  ///
  /// In en, this message translates to:
  /// **'Posts'**
  String get profilePostsTab;

  /// No description provided for @profilePostAuction.
  ///
  /// In en, this message translates to:
  /// **'Auction'**
  String get profilePostAuction;

  /// No description provided for @profileLikesTab.
  ///
  /// In en, this message translates to:
  /// **'Likes'**
  String get profileLikesTab;

  /// No description provided for @noPostsYet.
  ///
  /// In en, this message translates to:
  /// **'No posts yet'**
  String get noPostsYet;

  /// No description provided for @noLikedPosts.
  ///
  /// In en, this message translates to:
  /// **'No liked posts'**
  String get noLikedPosts;

  /// No description provided for @noSavedPosts.
  ///
  /// In en, this message translates to:
  /// **'No saved posts'**
  String get noSavedPosts;

  /// No description provided for @noRepostedPosts.
  ///
  /// In en, this message translates to:
  /// **'No reposts yet'**
  String get noRepostedPosts;

  /// No description provided for @noOnlyMePosts.
  ///
  /// In en, this message translates to:
  /// **'No only me posts yet'**
  String get noOnlyMePosts;

  /// No description provided for @repostTitle.
  ///
  /// In en, this message translates to:
  /// **'Repost'**
  String get repostTitle;

  /// No description provided for @repostSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Share this post to your profile'**
  String get repostSubtitle;

  /// No description provided for @repostAction.
  ///
  /// In en, this message translates to:
  /// **'Repost'**
  String get repostAction;

  /// No description provided for @repostUndo.
  ///
  /// In en, this message translates to:
  /// **'Undo repost'**
  String get repostUndo;

  /// No description provided for @savePost.
  ///
  /// In en, this message translates to:
  /// **'Save post'**
  String get savePost;

  /// No description provided for @unsavePost.
  ///
  /// In en, this message translates to:
  /// **'Remove from saved'**
  String get unsavePost;

  /// No description provided for @repostQuoteHint.
  ///
  /// In en, this message translates to:
  /// **'Add a comment (optional)'**
  String get repostQuoteHint;

  /// No description provided for @repostComposeTitle.
  ///
  /// In en, this message translates to:
  /// **'Add to your repost'**
  String get repostComposeTitle;

  /// No description provided for @repostComposeHint.
  ///
  /// In en, this message translates to:
  /// **'Say something...'**
  String get repostComposeHint;

  /// No description provided for @repostComposeAdd.
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get repostComposeAdd;

  /// No description provided for @postRepostersHeader.
  ///
  /// In en, this message translates to:
  /// **'Reposts'**
  String get postRepostersHeader;

  /// No description provided for @repostSuccess.
  ///
  /// In en, this message translates to:
  /// **'Reposted'**
  String get repostSuccess;

  /// No description provided for @repostRemoved.
  ///
  /// In en, this message translates to:
  /// **'Repost removed'**
  String get repostRemoved;

  /// No description provided for @cannotRepostOwnPost.
  ///
  /// In en, this message translates to:
  /// **'You can\'t repost your own post'**
  String get cannotRepostOwnPost;

  /// No description provided for @repostCountLabel.
  ///
  /// In en, this message translates to:
  /// **'{count} reposts'**
  String repostCountLabel(int count);

  /// No description provided for @repostedByUser.
  ///
  /// In en, this message translates to:
  /// **'{name} reposted'**
  String repostedByUser(Object name);

  /// No description provided for @postRepostersTitle.
  ///
  /// In en, this message translates to:
  /// **'Reposts · {count}'**
  String postRepostersTitle(int count);

  /// No description provided for @postRepostersEmpty.
  ///
  /// In en, this message translates to:
  /// **'No reposts yet'**
  String get postRepostersEmpty;

  /// No description provided for @profileRepostsTab.
  ///
  /// In en, this message translates to:
  /// **'Reposts'**
  String get profileRepostsTab;

  /// No description provided for @editProfile.
  ///
  /// In en, this message translates to:
  /// **'Edit profile'**
  String get editProfile;

  /// No description provided for @noBio.
  ///
  /// In en, this message translates to:
  /// **'No bio yet.'**
  String get noBio;

  /// No description provided for @profileAvatarViewPhoto.
  ///
  /// In en, this message translates to:
  /// **'Open profile photo'**
  String get profileAvatarViewPhoto;

  /// No description provided for @profileAvatarViewStory.
  ///
  /// In en, this message translates to:
  /// **'View story'**
  String get profileAvatarViewStory;

  /// No description provided for @profileAvatarNoPhoto.
  ///
  /// In en, this message translates to:
  /// **'No profile photo'**
  String get profileAvatarNoPhoto;

  /// No description provided for @story.
  ///
  /// In en, this message translates to:
  /// **'Story'**
  String get story;

  /// No description provided for @addStoryTitle.
  ///
  /// In en, this message translates to:
  /// **'Add story'**
  String get addStoryTitle;

  /// No description provided for @shareStoryButton.
  ///
  /// In en, this message translates to:
  /// **'Share story'**
  String get shareStoryButton;

  /// No description provided for @storyAddText.
  ///
  /// In en, this message translates to:
  /// **'Text'**
  String get storyAddText;

  /// No description provided for @storyTextDone.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get storyTextDone;

  /// No description provided for @storyCaptionHint.
  ///
  /// In en, this message translates to:
  /// **'Add a caption (optional)'**
  String get storyCaptionHint;

  /// No description provided for @storyLoadMore.
  ///
  /// In en, this message translates to:
  /// **'Load more'**
  String get storyLoadMore;

  /// No description provided for @storyShowLess.
  ///
  /// In en, this message translates to:
  /// **'Show less'**
  String get storyShowLess;

  /// No description provided for @storyPickMediaError.
  ///
  /// In en, this message translates to:
  /// **'Could not pick media: {error}'**
  String storyPickMediaError(String error);

  /// No description provided for @storyExpired.
  ///
  /// In en, this message translates to:
  /// **'Story expired'**
  String get storyExpired;

  /// No description provided for @storyTimeMinutesAgo.
  ///
  /// In en, this message translates to:
  /// **'{count}m ago'**
  String storyTimeMinutesAgo(int count);

  /// No description provided for @storyTimeHoursAgo.
  ///
  /// In en, this message translates to:
  /// **'{count}h ago'**
  String storyTimeHoursAgo(int count);

  /// No description provided for @storyTimeDaysAgo.
  ///
  /// In en, this message translates to:
  /// **'{count}d ago'**
  String storyTimeDaysAgo(int count);

  /// No description provided for @storyAddCommentHint.
  ///
  /// In en, this message translates to:
  /// **'Add comment...'**
  String get storyAddCommentHint;

  /// No description provided for @storySendMessageHint.
  ///
  /// In en, this message translates to:
  /// **'Write a message...'**
  String get storySendMessageHint;

  /// No description provided for @storySendMessageTitle.
  ///
  /// In en, this message translates to:
  /// **'Reply with a message'**
  String get storySendMessageTitle;

  /// No description provided for @storyViewersTitle.
  ///
  /// In en, this message translates to:
  /// **'Viewers'**
  String get storyViewersTitle;

  /// No description provided for @storyViewerUnknown.
  ///
  /// In en, this message translates to:
  /// **'Viewer'**
  String get storyViewerUnknown;

  /// No description provided for @storyMessagesTitle.
  ///
  /// In en, this message translates to:
  /// **'Messages on this story'**
  String get storyMessagesTitle;

  /// No description provided for @storyMessagesEmpty.
  ///
  /// In en, this message translates to:
  /// **'No messages on this story yet'**
  String get storyMessagesEmpty;

  /// No description provided for @storyMessageSendFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not send message. Try again.'**
  String get storyMessageSendFailed;

  /// No description provided for @storyMessageSent.
  ///
  /// In en, this message translates to:
  /// **'Message sent to {name}'**
  String storyMessageSent(String name);

  /// No description provided for @storyPreviewLabel.
  ///
  /// In en, this message translates to:
  /// **'Story'**
  String get storyPreviewLabel;

  /// No description provided for @postPreviewLabel.
  ///
  /// In en, this message translates to:
  /// **'Post'**
  String get postPreviewLabel;

  /// No description provided for @storyMessageOnStory.
  ///
  /// In en, this message translates to:
  /// **'Replied to your story'**
  String get storyMessageOnStory;

  /// No description provided for @storyMessageOnPost.
  ///
  /// In en, this message translates to:
  /// **'Replied to your post'**
  String get storyMessageOnPost;

  /// No description provided for @personalInfo.
  ///
  /// In en, this message translates to:
  /// **'Personal Info'**
  String get personalInfo;

  /// No description provided for @genderLabel.
  ///
  /// In en, this message translates to:
  /// **'Gender'**
  String get genderLabel;

  /// No description provided for @male.
  ///
  /// In en, this message translates to:
  /// **'Male'**
  String get male;

  /// No description provided for @female.
  ///
  /// In en, this message translates to:
  /// **'Female'**
  String get female;

  /// No description provided for @selectCountry.
  ///
  /// In en, this message translates to:
  /// **'Select Country'**
  String get selectCountry;

  /// No description provided for @changeProfilePhoto.
  ///
  /// In en, this message translates to:
  /// **'Change profile photo'**
  String get changeProfilePhoto;

  /// No description provided for @takePhoto.
  ///
  /// In en, this message translates to:
  /// **'Take Photo'**
  String get takePhoto;

  /// No description provided for @importFromLibrary.
  ///
  /// In en, this message translates to:
  /// **'Import'**
  String get importFromLibrary;

  /// No description provided for @uploadFromLibrary.
  ///
  /// In en, this message translates to:
  /// **'Upload from library'**
  String get uploadFromLibrary;

  /// No description provided for @removeCurrentPhoto.
  ///
  /// In en, this message translates to:
  /// **'Remove current photo'**
  String get removeCurrentPhoto;

  /// No description provided for @changePhoto.
  ///
  /// In en, this message translates to:
  /// **'Change photo'**
  String get changePhoto;

  /// No description provided for @enterYourName.
  ///
  /// In en, this message translates to:
  /// **'Enter your name'**
  String get enterYourName;

  /// No description provided for @enterUsername.
  ///
  /// In en, this message translates to:
  /// **'Enter username'**
  String get enterUsername;

  /// No description provided for @addBioToProfile.
  ///
  /// In en, this message translates to:
  /// **'Add a bio to your profile'**
  String get addBioToProfile;

  /// No description provided for @selectGender.
  ///
  /// In en, this message translates to:
  /// **'Select gender'**
  String get selectGender;

  /// No description provided for @instagramProfileUrl.
  ///
  /// In en, this message translates to:
  /// **'Username or profile link'**
  String get instagramProfileUrl;

  /// No description provided for @youtubeChannelUrl.
  ///
  /// In en, this message translates to:
  /// **'Username or channel link'**
  String get youtubeChannelUrl;

  /// No description provided for @egypt.
  ///
  /// In en, this message translates to:
  /// **'Egypt'**
  String get egypt;

  /// No description provided for @saudiArabia.
  ///
  /// In en, this message translates to:
  /// **'Saudi Arabia'**
  String get saudiArabia;

  /// No description provided for @uae.
  ///
  /// In en, this message translates to:
  /// **'UAE'**
  String get uae;

  /// No description provided for @usa.
  ///
  /// In en, this message translates to:
  /// **'USA'**
  String get usa;

  /// No description provided for @uk.
  ///
  /// In en, this message translates to:
  /// **'UK'**
  String get uk;

  /// No description provided for @kuwait.
  ///
  /// In en, this message translates to:
  /// **'Kuwait'**
  String get kuwait;

  /// No description provided for @qatar.
  ///
  /// In en, this message translates to:
  /// **'Qatar'**
  String get qatar;

  /// No description provided for @bioLabel.
  ///
  /// In en, this message translates to:
  /// **'Bio'**
  String get bioLabel;

  /// No description provided for @instagramLabel.
  ///
  /// In en, this message translates to:
  /// **'Instagram'**
  String get instagramLabel;

  /// No description provided for @youtubeLabel.
  ///
  /// In en, this message translates to:
  /// **'YouTube'**
  String get youtubeLabel;

  /// No description provided for @fieldIsRequired.
  ///
  /// In en, this message translates to:
  /// **'{field} is required'**
  String fieldIsRequired(String field);

  /// No description provided for @edit.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get edit;

  /// No description provided for @feedFollowingTab.
  ///
  /// In en, this message translates to:
  /// **'Following'**
  String get feedFollowingTab;

  /// No description provided for @feedForYou.
  ///
  /// In en, this message translates to:
  /// **'For You'**
  String get feedForYou;

  /// No description provided for @feedLive.
  ///
  /// In en, this message translates to:
  /// **'Live'**
  String get feedLive;

  /// No description provided for @feedShop.
  ///
  /// In en, this message translates to:
  /// **'Shop'**
  String get feedShop;

  /// No description provided for @shopTitle.
  ///
  /// In en, this message translates to:
  /// **'Shop'**
  String get shopTitle;

  /// No description provided for @shopFeatured.
  ///
  /// In en, this message translates to:
  /// **'Featured'**
  String get shopFeatured;

  /// No description provided for @shopFlashDeals.
  ///
  /// In en, this message translates to:
  /// **'Flash Deals'**
  String get shopFlashDeals;

  /// No description provided for @shopForYou.
  ///
  /// In en, this message translates to:
  /// **'For You'**
  String get shopForYou;

  /// No description provided for @shopCart.
  ///
  /// In en, this message translates to:
  /// **'Cart'**
  String get shopCart;

  /// No description provided for @shopCheckout.
  ///
  /// In en, this message translates to:
  /// **'Checkout'**
  String get shopCheckout;

  /// No description provided for @shopOrders.
  ///
  /// In en, this message translates to:
  /// **'Orders'**
  String get shopOrders;

  /// No description provided for @shopBuyNow.
  ///
  /// In en, this message translates to:
  /// **'Buy Now'**
  String get shopBuyNow;

  /// No description provided for @shopAddToCart.
  ///
  /// In en, this message translates to:
  /// **'Add to Cart'**
  String get shopAddToCart;

  /// No description provided for @shopEmpty.
  ///
  /// In en, this message translates to:
  /// **'No products found'**
  String get shopEmpty;

  /// No description provided for @shopRetry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get shopRetry;

  /// No description provided for @shopAllCategories.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get shopAllCategories;

  /// No description provided for @shopProducts.
  ///
  /// In en, this message translates to:
  /// **'Products'**
  String get shopProducts;

  /// No description provided for @shopNoProductsYet.
  ///
  /// In en, this message translates to:
  /// **'No products yet'**
  String get shopNoProductsYet;

  /// No description provided for @shopEmptyHint.
  ///
  /// In en, this message translates to:
  /// **'Try a different category or search term.'**
  String get shopEmptyHint;

  /// No description provided for @shopSeeAll.
  ///
  /// In en, this message translates to:
  /// **'See all'**
  String get shopSeeAll;

  /// No description provided for @shopSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search products...'**
  String get shopSearchHint;

  /// No description provided for @shopSearchForProducts.
  ///
  /// In en, this message translates to:
  /// **'Search for products'**
  String get shopSearchForProducts;

  /// No description provided for @shopRecentSearches.
  ///
  /// In en, this message translates to:
  /// **'Recent'**
  String get shopRecentSearches;

  /// No description provided for @shopNoResultsFor.
  ///
  /// In en, this message translates to:
  /// **'No results for \"{query}\"'**
  String shopNoResultsFor(String query);

  /// No description provided for @shopSort.
  ///
  /// In en, this message translates to:
  /// **'Sort'**
  String get shopSort;

  /// No description provided for @shopSortNewest.
  ///
  /// In en, this message translates to:
  /// **'Newest'**
  String get shopSortNewest;

  /// No description provided for @shopSortOldest.
  ///
  /// In en, this message translates to:
  /// **'Oldest'**
  String get shopSortOldest;

  /// No description provided for @shopSortPriceLow.
  ///
  /// In en, this message translates to:
  /// **'Price: Low'**
  String get shopSortPriceLow;

  /// No description provided for @shopSortPriceHigh.
  ///
  /// In en, this message translates to:
  /// **'Price: High'**
  String get shopSortPriceHigh;

  /// No description provided for @shopSortTitleAsc.
  ///
  /// In en, this message translates to:
  /// **'Title A-Z'**
  String get shopSortTitleAsc;

  /// No description provided for @shopSortTitleDesc.
  ///
  /// In en, this message translates to:
  /// **'Title Z-A'**
  String get shopSortTitleDesc;

  /// No description provided for @shopCartEmpty.
  ///
  /// In en, this message translates to:
  /// **'Your cart is empty'**
  String get shopCartEmpty;

  /// No description provided for @shopSubtotal.
  ///
  /// In en, this message translates to:
  /// **'Subtotal'**
  String get shopSubtotal;

  /// No description provided for @shopCommission.
  ///
  /// In en, this message translates to:
  /// **'Commission'**
  String get shopCommission;

  /// No description provided for @shopCheckoutAction.
  ///
  /// In en, this message translates to:
  /// **'Checkout'**
  String get shopCheckoutAction;

  /// No description provided for @shopShippingDetails.
  ///
  /// In en, this message translates to:
  /// **'Shipping Details'**
  String get shopShippingDetails;

  /// No description provided for @shopPayWithCoins.
  ///
  /// In en, this message translates to:
  /// **'Pay with coins'**
  String get shopPayWithCoins;

  /// No description provided for @shopFirstName.
  ///
  /// In en, this message translates to:
  /// **'First name'**
  String get shopFirstName;

  /// No description provided for @shopFirstNameHint.
  ///
  /// In en, this message translates to:
  /// **'Enter your first name'**
  String get shopFirstNameHint;

  /// No description provided for @shopLastName.
  ///
  /// In en, this message translates to:
  /// **'Last name'**
  String get shopLastName;

  /// No description provided for @shopLastNameHint.
  ///
  /// In en, this message translates to:
  /// **'Enter your last name'**
  String get shopLastNameHint;

  /// No description provided for @shopStreet.
  ///
  /// In en, this message translates to:
  /// **'Street'**
  String get shopStreet;

  /// No description provided for @shopStreetHint.
  ///
  /// In en, this message translates to:
  /// **'Enter your street'**
  String get shopStreetHint;

  /// No description provided for @shopStreetNo.
  ///
  /// In en, this message translates to:
  /// **'Street no.'**
  String get shopStreetNo;

  /// No description provided for @shopStreetNoHint.
  ///
  /// In en, this message translates to:
  /// **'No.'**
  String get shopStreetNoHint;

  /// No description provided for @shopApartmentNo.
  ///
  /// In en, this message translates to:
  /// **'Apartment no.'**
  String get shopApartmentNo;

  /// No description provided for @shopApartmentNoHint.
  ///
  /// In en, this message translates to:
  /// **'Apt.'**
  String get shopApartmentNoHint;

  /// No description provided for @shopCity.
  ///
  /// In en, this message translates to:
  /// **'City'**
  String get shopCity;

  /// No description provided for @shopCityHint.
  ///
  /// In en, this message translates to:
  /// **'Enter your city'**
  String get shopCityHint;

  /// No description provided for @shopPostcode.
  ///
  /// In en, this message translates to:
  /// **'Postcode'**
  String get shopPostcode;

  /// No description provided for @shopPostcodeHint.
  ///
  /// In en, this message translates to:
  /// **'Enter your postcode'**
  String get shopPostcodeHint;

  /// No description provided for @shopCountry.
  ///
  /// In en, this message translates to:
  /// **'Country'**
  String get shopCountry;

  /// No description provided for @shopCountryHint.
  ///
  /// In en, this message translates to:
  /// **'Enter your country'**
  String get shopCountryHint;

  /// No description provided for @shopPhone.
  ///
  /// In en, this message translates to:
  /// **'Phone'**
  String get shopPhone;

  /// No description provided for @shopPhoneHint.
  ///
  /// In en, this message translates to:
  /// **'Enter your phone'**
  String get shopPhoneHint;

  /// No description provided for @shopFieldRequired.
  ///
  /// In en, this message translates to:
  /// **'Required'**
  String get shopFieldRequired;

  /// No description provided for @shopYourBalance.
  ///
  /// In en, this message translates to:
  /// **'Your balance'**
  String get shopYourBalance;

  /// No description provided for @shopDueNow.
  ///
  /// In en, this message translates to:
  /// **'Due now'**
  String get shopDueNow;

  /// No description provided for @shopBuyCoins.
  ///
  /// In en, this message translates to:
  /// **'Buy coins'**
  String get shopBuyCoins;

  /// No description provided for @shopPayCoinsAmount.
  ///
  /// In en, this message translates to:
  /// **'Pay {count} coins'**
  String shopPayCoinsAmount(int count);

  /// No description provided for @shopNeedMoreCoins.
  ///
  /// In en, this message translates to:
  /// **'You need {count} more coins.'**
  String shopNeedMoreCoins(int count);

  /// No description provided for @shopNotEnoughCoins.
  ///
  /// In en, this message translates to:
  /// **'Not enough coins. Buy more to continue.'**
  String get shopNotEnoughCoins;

  /// No description provided for @shopCoinsLabel.
  ///
  /// In en, this message translates to:
  /// **'{count} coins'**
  String shopCoinsLabel(int count);

  /// No description provided for @shopProductNotFound.
  ///
  /// In en, this message translates to:
  /// **'Product not found'**
  String get shopProductNotFound;

  /// No description provided for @shopAddFavorite.
  ///
  /// In en, this message translates to:
  /// **'Add favorite'**
  String get shopAddFavorite;

  /// No description provided for @shopRemoveFavorite.
  ///
  /// In en, this message translates to:
  /// **'Remove favorite'**
  String get shopRemoveFavorite;

  /// No description provided for @shopShare.
  ///
  /// In en, this message translates to:
  /// **'Share'**
  String get shopShare;

  /// No description provided for @shopReadMore.
  ///
  /// In en, this message translates to:
  /// **'Read more'**
  String get shopReadMore;

  /// No description provided for @shopShowLess.
  ///
  /// In en, this message translates to:
  /// **'Show less'**
  String get shopShowLess;

  /// No description provided for @shopVariants.
  ///
  /// In en, this message translates to:
  /// **'Variants'**
  String get shopVariants;

  /// No description provided for @shopQuantity.
  ///
  /// In en, this message translates to:
  /// **'Quantity'**
  String get shopQuantity;

  /// No description provided for @shopOutOfStock.
  ///
  /// In en, this message translates to:
  /// **'Out of stock'**
  String get shopOutOfStock;

  /// No description provided for @shopSelectVariantFirst.
  ///
  /// In en, this message translates to:
  /// **'Select a variant first'**
  String get shopSelectVariantFirst;

  /// No description provided for @shopAddedToCart.
  ///
  /// In en, this message translates to:
  /// **'Added to cart'**
  String get shopAddedToCart;

  /// No description provided for @shopLiveBadge.
  ///
  /// In en, this message translates to:
  /// **'LIVE'**
  String get shopLiveBadge;

  /// No description provided for @shopBestPrice.
  ///
  /// In en, this message translates to:
  /// **'Best price'**
  String get shopBestPrice;

  /// No description provided for @shopPurchases.
  ///
  /// In en, this message translates to:
  /// **'Purchases'**
  String get shopPurchases;

  /// No description provided for @shopSales.
  ///
  /// In en, this message translates to:
  /// **'Sales'**
  String get shopSales;

  /// No description provided for @shopNoPurchasesYet.
  ///
  /// In en, this message translates to:
  /// **'No purchases yet'**
  String get shopNoPurchasesYet;

  /// No description provided for @shopNoSalesYet.
  ///
  /// In en, this message translates to:
  /// **'No sales yet'**
  String get shopNoSalesYet;

  /// No description provided for @shopStatusPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get shopStatusPending;

  /// No description provided for @shopStatusPaid.
  ///
  /// In en, this message translates to:
  /// **'Paid'**
  String get shopStatusPaid;

  /// No description provided for @shopStatusCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get shopStatusCancelled;

  /// No description provided for @shopStatusRefunded.
  ///
  /// In en, this message translates to:
  /// **'Refunded'**
  String get shopStatusRefunded;

  /// No description provided for @shopStatusUnknown.
  ///
  /// In en, this message translates to:
  /// **'Unknown'**
  String get shopStatusUnknown;

  /// No description provided for @shopFulfillmentNone.
  ///
  /// In en, this message translates to:
  /// **'Not started'**
  String get shopFulfillmentNone;

  /// No description provided for @shopFulfillmentAwaitingShipment.
  ///
  /// In en, this message translates to:
  /// **'Awaiting shipment'**
  String get shopFulfillmentAwaitingShipment;

  /// No description provided for @shopFulfillmentShipped.
  ///
  /// In en, this message translates to:
  /// **'Shipped'**
  String get shopFulfillmentShipped;

  /// No description provided for @shopFulfillmentDelivered.
  ///
  /// In en, this message translates to:
  /// **'Delivered'**
  String get shopFulfillmentDelivered;

  /// No description provided for @shopFulfillmentAccepted.
  ///
  /// In en, this message translates to:
  /// **'Accepted'**
  String get shopFulfillmentAccepted;

  /// No description provided for @shopFulfillmentDisputed.
  ///
  /// In en, this message translates to:
  /// **'Disputed'**
  String get shopFulfillmentDisputed;

  /// No description provided for @shopStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get shopStatus;

  /// No description provided for @shopFulfillment.
  ///
  /// In en, this message translates to:
  /// **'Fulfillment'**
  String get shopFulfillment;

  /// No description provided for @shopTracking.
  ///
  /// In en, this message translates to:
  /// **'Tracking'**
  String get shopTracking;

  /// No description provided for @shopItems.
  ///
  /// In en, this message translates to:
  /// **'Items'**
  String get shopItems;

  /// No description provided for @shopQty.
  ///
  /// In en, this message translates to:
  /// **'Qty: {count}'**
  String shopQty(int count);

  /// No description provided for @shopTotalPaid.
  ///
  /// In en, this message translates to:
  /// **'Total paid'**
  String get shopTotalPaid;

  /// No description provided for @shopShipping.
  ///
  /// In en, this message translates to:
  /// **'Shipping'**
  String get shopShipping;

  /// No description provided for @shopShip.
  ///
  /// In en, this message translates to:
  /// **'Ship'**
  String get shopShip;

  /// No description provided for @shopShipOrder.
  ///
  /// In en, this message translates to:
  /// **'Ship order'**
  String get shopShipOrder;

  /// No description provided for @shopTrackingNumber.
  ///
  /// In en, this message translates to:
  /// **'Tracking number'**
  String get shopTrackingNumber;

  /// No description provided for @shopShippingNote.
  ///
  /// In en, this message translates to:
  /// **'Shipping note'**
  String get shopShippingNote;

  /// No description provided for @shopReceive.
  ///
  /// In en, this message translates to:
  /// **'Receive'**
  String get shopReceive;

  /// No description provided for @shopAccept.
  ///
  /// In en, this message translates to:
  /// **'Accept'**
  String get shopAccept;

  /// No description provided for @shopDispute.
  ///
  /// In en, this message translates to:
  /// **'Dispute'**
  String get shopDispute;

  /// No description provided for @shopDisputeOrder.
  ///
  /// In en, this message translates to:
  /// **'Dispute order'**
  String get shopDisputeOrder;

  /// No description provided for @shopNoteOptional.
  ///
  /// In en, this message translates to:
  /// **'Note (optional)'**
  String get shopNoteOptional;

  /// No description provided for @shopCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get shopCancel;

  /// No description provided for @shopLiveAddProduct.
  ///
  /// In en, this message translates to:
  /// **'Add product'**
  String get shopLiveAddProduct;

  /// No description provided for @shopLiveNoProductsToAdd.
  ///
  /// In en, this message translates to:
  /// **'No products available to add'**
  String get shopLiveNoProductsToAdd;

  /// No description provided for @shopLiveEmptyHost.
  ///
  /// In en, this message translates to:
  /// **'No products yet — tap Add product'**
  String get shopLiveEmptyHost;

  /// No description provided for @shopLiveEmptyViewer.
  ///
  /// In en, this message translates to:
  /// **'No products in this live yet'**
  String get shopLiveEmptyViewer;

  /// No description provided for @shopPinned.
  ///
  /// In en, this message translates to:
  /// **'Pinned'**
  String get shopPinned;

  /// No description provided for @shopPin.
  ///
  /// In en, this message translates to:
  /// **'Pin'**
  String get shopPin;

  /// No description provided for @shopUnpin.
  ///
  /// In en, this message translates to:
  /// **'Unpin'**
  String get shopUnpin;

  /// No description provided for @shopRemove.
  ///
  /// In en, this message translates to:
  /// **'Remove'**
  String get shopRemove;

  /// No description provided for @shopBuy.
  ///
  /// In en, this message translates to:
  /// **'Buy'**
  String get shopBuy;

  /// No description provided for @shopItemsCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 item} other{{count} items}}'**
  String shopItemsCount(int count);

  /// No description provided for @noPostsFound.
  ///
  /// In en, this message translates to:
  /// **'No posts found'**
  String get noPostsFound;

  /// No description provided for @navHome.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get navHome;

  /// No description provided for @pressBackAgainToExit.
  ///
  /// In en, this message translates to:
  /// **'Press back again to exit'**
  String get pressBackAgainToExit;

  /// No description provided for @navFriends.
  ///
  /// In en, this message translates to:
  /// **'Friends'**
  String get navFriends;

  /// No description provided for @navAuctions.
  ///
  /// In en, this message translates to:
  /// **'Auctions'**
  String get navAuctions;

  /// No description provided for @auctionsSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search auctions...'**
  String get auctionsSearchHint;

  /// No description provided for @postsSearchTitle.
  ///
  /// In en, this message translates to:
  /// **'Search posts'**
  String get postsSearchTitle;

  /// No description provided for @postsSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search posts...'**
  String get postsSearchHint;

  /// No description provided for @searchAction.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get searchAction;

  /// No description provided for @searchHistorySeeMore.
  ///
  /// In en, this message translates to:
  /// **'See more'**
  String get searchHistorySeeMore;

  /// No description provided for @searchHistorySeeLess.
  ///
  /// In en, this message translates to:
  /// **'See less'**
  String get searchHistorySeeLess;

  /// No description provided for @searchHistoryClear.
  ///
  /// In en, this message translates to:
  /// **'Clear'**
  String get searchHistoryClear;

  /// No description provided for @searchHistoryEmpty.
  ///
  /// In en, this message translates to:
  /// **'No recent searches'**
  String get searchHistoryEmpty;

  /// No description provided for @searchSeeAll.
  ///
  /// In en, this message translates to:
  /// **'See all'**
  String get searchSeeAll;

  /// No description provided for @searchSeeLess.
  ///
  /// In en, this message translates to:
  /// **'See less'**
  String get searchSeeLess;

  /// No description provided for @searchYouMayLike.
  ///
  /// In en, this message translates to:
  /// **'You may like'**
  String get searchYouMayLike;

  /// No description provided for @searchNoResults.
  ///
  /// In en, this message translates to:
  /// **'No posts found'**
  String get searchNoResults;

  /// No description provided for @searchTabTop.
  ///
  /// In en, this message translates to:
  /// **'Top'**
  String get searchTabTop;

  /// No description provided for @searchTabUsers.
  ///
  /// In en, this message translates to:
  /// **'Users'**
  String get searchTabUsers;

  /// No description provided for @searchTabVideos.
  ///
  /// In en, this message translates to:
  /// **'Videos'**
  String get searchTabVideos;

  /// No description provided for @searchTabLive.
  ///
  /// In en, this message translates to:
  /// **'LIVE'**
  String get searchTabLive;

  /// No description provided for @searchTabSounds.
  ///
  /// In en, this message translates to:
  /// **'Sounds'**
  String get searchTabSounds;

  /// No description provided for @searchTabPlaces.
  ///
  /// In en, this message translates to:
  /// **'Places'**
  String get searchTabPlaces;

  /// No description provided for @searchComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Coming soon'**
  String get searchComingSoon;

  /// No description provided for @auctionsFiltersTitle.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get auctionsFiltersTitle;

  /// No description provided for @auctionsFiltersApply.
  ///
  /// In en, this message translates to:
  /// **'Apply filters'**
  String get auctionsFiltersApply;

  /// No description provided for @auctionsFiltersReset.
  ///
  /// In en, this message translates to:
  /// **'Reset'**
  String get auctionsFiltersReset;

  /// No description provided for @auctionsFiltersCategories.
  ///
  /// In en, this message translates to:
  /// **'Categories'**
  String get auctionsFiltersCategories;

  /// No description provided for @auctionsFiltersPriceRange.
  ///
  /// In en, this message translates to:
  /// **'Price range (USD)'**
  String get auctionsFiltersPriceRange;

  /// No description provided for @auctionsFiltersMinPrice.
  ///
  /// In en, this message translates to:
  /// **'Min price'**
  String get auctionsFiltersMinPrice;

  /// No description provided for @auctionsFiltersMaxPrice.
  ///
  /// In en, this message translates to:
  /// **'Max price'**
  String get auctionsFiltersMaxPrice;

  /// No description provided for @auctionsFiltersLiveStatus.
  ///
  /// In en, this message translates to:
  /// **'Auction status'**
  String get auctionsFiltersLiveStatus;

  /// No description provided for @auctionsFilterLive.
  ///
  /// In en, this message translates to:
  /// **'Live'**
  String get auctionsFilterLive;

  /// No description provided for @auctionsFilterEnded.
  ///
  /// In en, this message translates to:
  /// **'Ended'**
  String get auctionsFilterEnded;

  /// No description provided for @endedAuctionsNow.
  ///
  /// In en, this message translates to:
  /// **'Ended auctions'**
  String get endedAuctionsNow;

  /// No description provided for @auctionsFiltersTimeRemaining.
  ///
  /// In en, this message translates to:
  /// **'Time remaining'**
  String get auctionsFiltersTimeRemaining;

  /// No description provided for @auctionsFiltersInvalidPriceRange.
  ///
  /// In en, this message translates to:
  /// **'Min price cannot be greater than max price'**
  String get auctionsFiltersInvalidPriceRange;

  /// No description provided for @auctionsTimeRemainingAny.
  ///
  /// In en, this message translates to:
  /// **'Any time'**
  String get auctionsTimeRemainingAny;

  /// No description provided for @auctionsTimeRemaining1Hour.
  ///
  /// In en, this message translates to:
  /// **'Ending within 1 hour'**
  String get auctionsTimeRemaining1Hour;

  /// No description provided for @auctionsTimeRemaining6Hours.
  ///
  /// In en, this message translates to:
  /// **'Ending within 6 hours'**
  String get auctionsTimeRemaining6Hours;

  /// No description provided for @auctionsTimeRemaining24Hours.
  ///
  /// In en, this message translates to:
  /// **'Ending within 24 hours'**
  String get auctionsTimeRemaining24Hours;

  /// No description provided for @auctionsTimeRemaining7Days.
  ///
  /// In en, this message translates to:
  /// **'Ending within 7 days'**
  String get auctionsTimeRemaining7Days;

  /// No description provided for @auctionsTimeRemaining30Days.
  ///
  /// In en, this message translates to:
  /// **'Ending within 30 days'**
  String get auctionsTimeRemaining30Days;

  /// No description provided for @popularCategories.
  ///
  /// In en, this message translates to:
  /// **'Popular categories'**
  String get popularCategories;

  /// No description provided for @viewAll.
  ///
  /// In en, this message translates to:
  /// **'View all'**
  String get viewAll;

  /// No description provided for @auctionCategoryWatches.
  ///
  /// In en, this message translates to:
  /// **'Luxury watches'**
  String get auctionCategoryWatches;

  /// No description provided for @auctionCategoryCars.
  ///
  /// In en, this message translates to:
  /// **'Sports cars'**
  String get auctionCategoryCars;

  /// No description provided for @auctionCategoryArt.
  ///
  /// In en, this message translates to:
  /// **'Rare art'**
  String get auctionCategoryArt;

  /// No description provided for @auctionCategoryJewelry.
  ///
  /// In en, this message translates to:
  /// **'Jewelry'**
  String get auctionCategoryJewelry;

  /// No description provided for @auctionCategoryAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get auctionCategoryAll;

  /// No description provided for @activeAuctionsNow.
  ///
  /// In en, this message translates to:
  /// **'Active auctions now'**
  String get activeAuctionsNow;

  /// No description provided for @liveBadge.
  ///
  /// In en, this message translates to:
  /// **'Live'**
  String get liveBadge;

  /// No description provided for @auctionActiveBadge.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get auctionActiveBadge;

  /// No description provided for @auctionTapToEnter.
  ///
  /// In en, this message translates to:
  /// **'Tap to enter'**
  String get auctionTapToEnter;

  /// No description provided for @auctionFinishedBadge.
  ///
  /// In en, this message translates to:
  /// **'Finished'**
  String get auctionFinishedBadge;

  /// No description provided for @auctionCancelAction.
  ///
  /// In en, this message translates to:
  /// **'Cancel auction'**
  String get auctionCancelAction;

  /// No description provided for @auctionCancelTitle.
  ///
  /// In en, this message translates to:
  /// **'Cancel this auction?'**
  String get auctionCancelTitle;

  /// No description provided for @auctionCancelMessage.
  ///
  /// In en, this message translates to:
  /// **'Gift contributions may be refunded if escrow is enabled. This cannot be undone.'**
  String get auctionCancelMessage;

  /// No description provided for @auctionCancelSuccess.
  ///
  /// In en, this message translates to:
  /// **'Auction cancelled'**
  String get auctionCancelSuccess;

  /// No description provided for @auctionSellerRequiredTitle.
  ///
  /// In en, this message translates to:
  /// **'Seller verification required'**
  String get auctionSellerRequiredTitle;

  /// No description provided for @auctionSellerRequiredMessage.
  ///
  /// In en, this message translates to:
  /// **'Complete seller verification before hosting auctions.'**
  String get auctionSellerRequiredMessage;

  /// No description provided for @auctionSellerPendingMessage.
  ///
  /// In en, this message translates to:
  /// **'Your seller verification is still under review.'**
  String get auctionSellerPendingMessage;

  /// No description provided for @auctionSellerRejectedMessage.
  ///
  /// In en, this message translates to:
  /// **'Your seller verification was rejected. Please resubmit.'**
  String get auctionSellerRejectedMessage;

  /// No description provided for @auctionSellerCompleteAction.
  ///
  /// In en, this message translates to:
  /// **'Complete verification'**
  String get auctionSellerCompleteAction;

  /// No description provided for @sellerVerificationTitle.
  ///
  /// In en, this message translates to:
  /// **'Seller verification'**
  String get sellerVerificationTitle;

  /// No description provided for @sellerVerificationSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Upload your passport and address details to host auctions.'**
  String get sellerVerificationSubtitle;

  /// No description provided for @sellerVerificationSubtitleSimple.
  ///
  /// In en, this message translates to:
  /// **'Enter your ID number and upload a passport photo.'**
  String get sellerVerificationSubtitleSimple;

  /// No description provided for @sellerVerificationIdentitySection.
  ///
  /// In en, this message translates to:
  /// **'Identity'**
  String get sellerVerificationIdentitySection;

  /// No description provided for @sellerVerificationPassportSection.
  ///
  /// In en, this message translates to:
  /// **'Passport'**
  String get sellerVerificationPassportSection;

  /// No description provided for @sellerVerificationContactSection.
  ///
  /// In en, this message translates to:
  /// **'Contact & address'**
  String get sellerVerificationContactSection;

  /// No description provided for @sellerVerificationFullLegalName.
  ///
  /// In en, this message translates to:
  /// **'Full legal name'**
  String get sellerVerificationFullLegalName;

  /// No description provided for @sellerVerificationDateOfBirth.
  ///
  /// In en, this message translates to:
  /// **'Date of birth'**
  String get sellerVerificationDateOfBirth;

  /// No description provided for @sellerVerificationNationality.
  ///
  /// In en, this message translates to:
  /// **'Nationality'**
  String get sellerVerificationNationality;

  /// No description provided for @sellerVerificationNationalId.
  ///
  /// In en, this message translates to:
  /// **'ID number'**
  String get sellerVerificationNationalId;

  /// No description provided for @sellerVerificationNationalIdOptional.
  ///
  /// In en, this message translates to:
  /// **'National ID (optional)'**
  String get sellerVerificationNationalIdOptional;

  /// No description provided for @sellerVerificationNationalIdRequired.
  ///
  /// In en, this message translates to:
  /// **'ID number is required'**
  String get sellerVerificationNationalIdRequired;

  /// No description provided for @sellerVerificationPassportNumber.
  ///
  /// In en, this message translates to:
  /// **'Passport number'**
  String get sellerVerificationPassportNumber;

  /// No description provided for @sellerVerificationPassportCountry.
  ///
  /// In en, this message translates to:
  /// **'Passport country'**
  String get sellerVerificationPassportCountry;

  /// No description provided for @sellerVerificationPassportExpiry.
  ///
  /// In en, this message translates to:
  /// **'Passport expiry date'**
  String get sellerVerificationPassportExpiry;

  /// No description provided for @sellerVerificationPassportFront.
  ///
  /// In en, this message translates to:
  /// **'Passport front photo'**
  String get sellerVerificationPassportFront;

  /// No description provided for @sellerVerificationPassportPhoto.
  ///
  /// In en, this message translates to:
  /// **'Passport photo'**
  String get sellerVerificationPassportPhoto;

  /// No description provided for @sellerVerificationPassportBackOptional.
  ///
  /// In en, this message translates to:
  /// **'Passport back (optional)'**
  String get sellerVerificationPassportBackOptional;

  /// No description provided for @sellerVerificationSelfieOptional.
  ///
  /// In en, this message translates to:
  /// **'Selfie (optional)'**
  String get sellerVerificationSelfieOptional;

  /// No description provided for @sellerVerificationContactPhone.
  ///
  /// In en, this message translates to:
  /// **'Contact phone'**
  String get sellerVerificationContactPhone;

  /// No description provided for @sellerVerificationAddressLine1.
  ///
  /// In en, this message translates to:
  /// **'Address line 1'**
  String get sellerVerificationAddressLine1;

  /// No description provided for @sellerVerificationAddressLine2Optional.
  ///
  /// In en, this message translates to:
  /// **'Address line 2 (optional)'**
  String get sellerVerificationAddressLine2Optional;

  /// No description provided for @sellerVerificationCity.
  ///
  /// In en, this message translates to:
  /// **'City'**
  String get sellerVerificationCity;

  /// No description provided for @sellerVerificationRegionOptional.
  ///
  /// In en, this message translates to:
  /// **'Region / state (optional)'**
  String get sellerVerificationRegionOptional;

  /// No description provided for @sellerVerificationCountry.
  ///
  /// In en, this message translates to:
  /// **'Country'**
  String get sellerVerificationCountry;

  /// No description provided for @sellerVerificationPostalOptional.
  ///
  /// In en, this message translates to:
  /// **'Postal code (optional)'**
  String get sellerVerificationPostalOptional;

  /// No description provided for @sellerVerificationPickDate.
  ///
  /// In en, this message translates to:
  /// **'Select date'**
  String get sellerVerificationPickDate;

  /// No description provided for @sellerVerificationTapToUpload.
  ///
  /// In en, this message translates to:
  /// **'Tap to upload'**
  String get sellerVerificationTapToUpload;

  /// No description provided for @sellerVerificationUploading.
  ///
  /// In en, this message translates to:
  /// **'Uploading…'**
  String get sellerVerificationUploading;

  /// No description provided for @sellerVerificationUploaded.
  ///
  /// In en, this message translates to:
  /// **'Uploaded'**
  String get sellerVerificationUploaded;

  /// No description provided for @sellerVerificationSubmit.
  ///
  /// In en, this message translates to:
  /// **'Submit for review'**
  String get sellerVerificationSubmit;

  /// No description provided for @sellerVerificationSubmitted.
  ///
  /// In en, this message translates to:
  /// **'Verification submitted. We\'ll review it soon.'**
  String get sellerVerificationSubmitted;

  /// No description provided for @sellerVerificationDobRequired.
  ///
  /// In en, this message translates to:
  /// **'Date of birth is required'**
  String get sellerVerificationDobRequired;

  /// No description provided for @sellerVerificationExpiryRequired.
  ///
  /// In en, this message translates to:
  /// **'Passport expiry date is required'**
  String get sellerVerificationExpiryRequired;

  /// No description provided for @sellerVerificationExpiryFuture.
  ///
  /// In en, this message translates to:
  /// **'Passport must not be expired'**
  String get sellerVerificationExpiryFuture;

  /// No description provided for @sellerVerificationPassportFrontRequired.
  ///
  /// In en, this message translates to:
  /// **'Passport photo is required'**
  String get sellerVerificationPassportFrontRequired;

  /// No description provided for @auctionTimeLeft.
  ///
  /// In en, this message translates to:
  /// **'Time left'**
  String get auctionTimeLeft;

  /// No description provided for @auctionStartsIn.
  ///
  /// In en, this message translates to:
  /// **'Starts in'**
  String get auctionStartsIn;

  /// No description provided for @auctionAddedBy.
  ///
  /// In en, this message translates to:
  /// **'Added by {username}'**
  String auctionAddedBy(String username);

  /// No description provided for @auctionCountdownDayCount.
  ///
  /// In en, this message translates to:
  /// **'{days} day'**
  String auctionCountdownDayCount(int days);

  /// No description provided for @auctionTimerHour.
  ///
  /// In en, this message translates to:
  /// **'h'**
  String get auctionTimerHour;

  /// No description provided for @auctionTimerMinute.
  ///
  /// In en, this message translates to:
  /// **'m'**
  String get auctionTimerMinute;

  /// No description provided for @auctionTimerSecond.
  ///
  /// In en, this message translates to:
  /// **'s'**
  String get auctionTimerSecond;

  /// No description provided for @auctionCountdownWithDays.
  ///
  /// In en, this message translates to:
  /// **'{days} day {time}'**
  String auctionCountdownWithDays(int days, String time);

  /// No description provided for @auctionTargetReachedMessage.
  ///
  /// In en, this message translates to:
  /// **'Target price reached. Auction ended.'**
  String get auctionTargetReachedMessage;

  /// No description provided for @auctionBiddingClosed.
  ///
  /// In en, this message translates to:
  /// **'Bidding closed'**
  String get auctionBiddingClosed;

  /// No description provided for @auctionTargetPrice.
  ///
  /// In en, this message translates to:
  /// **'Target {amount} {currency}'**
  String auctionTargetPrice(String amount, String currency);

  /// No description provided for @liveStreamsTitle.
  ///
  /// In en, this message translates to:
  /// **'Live Streams'**
  String get liveStreamsTitle;

  /// No description provided for @searchLiveStreamsHint.
  ///
  /// In en, this message translates to:
  /// **'Search live streams...'**
  String get searchLiveStreamsHint;

  /// No description provided for @liveFilterAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get liveFilterAll;

  /// No description provided for @liveFilterRealEstate.
  ///
  /// In en, this message translates to:
  /// **'Real Estate'**
  String get liveFilterRealEstate;

  /// No description provided for @liveFilterAuctions.
  ///
  /// In en, this message translates to:
  /// **'Auctions'**
  String get liveFilterAuctions;

  /// No description provided for @liveFilterTrending.
  ///
  /// In en, this message translates to:
  /// **'Trending'**
  String get liveFilterTrending;

  /// No description provided for @liveFilterInvestments.
  ///
  /// In en, this message translates to:
  /// **'Investments'**
  String get liveFilterInvestments;

  /// No description provided for @liveStreamTitle1.
  ///
  /// In en, this message translates to:
  /// **'Live Real Estate Q&A'**
  String get liveStreamTitle1;

  /// No description provided for @liveStreamTitle2.
  ///
  /// In en, this message translates to:
  /// **'Luxury Auction Showcase'**
  String get liveStreamTitle2;

  /// No description provided for @liveStreamTitle3.
  ///
  /// In en, this message translates to:
  /// **'Investment Tips Live'**
  String get liveStreamTitle3;

  /// No description provided for @liveHostName.
  ///
  /// In en, this message translates to:
  /// **'Host {number}'**
  String liveHostName(int number);

  /// No description provided for @liveViewersCount.
  ///
  /// In en, this message translates to:
  /// **'{count}'**
  String liveViewersCount(int count);

  /// No description provided for @joinLiveStream.
  ///
  /// In en, this message translates to:
  /// **'Join live'**
  String get joinLiveStream;

  /// No description provided for @liveDetailsTitle.
  ///
  /// In en, this message translates to:
  /// **'Live stream'**
  String get liveDetailsTitle;

  /// No description provided for @liveFollow.
  ///
  /// In en, this message translates to:
  /// **'Follow'**
  String get liveFollow;

  /// No description provided for @liveFollowing.
  ///
  /// In en, this message translates to:
  /// **'Following'**
  String get liveFollowing;

  /// No description provided for @liveViewersShort.
  ///
  /// In en, this message translates to:
  /// **'{count} viewers'**
  String liveViewersShort(String count);

  /// No description provided for @liveTopBid.
  ///
  /// In en, this message translates to:
  /// **'Highest price'**
  String get liveTopBid;

  /// No description provided for @liveTargetPrice.
  ///
  /// In en, this message translates to:
  /// **'Target price'**
  String get liveTargetPrice;

  /// No description provided for @currencyUsd.
  ///
  /// In en, this message translates to:
  /// **'USD'**
  String get currencyUsd;

  /// No description provided for @currencySar.
  ///
  /// In en, this message translates to:
  /// **'SAR'**
  String get currencySar;

  /// No description provided for @liveHighestBidAmount.
  ///
  /// In en, this message translates to:
  /// **'{amount} {currency}'**
  String liveHighestBidAmount(String amount, String currency);

  /// No description provided for @liveAddCommentOrBid.
  ///
  /// In en, this message translates to:
  /// **'Add comment or bid...'**
  String get liveAddCommentOrBid;

  /// No description provided for @liveBidAmount.
  ///
  /// In en, this message translates to:
  /// **'Bid {amount} SAR'**
  String liveBidAmount(int amount);

  /// No description provided for @liveCommentSample.
  ///
  /// In en, this message translates to:
  /// **'This property looks amazing!'**
  String get liveCommentSample;

  /// No description provided for @liveChatYou.
  ///
  /// In en, this message translates to:
  /// **'You'**
  String get liveChatYou;

  /// No description provided for @liveSendGift.
  ///
  /// In en, this message translates to:
  /// **'Send Gift'**
  String get liveSendGift;

  /// No description provided for @liveSelectGift.
  ///
  /// In en, this message translates to:
  /// **'Select a Gift'**
  String get liveSelectGift;

  /// No description provided for @liveSendToHost.
  ///
  /// In en, this message translates to:
  /// **'Send to Host'**
  String get liveSendToHost;

  /// No description provided for @liveGiftSent.
  ///
  /// In en, this message translates to:
  /// **'Sent {name} {icon}'**
  String liveGiftSent(String name, String icon);

  /// No description provided for @liveGiftCommentGeneric.
  ///
  /// In en, this message translates to:
  /// **'Sent a gift'**
  String get liveGiftCommentGeneric;

  /// No description provided for @liveGiftRose.
  ///
  /// In en, this message translates to:
  /// **'Rose'**
  String get liveGiftRose;

  /// No description provided for @liveGiftCoffee.
  ///
  /// In en, this message translates to:
  /// **'Coffee'**
  String get liveGiftCoffee;

  /// No description provided for @liveGiftDonut.
  ///
  /// In en, this message translates to:
  /// **'Donut'**
  String get liveGiftDonut;

  /// No description provided for @liveGiftHeart.
  ///
  /// In en, this message translates to:
  /// **'Heart'**
  String get liveGiftHeart;

  /// No description provided for @liveGiftParty.
  ///
  /// In en, this message translates to:
  /// **'Party'**
  String get liveGiftParty;

  /// No description provided for @liveGiftCrown.
  ///
  /// In en, this message translates to:
  /// **'Crown'**
  String get liveGiftCrown;

  /// No description provided for @liveGiftRocket.
  ///
  /// In en, this message translates to:
  /// **'Rocket'**
  String get liveGiftRocket;

  /// No description provided for @liveGiftDiamond.
  ///
  /// In en, this message translates to:
  /// **'Diamond'**
  String get liveGiftDiamond;

  /// No description provided for @liveVipBadge.
  ///
  /// In en, this message translates to:
  /// **'VIP'**
  String get liveVipBadge;

  /// No description provided for @liveCoinsBalance.
  ///
  /// In en, this message translates to:
  /// **'{count}'**
  String liveCoinsBalance(int count);

  /// No description provided for @liveGiftPriceLabel.
  ///
  /// In en, this message translates to:
  /// **'PRICE'**
  String get liveGiftPriceLabel;

  /// No description provided for @liveGiftPriceAmount.
  ///
  /// In en, this message translates to:
  /// **'{amount} {currency}'**
  String liveGiftPriceAmount(String amount, String currency);

  /// No description provided for @liveGiftBuy.
  ///
  /// In en, this message translates to:
  /// **'Buy — {price}'**
  String liveGiftBuy(String price);

  /// No description provided for @liveGiftBuyMore.
  ///
  /// In en, this message translates to:
  /// **'Buy more'**
  String get liveGiftBuyMore;

  /// No description provided for @liveGiftBuying.
  ///
  /// In en, this message translates to:
  /// **'Buying…'**
  String get liveGiftBuying;

  /// No description provided for @liveGiftSending.
  ///
  /// In en, this message translates to:
  /// **'Sending…'**
  String get liveGiftSending;

  /// No description provided for @liveGiftPurchaseSuccess.
  ///
  /// In en, this message translates to:
  /// **'Purchased {name}'**
  String liveGiftPurchaseSuccess(String name);

  /// No description provided for @liveGiftLoginRequired.
  ///
  /// In en, this message translates to:
  /// **'Sign in to buy or send gifts'**
  String get liveGiftLoginRequired;

  /// No description provided for @liveGiftNoRecipient.
  ///
  /// In en, this message translates to:
  /// **'Open a live or auction post to send a gift'**
  String get liveGiftNoRecipient;

  /// No description provided for @liveGiftCannotSendToSelf.
  ///
  /// In en, this message translates to:
  /// **'You cannot send a gift to your own auction'**
  String get liveGiftCannotSendToSelf;

  /// No description provided for @liveGiftCatalogEmpty.
  ///
  /// In en, this message translates to:
  /// **'No gifts available'**
  String get liveGiftCatalogEmpty;

  /// No description provided for @liveGiftRetry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get liveGiftRetry;

  /// No description provided for @liveGiftOwned.
  ///
  /// In en, this message translates to:
  /// **'×{count}'**
  String liveGiftOwned(int count);

  /// No description provided for @liveGiftLevelBanner.
  ///
  /// In en, this message translates to:
  /// **'Send a Gift to activate your gifter level and rewards'**
  String get liveGiftLevelBanner;

  /// No description provided for @liveGiftPinHint.
  ///
  /// In en, this message translates to:
  /// **'Pin Gifts you like to the top'**
  String get liveGiftPinHint;

  /// No description provided for @liveGiftPinAction.
  ///
  /// In en, this message translates to:
  /// **'Pin'**
  String get liveGiftPinAction;

  /// No description provided for @liveGiftUnpinAction.
  ///
  /// In en, this message translates to:
  /// **'Unpin'**
  String get liveGiftUnpinAction;

  /// No description provided for @liveGiftTabGifts.
  ///
  /// In en, this message translates to:
  /// **'Gifts'**
  String get liveGiftTabGifts;

  /// No description provided for @liveGiftTabSongs.
  ///
  /// In en, this message translates to:
  /// **'Songs'**
  String get liveGiftTabSongs;

  /// No description provided for @liveGiftTabInteractive.
  ///
  /// In en, this message translates to:
  /// **'Interactive'**
  String get liveGiftTabInteractive;

  /// No description provided for @liveGiftTabComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Coming soon'**
  String get liveGiftTabComingSoon;

  /// No description provided for @liveGiftSendAction.
  ///
  /// In en, this message translates to:
  /// **'Send'**
  String get liveGiftSendAction;

  /// No description provided for @liveGiftRecharge.
  ///
  /// In en, this message translates to:
  /// **'Recharge'**
  String get liveGiftRecharge;

  /// No description provided for @firstRechargeTitle.
  ///
  /// In en, this message translates to:
  /// **'First recharge offer'**
  String get firstRechargeTitle;

  /// No description provided for @firstRechargeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Rewards are only available with cash recharge. Offer ends in {days} days.'**
  String firstRechargeSubtitle(int days);

  /// No description provided for @firstRechargeRoseTitle.
  ///
  /// In en, this message translates to:
  /// **'Get Rose x3 in your Backpack'**
  String get firstRechargeRoseTitle;

  /// No description provided for @firstRechargeRoseBody.
  ///
  /// In en, this message translates to:
  /// **'Get 1 now and the rest after 24 hours, each available for 7 days'**
  String get firstRechargeRoseBody;

  /// No description provided for @firstRechargeBonusTitle.
  ///
  /// In en, this message translates to:
  /// **'Get bonus Coins'**
  String get firstRechargeBonusTitle;

  /// No description provided for @firstRechargeBonusBody.
  ///
  /// In en, this message translates to:
  /// **'Use Coins on virtual items such as Gifts'**
  String get firstRechargeBonusBody;

  /// No description provided for @firstRechargeGetCoins.
  ///
  /// In en, this message translates to:
  /// **'Get Coins'**
  String get firstRechargeGetCoins;

  /// No description provided for @firstRechargeGetCoinsHint.
  ///
  /// In en, this message translates to:
  /// **'Recharge to get Gifts and bonus Coins.'**
  String get firstRechargeGetCoinsHint;

  /// No description provided for @firstRechargePolicy.
  ///
  /// In en, this message translates to:
  /// **'By continuing, you agree to the Virtual Items Policy. You will also lose the extra bonus if you withdraw from this purchase.'**
  String get firstRechargePolicy;

  /// No description provided for @firstRechargeCta.
  ///
  /// In en, this message translates to:
  /// **'Get {coins} ({price})'**
  String firstRechargeCta(String coins, String price);

  /// No description provided for @auctionGiftsTitle.
  ///
  /// In en, this message translates to:
  /// **'Auction gifts'**
  String get auctionGiftsTitle;

  /// No description provided for @auctionGiftsEmpty.
  ///
  /// In en, this message translates to:
  /// **'No gifts sent on this auction yet'**
  String get auctionGiftsEmpty;

  /// No description provided for @auctionGiftsSummary.
  ///
  /// In en, this message translates to:
  /// **'{current} / {target} {currency}'**
  String auctionGiftsSummary(String current, String target, String currency);

  /// No description provided for @auctionGiftsContribution.
  ///
  /// In en, this message translates to:
  /// **'+{amount} {currency}'**
  String auctionGiftsContribution(String amount, String currency);

  /// No description provided for @liveQuickBid.
  ///
  /// In en, this message translates to:
  /// **'+{amount}'**
  String liveQuickBid(int amount);

  /// No description provided for @highestCurrentBid.
  ///
  /// In en, this message translates to:
  /// **'Highest current bid'**
  String get highestCurrentBid;

  /// No description provided for @bidsLabel.
  ///
  /// In en, this message translates to:
  /// **'Bids'**
  String get bidsLabel;

  /// No description provided for @auctionGiftsLabel.
  ///
  /// In en, this message translates to:
  /// **'Gifts'**
  String get auctionGiftsLabel;

  /// No description provided for @bidNow.
  ///
  /// In en, this message translates to:
  /// **'Bid now'**
  String get bidNow;

  /// No description provided for @navAdd.
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get navAdd;

  /// No description provided for @navChat.
  ///
  /// In en, this message translates to:
  /// **'Chat'**
  String get navChat;

  /// No description provided for @navProfile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get navProfile;

  /// No description provided for @describePostHint.
  ///
  /// In en, this message translates to:
  /// **'Add a description...'**
  String get describePostHint;

  /// No description provided for @addDescriptionHint.
  ///
  /// In en, this message translates to:
  /// **'Add a description...'**
  String get addDescriptionHint;

  /// No description provided for @hashtagsLabel.
  ///
  /// In en, this message translates to:
  /// **'Hashtags'**
  String get hashtagsLabel;

  /// No description provided for @mentionsLabel.
  ///
  /// In en, this message translates to:
  /// **'Mention'**
  String get mentionsLabel;

  /// No description provided for @whoCanWatchLabel.
  ///
  /// In en, this message translates to:
  /// **'Who can view this post'**
  String get whoCanWatchLabel;

  /// No description provided for @allowCommentsLabel.
  ///
  /// In en, this message translates to:
  /// **'Allow comments'**
  String get allowCommentsLabel;

  /// No description provided for @allowReuseLabel.
  ///
  /// In en, this message translates to:
  /// **'Allow reuse of content'**
  String get allowReuseLabel;

  /// No description provided for @allowReuseSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Duet, Stitch, stickers, and add to Story'**
  String get allowReuseSubtitle;

  /// No description provided for @videoPrivacySection.
  ///
  /// In en, this message translates to:
  /// **'Video privacy'**
  String get videoPrivacySection;

  /// No description provided for @advancedSettings.
  ///
  /// In en, this message translates to:
  /// **'Advanced settings'**
  String get advancedSettings;

  /// No description provided for @addPostSettingsTitle.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get addPostSettingsTitle;

  /// No description provided for @everyoneCanViewPost.
  ///
  /// In en, this message translates to:
  /// **'Everyone can view this post'**
  String get everyoneCanViewPost;

  /// No description provided for @friendsCanViewPost.
  ///
  /// In en, this message translates to:
  /// **'Friends can view this post'**
  String get friendsCanViewPost;

  /// No description provided for @onlyYouCanViewPost.
  ///
  /// In en, this message translates to:
  /// **'Only you can view this post'**
  String get onlyYouCanViewPost;

  /// No description provided for @friendsPrivacySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Followers you follow back'**
  String get friendsPrivacySubtitle;

  /// No description provided for @draftsLabel.
  ///
  /// In en, this message translates to:
  /// **'Drafts'**
  String get draftsLabel;

  /// No description provided for @moreOptionsLabel.
  ///
  /// In en, this message translates to:
  /// **'More options'**
  String get moreOptionsLabel;

  /// No description provided for @previewLabel.
  ///
  /// In en, this message translates to:
  /// **'Preview'**
  String get previewLabel;

  /// No description provided for @editCoverLabel.
  ///
  /// In en, this message translates to:
  /// **'Edit cover'**
  String get editCoverLabel;

  /// No description provided for @locationLabelShort.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get locationLabelShort;

  /// No description provided for @addPostDraftsComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Drafts coming soon'**
  String get addPostDraftsComingSoon;

  /// No description provided for @allowDuetLabel.
  ///
  /// In en, this message translates to:
  /// **'Allow Duet'**
  String get allowDuetLabel;

  /// No description provided for @allowStitchLabel.
  ///
  /// In en, this message translates to:
  /// **'Allow Stitch'**
  String get allowStitchLabel;

  /// No description provided for @addLocationLabel.
  ///
  /// In en, this message translates to:
  /// **'Add location'**
  String get addLocationLabel;

  /// No description provided for @selectCity.
  ///
  /// In en, this message translates to:
  /// **'Select city'**
  String get selectCity;

  /// No description provided for @selectCityHint.
  ///
  /// In en, this message translates to:
  /// **'Search cities'**
  String get selectCityHint;

  /// No description provided for @selectCountryHint.
  ///
  /// In en, this message translates to:
  /// **'Search countries'**
  String get selectCountryHint;

  /// No description provided for @locationSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search countries or cities'**
  String get locationSearchHint;

  /// No description provided for @clearLocation.
  ///
  /// In en, this message translates to:
  /// **'Clear location'**
  String get clearLocation;

  /// No description provided for @everyoneLabel.
  ///
  /// In en, this message translates to:
  /// **'Everyone'**
  String get everyoneLabel;

  /// No description provided for @friendsLabel.
  ///
  /// In en, this message translates to:
  /// **'Friends'**
  String get friendsLabel;

  /// No description provided for @onlyMeLabel.
  ///
  /// In en, this message translates to:
  /// **'Only me'**
  String get onlyMeLabel;

  /// No description provided for @videoLabel.
  ///
  /// In en, this message translates to:
  /// **'Video'**
  String get videoLabel;

  /// No description provided for @recordVideo.
  ///
  /// In en, this message translates to:
  /// **'Record video'**
  String get recordVideo;

  /// No description provided for @imagesLabel.
  ///
  /// In en, this message translates to:
  /// **'Images'**
  String get imagesLabel;

  /// No description provided for @imageFromLibrary.
  ///
  /// In en, this message translates to:
  /// **'Upload images from library'**
  String get imageFromLibrary;

  /// No description provided for @videoFromLibrary.
  ///
  /// In en, this message translates to:
  /// **'Import videos from library'**
  String get videoFromLibrary;

  /// No description provided for @tapToSelectMedia.
  ///
  /// In en, this message translates to:
  /// **'Tap to upload from library'**
  String get tapToSelectMedia;

  /// No description provided for @pleaseSelectMediaFirst.
  ///
  /// In en, this message translates to:
  /// **'Please select media first'**
  String get pleaseSelectMediaFirst;

  /// No description provided for @loginRequired.
  ///
  /// In en, this message translates to:
  /// **'Login Required'**
  String get loginRequired;

  /// No description provided for @loginRequiredMessage.
  ///
  /// In en, this message translates to:
  /// **'Please login to like, comment or save posts'**
  String get loginRequiredMessage;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @login.
  ///
  /// In en, this message translates to:
  /// **'Login'**
  String get login;

  /// No description provided for @commentsTitle.
  ///
  /// In en, this message translates to:
  /// **'Comments'**
  String get commentsTitle;

  /// No description provided for @commentsCount.
  ///
  /// In en, this message translates to:
  /// **'{count} comments'**
  String commentsCount(int count);

  /// No description provided for @postLikesEmpty.
  ///
  /// In en, this message translates to:
  /// **'No likes yet'**
  String get postLikesEmpty;

  /// No description provided for @postViewsEmpty.
  ///
  /// In en, this message translates to:
  /// **'No views yet'**
  String get postViewsEmpty;

  /// No description provided for @postViewWatchedDuration.
  ///
  /// In en, this message translates to:
  /// **'{seconds}s watched'**
  String postViewWatchedDuration(int seconds);

  /// No description provided for @viewsLabel.
  ///
  /// In en, this message translates to:
  /// **'Views'**
  String get viewsLabel;

  /// No description provided for @commentsSortNewest.
  ///
  /// In en, this message translates to:
  /// **'Newest'**
  String get commentsSortNewest;

  /// No description provided for @commentsSortOldest.
  ///
  /// In en, this message translates to:
  /// **'Oldest'**
  String get commentsSortOldest;

  /// No description provided for @commentsSortTop.
  ///
  /// In en, this message translates to:
  /// **'Top'**
  String get commentsSortTop;

  /// No description provided for @noCommentsYet.
  ///
  /// In en, this message translates to:
  /// **'No comments yet. Be the first!'**
  String get noCommentsYet;

  /// No description provided for @addCommentHint.
  ///
  /// In en, this message translates to:
  /// **'Add comment...'**
  String get addCommentHint;

  /// No description provided for @justNow.
  ///
  /// In en, this message translates to:
  /// **'Just now'**
  String get justNow;

  /// No description provided for @inboxTimeMinutes.
  ///
  /// In en, this message translates to:
  /// **'{count}m'**
  String inboxTimeMinutes(int count);

  /// No description provided for @inboxTimeHours.
  ///
  /// In en, this message translates to:
  /// **'{count}h'**
  String inboxTimeHours(int count);

  /// No description provided for @inboxTimeDays.
  ///
  /// In en, this message translates to:
  /// **'{count}d'**
  String inboxTimeDays(int count);

  /// No description provided for @replyAction.
  ///
  /// In en, this message translates to:
  /// **'Reply'**
  String get replyAction;

  /// No description provided for @replyingTo.
  ///
  /// In en, this message translates to:
  /// **'Replying to {username}'**
  String replyingTo(String username);

  /// No description provided for @viewReplies.
  ///
  /// In en, this message translates to:
  /// **'View {count} replies'**
  String viewReplies(int count);

  /// No description provided for @hideReplies.
  ///
  /// In en, this message translates to:
  /// **'Hide replies'**
  String get hideReplies;

  /// No description provided for @loadMoreReplies.
  ///
  /// In en, this message translates to:
  /// **'Load more replies'**
  String get loadMoreReplies;

  /// No description provided for @deleteCommentTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete comment?'**
  String get deleteCommentTitle;

  /// No description provided for @deleteCommentMessage.
  ///
  /// In en, this message translates to:
  /// **'This comment will be permanently removed.'**
  String get deleteCommentMessage;

  /// No description provided for @deleteAction.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get deleteAction;

  /// No description provided for @editPost.
  ///
  /// In en, this message translates to:
  /// **'Edit post'**
  String get editPost;

  /// No description provided for @deletePost.
  ///
  /// In en, this message translates to:
  /// **'Delete post'**
  String get deletePost;

  /// No description provided for @deletePostTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete post?'**
  String get deletePostTitle;

  /// No description provided for @deletePostMessage.
  ///
  /// In en, this message translates to:
  /// **'This post will be permanently removed. Only you can delete your own posts.'**
  String get deletePostMessage;

  /// No description provided for @postOptionShare.
  ///
  /// In en, this message translates to:
  /// **'Share'**
  String get postOptionShare;

  /// No description provided for @postOptionReport.
  ///
  /// In en, this message translates to:
  /// **'Report'**
  String get postOptionReport;

  /// No description provided for @postOptionNotInterested.
  ///
  /// In en, this message translates to:
  /// **'Not interested'**
  String get postOptionNotInterested;

  /// No description provided for @feedInterestPromptQuestion.
  ///
  /// In en, this message translates to:
  /// **'Are you interested in this kind of content?'**
  String get feedInterestPromptQuestion;

  /// No description provided for @feedInterestPromptYes.
  ///
  /// In en, this message translates to:
  /// **'Yes'**
  String get feedInterestPromptYes;

  /// No description provided for @feedInterestPromptNo.
  ///
  /// In en, this message translates to:
  /// **'No'**
  String get feedInterestPromptNo;

  /// No description provided for @feedInterestPromptThanks.
  ///
  /// In en, this message translates to:
  /// **'Thanks — we\'ll show more like this'**
  String get feedInterestPromptThanks;

  /// No description provided for @postOptionDownload.
  ///
  /// In en, this message translates to:
  /// **'Download'**
  String get postOptionDownload;

  /// No description provided for @postOptionAddToStory.
  ///
  /// In en, this message translates to:
  /// **'Add to story'**
  String get postOptionAddToStory;

  /// No description provided for @postOptionShareAsGif.
  ///
  /// In en, this message translates to:
  /// **'Share as GIF'**
  String get postOptionShareAsGif;

  /// No description provided for @postOptionCreateGroup.
  ///
  /// In en, this message translates to:
  /// **'Create group'**
  String get postOptionCreateGroup;

  /// No description provided for @postLinkCopied.
  ///
  /// In en, this message translates to:
  /// **'Link copied to clipboard'**
  String get postLinkCopied;

  /// No description provided for @postReportTitle.
  ///
  /// In en, this message translates to:
  /// **'Report post?'**
  String get postReportTitle;

  /// No description provided for @postReportMessage.
  ///
  /// In en, this message translates to:
  /// **'Tell us if this post breaks our community guidelines.'**
  String get postReportMessage;

  /// No description provided for @postReportSubmitted.
  ///
  /// In en, this message translates to:
  /// **'Thanks for reporting. We\'ll review this post.'**
  String get postReportSubmitted;

  /// No description provided for @postReportReasonSpam.
  ///
  /// In en, this message translates to:
  /// **'Spam'**
  String get postReportReasonSpam;

  /// No description provided for @postReportReasonHarassment.
  ///
  /// In en, this message translates to:
  /// **'Harassment or bullying'**
  String get postReportReasonHarassment;

  /// No description provided for @postReportReasonHateSpeech.
  ///
  /// In en, this message translates to:
  /// **'Hate speech'**
  String get postReportReasonHateSpeech;

  /// No description provided for @postReportReasonViolence.
  ///
  /// In en, this message translates to:
  /// **'Violence or dangerous content'**
  String get postReportReasonViolence;

  /// No description provided for @postReportReasonNudity.
  ///
  /// In en, this message translates to:
  /// **'Nudity or sexual content'**
  String get postReportReasonNudity;

  /// No description provided for @postReportReasonFalseInfo.
  ///
  /// In en, this message translates to:
  /// **'False information'**
  String get postReportReasonFalseInfo;

  /// No description provided for @postReportReasonScam.
  ///
  /// In en, this message translates to:
  /// **'Scam or fraud'**
  String get postReportReasonScam;

  /// No description provided for @postReportReasonCopyright.
  ///
  /// In en, this message translates to:
  /// **'Copyright infringement'**
  String get postReportReasonCopyright;

  /// No description provided for @postReportReasonOther.
  ///
  /// In en, this message translates to:
  /// **'Other'**
  String get postReportReasonOther;

  /// No description provided for @postNotInterestedApplied.
  ///
  /// In en, this message translates to:
  /// **'We\'ll show fewer posts like this'**
  String get postNotInterestedApplied;

  /// No description provided for @postDownloadStarted.
  ///
  /// In en, this message translates to:
  /// **'Downloading…'**
  String get postDownloadStarted;

  /// No description provided for @postDownloadSaved.
  ///
  /// In en, this message translates to:
  /// **'Saved to app downloads'**
  String get postDownloadSaved;

  /// No description provided for @postDownloadFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not download media'**
  String get postDownloadFailed;

  /// No description provided for @postShareAsGifUnavailable.
  ///
  /// In en, this message translates to:
  /// **'GIF share is only available for videos'**
  String get postShareAsGifUnavailable;

  /// No description provided for @postShareSheetTitle.
  ///
  /// In en, this message translates to:
  /// **'Share post'**
  String get postShareSheetTitle;

  /// No description provided for @postShareSendToTitle.
  ///
  /// In en, this message translates to:
  /// **'Send to'**
  String get postShareSendToTitle;

  /// No description provided for @postShareSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get postShareSearchHint;

  /// No description provided for @postShareRecentChats.
  ///
  /// In en, this message translates to:
  /// **'Recent chats'**
  String get postShareRecentChats;

  /// No description provided for @postShareSearchUsers.
  ///
  /// In en, this message translates to:
  /// **'Search friends and users'**
  String get postShareSearchUsers;

  /// No description provided for @postShareNoUsers.
  ///
  /// In en, this message translates to:
  /// **'No users found'**
  String get postShareNoUsers;

  /// No description provided for @postShareToApps.
  ///
  /// In en, this message translates to:
  /// **'Share to apps'**
  String get postShareToApps;

  /// No description provided for @postShareMessenger.
  ///
  /// In en, this message translates to:
  /// **'Messenger'**
  String get postShareMessenger;

  /// No description provided for @postShareFacebook.
  ///
  /// In en, this message translates to:
  /// **'Facebook'**
  String get postShareFacebook;

  /// No description provided for @postShareInstagram.
  ///
  /// In en, this message translates to:
  /// **'Instagram'**
  String get postShareInstagram;

  /// No description provided for @postShareWhatsApp.
  ///
  /// In en, this message translates to:
  /// **'WhatsApp'**
  String get postShareWhatsApp;

  /// No description provided for @postShareTelegram.
  ///
  /// In en, this message translates to:
  /// **'Telegram'**
  String get postShareTelegram;

  /// No description provided for @postShareTwitter.
  ///
  /// In en, this message translates to:
  /// **'X'**
  String get postShareTwitter;

  /// No description provided for @postShareSms.
  ///
  /// In en, this message translates to:
  /// **'SMS'**
  String get postShareSms;

  /// No description provided for @postShareEmail.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get postShareEmail;

  /// No description provided for @postShareCopyLink.
  ///
  /// In en, this message translates to:
  /// **'Copy link'**
  String get postShareCopyLink;

  /// No description provided for @postShareMore.
  ///
  /// In en, this message translates to:
  /// **'More'**
  String get postShareMore;

  /// No description provided for @postOptionCast.
  ///
  /// In en, this message translates to:
  /// **'Cast'**
  String get postOptionCast;

  /// No description provided for @postShareInstagramHint.
  ///
  /// In en, this message translates to:
  /// **'Link copied — paste in Instagram'**
  String get postShareInstagramHint;

  /// No description provided for @postOptionCastUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Casting is not available yet'**
  String get postOptionCastUnavailable;

  /// No description provided for @postShareSendFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not send post'**
  String get postShareSendFailed;

  /// No description provided for @postShareSentTo.
  ///
  /// In en, this message translates to:
  /// **'Sent to {name}'**
  String postShareSentTo(String name);

  /// No description provided for @postShareSend.
  ///
  /// In en, this message translates to:
  /// **'Send'**
  String get postShareSend;

  /// No description provided for @postShareSendToCount.
  ///
  /// In en, this message translates to:
  /// **'Send ({count})'**
  String postShareSendToCount(int count);

  /// No description provided for @postShareSentCount.
  ///
  /// In en, this message translates to:
  /// **'Sent to {count} people'**
  String postShareSentCount(int count);

  /// No description provided for @postQuickShareTitle.
  ///
  /// In en, this message translates to:
  /// **'Recent friends'**
  String get postQuickShareTitle;

  /// No description provided for @postQuickShareSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Select friends, tap again to cancel, then send'**
  String get postQuickShareSubtitle;

  /// No description provided for @postAddToStoryHint.
  ///
  /// In en, this message translates to:
  /// **'Create your story — the post is ready to share'**
  String get postAddToStoryHint;

  /// No description provided for @postCreateGroupHint.
  ///
  /// In en, this message translates to:
  /// **'Pick contacts to start a group chat'**
  String get postCreateGroupHint;

  /// No description provided for @postUpdatedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Post updated successfully'**
  String get postUpdatedSuccessfully;

  /// No description provided for @postDeletedSuccessfully.
  ///
  /// In en, this message translates to:
  /// **'Post deleted successfully'**
  String get postDeletedSuccessfully;

  /// No description provided for @saveButton.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get saveButton;

  /// No description provided for @categoryLabel.
  ///
  /// In en, this message translates to:
  /// **'Category'**
  String get categoryLabel;

  /// No description provided for @selectCategoryHint.
  ///
  /// In en, this message translates to:
  /// **'Choose a category'**
  String get selectCategoryHint;

  /// No description provided for @hashtagsHint.
  ///
  /// In en, this message translates to:
  /// **'Type #tag in your caption (e.g. #travel #food)'**
  String get hashtagsHint;

  /// No description provided for @mentionsHint.
  ///
  /// In en, this message translates to:
  /// **'Type @username in your caption (e.g. @jane_doe)'**
  String get mentionsHint;

  /// No description provided for @mediaLabel.
  ///
  /// In en, this message translates to:
  /// **'Media'**
  String get mediaLabel;

  /// No description provided for @settingsAndPrivacy.
  ///
  /// In en, this message translates to:
  /// **'Settings and privacy'**
  String get settingsAndPrivacy;

  /// No description provided for @settingsSectionAccount.
  ///
  /// In en, this message translates to:
  /// **'Account'**
  String get settingsSectionAccount;

  /// No description provided for @settingsSecurity.
  ///
  /// In en, this message translates to:
  /// **'Security'**
  String get settingsSecurity;

  /// No description provided for @settingsPrivacy.
  ///
  /// In en, this message translates to:
  /// **'Privacy'**
  String get settingsPrivacy;

  /// No description provided for @privacyPrivateAccount.
  ///
  /// In en, this message translates to:
  /// **'Private account'**
  String get privacyPrivateAccount;

  /// No description provided for @privacyPrivateAccountSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Only approved followers can see your posts and stories.'**
  String get privacyPrivateAccountSubtitle;

  /// No description provided for @privacyWhoCanMessage.
  ///
  /// In en, this message translates to:
  /// **'Who can message you'**
  String get privacyWhoCanMessage;

  /// No description provided for @privacyMessageEveryone.
  ///
  /// In en, this message translates to:
  /// **'Everyone'**
  String get privacyMessageEveryone;

  /// No description provided for @privacyMessageFollowers.
  ///
  /// In en, this message translates to:
  /// **'People you follow'**
  String get privacyMessageFollowers;

  /// No description provided for @privacyMessageFriends.
  ///
  /// In en, this message translates to:
  /// **'Friends'**
  String get privacyMessageFriends;

  /// No description provided for @privacyMessageNobody.
  ///
  /// In en, this message translates to:
  /// **'No one'**
  String get privacyMessageNobody;

  /// No description provided for @privacyAllowComments.
  ///
  /// In en, this message translates to:
  /// **'Allow comments'**
  String get privacyAllowComments;

  /// No description provided for @privacyAllowCommentsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'People can comment on your posts.'**
  String get privacyAllowCommentsSubtitle;

  /// No description provided for @privacyUpdated.
  ///
  /// In en, this message translates to:
  /// **'Privacy settings updated'**
  String get privacyUpdated;

  /// No description provided for @privacySectionAccount.
  ///
  /// In en, this message translates to:
  /// **'Account privacy'**
  String get privacySectionAccount;

  /// No description provided for @privacySectionInteractions.
  ///
  /// In en, this message translates to:
  /// **'Interactions'**
  String get privacySectionInteractions;

  /// No description provided for @settingsSectionContent.
  ///
  /// In en, this message translates to:
  /// **'Content & display'**
  String get settingsSectionContent;

  /// No description provided for @settingsLanguage.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get settingsLanguage;

  /// No description provided for @settingsNotifications.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get settingsNotifications;

  /// No description provided for @settingsDarkMode.
  ///
  /// In en, this message translates to:
  /// **'Dark mode'**
  String get settingsDarkMode;

  /// No description provided for @settingsSectionSupport.
  ///
  /// In en, this message translates to:
  /// **'Support'**
  String get settingsSectionSupport;

  /// No description provided for @settingsHelpCenter.
  ///
  /// In en, this message translates to:
  /// **'Help center'**
  String get settingsHelpCenter;

  /// No description provided for @settingsAbout.
  ///
  /// In en, this message translates to:
  /// **'About'**
  String get settingsAbout;

  /// No description provided for @settingsLogout.
  ///
  /// In en, this message translates to:
  /// **'Log out'**
  String get settingsLogout;

  /// No description provided for @settingsSelectLanguage.
  ///
  /// In en, this message translates to:
  /// **'Select language'**
  String get settingsSelectLanguage;

  /// No description provided for @settingsAppearance.
  ///
  /// In en, this message translates to:
  /// **'Appearance'**
  String get settingsAppearance;

  /// No description provided for @settingsLightMode.
  ///
  /// In en, this message translates to:
  /// **'Light mode'**
  String get settingsLightMode;

  /// No description provided for @settingsDarkModeOption.
  ///
  /// In en, this message translates to:
  /// **'Dark mode'**
  String get settingsDarkModeOption;

  /// No description provided for @settingsLanguageEnglish.
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get settingsLanguageEnglish;

  /// No description provided for @settingsLanguageArabic.
  ///
  /// In en, this message translates to:
  /// **'Arabic'**
  String get settingsLanguageArabic;

  /// No description provided for @settingsOn.
  ///
  /// In en, this message translates to:
  /// **'On'**
  String get settingsOn;

  /// No description provided for @settingsOff.
  ///
  /// In en, this message translates to:
  /// **'Off'**
  String get settingsOff;

  /// No description provided for @settingsLogoutTitle.
  ///
  /// In en, this message translates to:
  /// **'Log out?'**
  String get settingsLogoutTitle;

  /// No description provided for @settingsLogoutMessage.
  ///
  /// In en, this message translates to:
  /// **'You will need to sign in again to use your account.'**
  String get settingsLogoutMessage;

  /// No description provided for @settingsComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Coming soon'**
  String get settingsComingSoon;

  /// No description provided for @settingsChatWallpaper.
  ///
  /// In en, this message translates to:
  /// **'Chat wallpaper'**
  String get settingsChatWallpaper;

  /// No description provided for @settingsSectionAdmin.
  ///
  /// In en, this message translates to:
  /// **'Admin'**
  String get settingsSectionAdmin;

  /// No description provided for @settingsAdminActivity.
  ///
  /// In en, this message translates to:
  /// **'User activity'**
  String get settingsAdminActivity;

  /// No description provided for @adminActivityTitle.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get adminActivityTitle;

  /// No description provided for @adminActivityEmpty.
  ///
  /// In en, this message translates to:
  /// **'No activity yet'**
  String get adminActivityEmpty;

  /// No description provided for @adminActivityJustNow.
  ///
  /// In en, this message translates to:
  /// **'Just now'**
  String get adminActivityJustNow;

  /// No description provided for @adminActivityNoDetails.
  ///
  /// In en, this message translates to:
  /// **'No details'**
  String get adminActivityNoDetails;

  /// No description provided for @adminActivityOnPost.
  ///
  /// In en, this message translates to:
  /// **'On post: {post}'**
  String adminActivityOnPost(String post);

  /// No description provided for @adminActivityTypeCreatePost.
  ///
  /// In en, this message translates to:
  /// **'Created a post'**
  String get adminActivityTypeCreatePost;

  /// No description provided for @adminActivityTypeComment.
  ///
  /// In en, this message translates to:
  /// **'Commented'**
  String get adminActivityTypeComment;

  /// No description provided for @adminActivityTypeLikePost.
  ///
  /// In en, this message translates to:
  /// **'Liked a post'**
  String get adminActivityTypeLikePost;

  /// No description provided for @adminActivityTypeSendGift.
  ///
  /// In en, this message translates to:
  /// **'Sent a gift'**
  String get adminActivityTypeSendGift;

  /// No description provided for @chatWallpaperTitle.
  ///
  /// In en, this message translates to:
  /// **'Chat wallpaper'**
  String get chatWallpaperTitle;

  /// No description provided for @chatWallpaperSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Choose a background pattern for your chats. Colors follow your app theme.'**
  String get chatWallpaperSubtitle;

  /// No description provided for @chatWallpaperPlus.
  ///
  /// In en, this message translates to:
  /// **'Plus'**
  String get chatWallpaperPlus;

  /// No description provided for @chatWallpaperSquares.
  ///
  /// In en, this message translates to:
  /// **'Squares'**
  String get chatWallpaperSquares;

  /// No description provided for @chatWallpaperMaze.
  ///
  /// In en, this message translates to:
  /// **'Maze'**
  String get chatWallpaperMaze;

  /// No description provided for @chatWallpaperChooseFromPhotos.
  ///
  /// In en, this message translates to:
  /// **'Choose from Photos'**
  String get chatWallpaperChooseFromPhotos;

  /// No description provided for @chatWallpaperUploadDeviceSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Upload personal photo from device'**
  String get chatWallpaperUploadDeviceSubtitle;

  /// No description provided for @chatWallpaperDefault.
  ///
  /// In en, this message translates to:
  /// **'Default (No Wallpaper)'**
  String get chatWallpaperDefault;

  /// No description provided for @chatWallpaperCatalog.
  ///
  /// In en, this message translates to:
  /// **'Wallpapers Catalog'**
  String get chatWallpaperCatalog;

  /// No description provided for @chatWallpaperUpdated.
  ///
  /// In en, this message translates to:
  /// **'Personal background updated'**
  String get chatWallpaperUpdated;

  /// No description provided for @chatSettingsTitle.
  ///
  /// In en, this message translates to:
  /// **'Details'**
  String get chatSettingsTitle;

  /// No description provided for @chatSettingsProfile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get chatSettingsProfile;

  /// No description provided for @chatSettingsMute.
  ///
  /// In en, this message translates to:
  /// **'Mute'**
  String get chatSettingsMute;

  /// No description provided for @chatSettingsMuted.
  ///
  /// In en, this message translates to:
  /// **'Muted'**
  String get chatSettingsMuted;

  /// No description provided for @chatSettingsReport.
  ///
  /// In en, this message translates to:
  /// **'Report'**
  String get chatSettingsReport;

  /// No description provided for @chatSettingsMuteNotifications.
  ///
  /// In en, this message translates to:
  /// **'Mute notifications'**
  String get chatSettingsMuteNotifications;

  /// No description provided for @chatSettingsPinToTop.
  ///
  /// In en, this message translates to:
  /// **'Pin to top'**
  String get chatSettingsPinToTop;

  /// No description provided for @chatSettingsWallpaperSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Custom theme background'**
  String get chatSettingsWallpaperSubtitle;

  /// No description provided for @chatSettingsSearch.
  ///
  /// In en, this message translates to:
  /// **'Search in conversation'**
  String get chatSettingsSearch;

  /// No description provided for @chatSettingsBlock.
  ///
  /// In en, this message translates to:
  /// **'Block @{username}'**
  String chatSettingsBlock(String username);

  /// No description provided for @chatSettingsBlocked.
  ///
  /// In en, this message translates to:
  /// **'Blocked'**
  String get chatSettingsBlocked;

  /// No description provided for @unblock.
  ///
  /// In en, this message translates to:
  /// **'Unblock'**
  String get unblock;

  /// No description provided for @chatYouBlockedUser.
  ///
  /// In en, this message translates to:
  /// **'You blocked this user. Unblock to send a message.'**
  String get chatYouBlockedUser;

  /// No description provided for @userNotFound.
  ///
  /// In en, this message translates to:
  /// **'User not found'**
  String get userNotFound;

  /// No description provided for @chatSettingsDeleteHistory.
  ///
  /// In en, this message translates to:
  /// **'Delete chat history'**
  String get chatSettingsDeleteHistory;

  /// No description provided for @chatSettingsSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Type keyword...'**
  String get chatSettingsSearchHint;

  /// No description provided for @chatSettingsSearching.
  ///
  /// In en, this message translates to:
  /// **'Searching for \"{query}\"...'**
  String chatSettingsSearching(String query);

  /// No description provided for @chatSettingsReportTitle.
  ///
  /// In en, this message translates to:
  /// **'Report @{username}'**
  String chatSettingsReportTitle(String username);

  /// No description provided for @chatSettingsReportSpam.
  ///
  /// In en, this message translates to:
  /// **'Spam or Scam'**
  String get chatSettingsReportSpam;

  /// No description provided for @chatSettingsReportHarassment.
  ///
  /// In en, this message translates to:
  /// **'Harassment or Bullying'**
  String get chatSettingsReportHarassment;

  /// No description provided for @chatSettingsReportInappropriate.
  ///
  /// In en, this message translates to:
  /// **'Inappropriate Content'**
  String get chatSettingsReportInappropriate;

  /// No description provided for @chatSettingsReportSubmitted.
  ///
  /// In en, this message translates to:
  /// **'Report submitted: {reason}'**
  String chatSettingsReportSubmitted(String reason);

  /// No description provided for @chatSettingsBlockTitle.
  ///
  /// In en, this message translates to:
  /// **'Block @{username}?'**
  String chatSettingsBlockTitle(String username);

  /// No description provided for @chatSettingsBlockMessage.
  ///
  /// In en, this message translates to:
  /// **'They won\'t be able to message you or view your profile.'**
  String get chatSettingsBlockMessage;

  /// No description provided for @chatSettingsDeleteTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete chat history?'**
  String get chatSettingsDeleteTitle;

  /// No description provided for @chatSettingsDeleteMessage.
  ///
  /// In en, this message translates to:
  /// **'This will remove the chat history for you. This action cannot be undone.'**
  String get chatSettingsDeleteMessage;

  /// No description provided for @messagesTitle.
  ///
  /// In en, this message translates to:
  /// **'Messages'**
  String get messagesTitle;

  /// No description provided for @messagesInboxTitle.
  ///
  /// In en, this message translates to:
  /// **'Inbox'**
  String get messagesInboxTitle;

  /// No description provided for @messagesNewChatTitle.
  ///
  /// In en, this message translates to:
  /// **'New chat'**
  String get messagesNewChatTitle;

  /// No description provided for @messagesNewChatSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get messagesNewChatSearchHint;

  /// No description provided for @closeAction.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get closeAction;

  /// No description provided for @chatSendMessageHint.
  ///
  /// In en, this message translates to:
  /// **'Send a message...'**
  String get chatSendMessageHint;

  /// No description provided for @chatActiveYesterday.
  ///
  /// In en, this message translates to:
  /// **'Active yesterday'**
  String get chatActiveYesterday;

  /// No description provided for @messagesSwitchAccount.
  ///
  /// In en, this message translates to:
  /// **'Switch Account'**
  String get messagesSwitchAccount;

  /// No description provided for @messagesNewConversation.
  ///
  /// In en, this message translates to:
  /// **'New conversation'**
  String get messagesNewConversation;

  /// No description provided for @messagesSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search messages or people'**
  String get messagesSearchHint;

  /// No description provided for @messagesYourStory.
  ///
  /// In en, this message translates to:
  /// **'Your Story'**
  String get messagesYourStory;

  /// No description provided for @messagesPeopleYouMayKnow.
  ///
  /// In en, this message translates to:
  /// **'People you may know'**
  String get messagesPeopleYouMayKnow;

  /// No description provided for @messagesSeeAll.
  ///
  /// In en, this message translates to:
  /// **'See all'**
  String get messagesSeeAll;

  /// No description provided for @messagesFollow.
  ///
  /// In en, this message translates to:
  /// **'Follow'**
  String get messagesFollow;

  /// No description provided for @messagesFollowing.
  ///
  /// In en, this message translates to:
  /// **'Following'**
  String get messagesFollowing;

  /// No description provided for @messagesRecentMentions.
  ///
  /// In en, this message translates to:
  /// **'Recent Mentions'**
  String get messagesRecentMentions;

  /// No description provided for @messagesActivityFollowers.
  ///
  /// In en, this message translates to:
  /// **'Followers'**
  String get messagesActivityFollowers;

  /// No description provided for @messagesActivityActivities.
  ///
  /// In en, this message translates to:
  /// **'Activities'**
  String get messagesActivityActivities;

  /// No description provided for @messagesActivityTitle.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get messagesActivityTitle;

  /// No description provided for @messagesNewFollowers.
  ///
  /// In en, this message translates to:
  /// **'New followers'**
  String get messagesNewFollowers;

  /// No description provided for @messagesActivityComments.
  ///
  /// In en, this message translates to:
  /// **'Comments'**
  String get messagesActivityComments;

  /// No description provided for @messagesActivityMentions.
  ///
  /// In en, this message translates to:
  /// **'Mentions'**
  String get messagesActivityMentions;

  /// No description provided for @messagesActivityNotifications.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get messagesActivityNotifications;

  /// No description provided for @activityTabLikes.
  ///
  /// In en, this message translates to:
  /// **'Likes'**
  String get activityTabLikes;

  /// No description provided for @activityAllCaughtUp.
  ///
  /// In en, this message translates to:
  /// **'You\'re all caught up'**
  String get activityAllCaughtUp;

  /// No description provided for @activityClearNotificationsMessage.
  ///
  /// In en, this message translates to:
  /// **'Remove all read notifications from your activity feed?'**
  String get activityClearNotificationsMessage;

  /// No description provided for @activityOpenCommentsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'See comments on your posts'**
  String get activityOpenCommentsSubtitle;

  /// No description provided for @activityInboxSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Likes, comments and more'**
  String get activityInboxSubtitle;

  /// No description provided for @messagesRecentMessages.
  ///
  /// In en, this message translates to:
  /// **'Recent Messages'**
  String get messagesRecentMessages;

  /// No description provided for @messagesAllChats.
  ///
  /// In en, this message translates to:
  /// **'All Chats'**
  String get messagesAllChats;

  /// No description provided for @messagesAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get messagesAll;

  /// No description provided for @messagesNoResults.
  ///
  /// In en, this message translates to:
  /// **'No results found'**
  String get messagesNoResults;

  /// No description provided for @messagesInboxNoMessagesYet.
  ///
  /// In en, this message translates to:
  /// **'No messages yet'**
  String get messagesInboxNoMessagesYet;

  /// No description provided for @messagesInboxYouPrefix.
  ///
  /// In en, this message translates to:
  /// **'You'**
  String get messagesInboxYouPrefix;

  /// No description provided for @messagesInboxLastPhoto.
  ///
  /// In en, this message translates to:
  /// **'Photo'**
  String get messagesInboxLastPhoto;

  /// No description provided for @messagesInboxLastVideo.
  ///
  /// In en, this message translates to:
  /// **'Video'**
  String get messagesInboxLastVideo;

  /// No description provided for @messagesInboxLastVoice.
  ///
  /// In en, this message translates to:
  /// **'Voice message'**
  String get messagesInboxLastVoice;

  /// No description provided for @messagesInboxLastGift.
  ///
  /// In en, this message translates to:
  /// **'Gift'**
  String get messagesInboxLastGift;

  /// No description provided for @messagesInboxLastShare.
  ///
  /// In en, this message translates to:
  /// **'Shared a post'**
  String get messagesInboxLastShare;

  /// No description provided for @messagesInboxMessageDeleted.
  ///
  /// In en, this message translates to:
  /// **'Message deleted'**
  String get messagesInboxMessageDeleted;

  /// No description provided for @messagesInboxGroupFallback.
  ///
  /// In en, this message translates to:
  /// **'Group'**
  String get messagesInboxGroupFallback;

  /// No description provided for @messagesInboxUserFallback.
  ///
  /// In en, this message translates to:
  /// **'User'**
  String get messagesInboxUserFallback;

  /// No description provided for @messagesPreviewProperty.
  ///
  /// In en, this message translates to:
  /// **'Hi, is the property still available?'**
  String get messagesPreviewProperty;

  /// No description provided for @messagesPreviewOffer.
  ///
  /// In en, this message translates to:
  /// **'New offer has been sent'**
  String get messagesPreviewOffer;

  /// No description provided for @messagesPreviewThanks.
  ///
  /// In en, this message translates to:
  /// **'Thank you for your interest'**
  String get messagesPreviewThanks;

  /// No description provided for @messagesPreviewCar.
  ///
  /// In en, this message translates to:
  /// **'When can I check the car?'**
  String get messagesPreviewCar;

  /// No description provided for @messagesMentionVilla.
  ///
  /// In en, this message translates to:
  /// **'Great post describing the villa! @myself'**
  String get messagesMentionVilla;

  /// No description provided for @messagesMentionCheck.
  ///
  /// In en, this message translates to:
  /// **'Check this out @myself'**
  String get messagesMentionCheck;

  /// No description provided for @messagesSuggestionBioDesigner.
  ///
  /// In en, this message translates to:
  /// **'Interior Designer | Arch'**
  String get messagesSuggestionBioDesigner;

  /// No description provided for @messagesSuggestionBioJeddah.
  ///
  /// In en, this message translates to:
  /// **'Top listings in Jeddah'**
  String get messagesSuggestionBioJeddah;

  /// No description provided for @messagesSuggestionBioLuxury.
  ///
  /// In en, this message translates to:
  /// **'Worldwide luxury estates'**
  String get messagesSuggestionBioLuxury;

  /// No description provided for @messagesSuggestionFriendsOfFriends.
  ///
  /// In en, this message translates to:
  /// **'Suggested for you'**
  String get messagesSuggestionFriendsOfFriends;

  /// No description provided for @messagesSuggestionPopular.
  ///
  /// In en, this message translates to:
  /// **'Popular creator'**
  String get messagesSuggestionPopular;

  /// No description provided for @messagesSuggestionMutualFriends.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 mutual friend} other{{count} mutual friends}}'**
  String messagesSuggestionMutualFriends(num count);

  /// No description provided for @messagesSuggestionsEmpty.
  ///
  /// In en, this message translates to:
  /// **'No suggestions right now'**
  String get messagesSuggestionsEmpty;

  /// No description provided for @userCommentsTitle.
  ///
  /// In en, this message translates to:
  /// **'My Comments'**
  String get userCommentsTitle;

  /// No description provided for @userCommentsEmpty.
  ///
  /// In en, this message translates to:
  /// **'You haven\'t commented on any posts yet'**
  String get userCommentsEmpty;

  /// No description provided for @userCommentReplyLabel.
  ///
  /// In en, this message translates to:
  /// **'Reply'**
  String get userCommentReplyLabel;

  /// No description provided for @userCommentAction.
  ///
  /// In en, this message translates to:
  /// **'commented'**
  String get userCommentAction;

  /// No description provided for @userCommentOnPost.
  ///
  /// In en, this message translates to:
  /// **'On post by {author}'**
  String userCommentOnPost(String author);

  /// No description provided for @userLikesTitle.
  ///
  /// In en, this message translates to:
  /// **'Likes'**
  String get userLikesTitle;

  /// No description provided for @userLikesEmpty.
  ///
  /// In en, this message translates to:
  /// **'No one has liked your posts yet'**
  String get userLikesEmpty;

  /// No description provided for @userLikeReceivedAction.
  ///
  /// In en, this message translates to:
  /// **'liked your post'**
  String get userLikeReceivedAction;

  /// No description provided for @userMentionsTitle.
  ///
  /// In en, this message translates to:
  /// **'My Mentions'**
  String get userMentionsTitle;

  /// No description provided for @userMentionsEmpty.
  ///
  /// In en, this message translates to:
  /// **'No one has mentioned you yet'**
  String get userMentionsEmpty;

  /// No description provided for @userMentionAction.
  ///
  /// In en, this message translates to:
  /// **'mentioned you'**
  String get userMentionAction;

  /// No description provided for @userMentionInComment.
  ///
  /// In en, this message translates to:
  /// **'in a comment'**
  String get userMentionInComment;

  /// No description provided for @userFollowersTitle.
  ///
  /// In en, this message translates to:
  /// **'Followers'**
  String get userFollowersTitle;

  /// No description provided for @userFollowerAction.
  ///
  /// In en, this message translates to:
  /// **'followed you'**
  String get userFollowerAction;

  /// No description provided for @chatMessageDeleted.
  ///
  /// In en, this message translates to:
  /// **'This message was deleted'**
  String get chatMessageDeleted;

  /// No description provided for @chatActionReply.
  ///
  /// In en, this message translates to:
  /// **'Reply'**
  String get chatActionReply;

  /// No description provided for @chatActionReact.
  ///
  /// In en, this message translates to:
  /// **'React'**
  String get chatActionReact;

  /// No description provided for @chatActionDelete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get chatActionDelete;

  /// No description provided for @chatDeleteMessageTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete message?'**
  String get chatDeleteMessageTitle;

  /// No description provided for @chatDeleteMessageMessage.
  ///
  /// In en, this message translates to:
  /// **'This message will be hidden for everyone in the chat.'**
  String get chatDeleteMessageMessage;

  /// No description provided for @chatActiveNow.
  ///
  /// In en, this message translates to:
  /// **'Active now'**
  String get chatActiveNow;

  /// No description provided for @chatAddComment.
  ///
  /// In en, this message translates to:
  /// **'Write message'**
  String get chatAddComment;

  /// No description provided for @chatRecording.
  ///
  /// In en, this message translates to:
  /// **'Recording...'**
  String get chatRecording;

  /// No description provided for @chatSlideUpToCancel.
  ///
  /// In en, this message translates to:
  /// **'Slide up to cancel'**
  String get chatSlideUpToCancel;

  /// No description provided for @chatRecordingPermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'Allow microphone access to record voice messages.'**
  String get chatRecordingPermissionDenied;

  /// No description provided for @chatRecordingPermissionTitle.
  ///
  /// In en, this message translates to:
  /// **'Microphone access'**
  String get chatRecordingPermissionTitle;

  /// No description provided for @chatRecordingPermissionSettingsMessage.
  ///
  /// In en, this message translates to:
  /// **'Voice messages need the microphone. Open Settings, tap Permissions, and allow Microphone for Bimo Bond.'**
  String get chatRecordingPermissionSettingsMessage;

  /// No description provided for @chatRecordingOpenSettings.
  ///
  /// In en, this message translates to:
  /// **'Open Settings'**
  String get chatRecordingOpenSettings;

  /// No description provided for @chatRecordingAllowMicrophone.
  ///
  /// In en, this message translates to:
  /// **'Allow'**
  String get chatRecordingAllowMicrophone;

  /// No description provided for @chatRecordingPluginUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Voice recording is not ready. Stop the app completely, then run it again (not hot reload).'**
  String get chatRecordingPluginUnavailable;

  /// No description provided for @chatVoiceTooShort.
  ///
  /// In en, this message translates to:
  /// **'Hold longer to record a voice message.'**
  String get chatVoiceTooShort;

  /// No description provided for @chatVoicePlaybackFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not play this voice message.'**
  String get chatVoicePlaybackFailed;

  /// No description provided for @chatAttachmentSendFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not send attachment. Please try again.'**
  String get chatAttachmentSendFailed;

  /// No description provided for @chatLocationPermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'Location permission is required to share your position.'**
  String get chatLocationPermissionDenied;

  /// No description provided for @chatContactsPermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'Contacts permission is required to share a contact.'**
  String get chatContactsPermissionDenied;

  /// No description provided for @chatFeatureComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Coming soon.'**
  String get chatFeatureComingSoon;

  /// No description provided for @chatMessageLocation.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get chatMessageLocation;

  /// No description provided for @messagesInboxLastLocation.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get messagesInboxLastLocation;

  /// No description provided for @messagesInboxLastFile.
  ///
  /// In en, this message translates to:
  /// **'File'**
  String get messagesInboxLastFile;

  /// No description provided for @messagesInboxLastContact.
  ///
  /// In en, this message translates to:
  /// **'Contact'**
  String get messagesInboxLastContact;

  /// No description provided for @chatSeedGreeting.
  ///
  /// In en, this message translates to:
  /// **'Hi! How can I help you?'**
  String get chatSeedGreeting;

  /// No description provided for @chatSeedInterested.
  ///
  /// In en, this message translates to:
  /// **'I am interested in the property shown'**
  String get chatSeedInterested;

  /// No description provided for @chatSeedFinalPrice.
  ///
  /// In en, this message translates to:
  /// **'Can I know the final price?'**
  String get chatSeedFinalPrice;

  /// No description provided for @chatSeedAutoReply.
  ///
  /// In en, this message translates to:
  /// **'Thanks for reaching out! We will get back to you soon with more details.'**
  String get chatSeedAutoReply;

  /// No description provided for @chatUserBio.
  ///
  /// In en, this message translates to:
  /// **'Interested in real estate and design.'**
  String get chatUserBio;

  /// No description provided for @chatMoreGallery.
  ///
  /// In en, this message translates to:
  /// **'Import'**
  String get chatMoreGallery;

  /// No description provided for @chatMoreCamera.
  ///
  /// In en, this message translates to:
  /// **'Camera'**
  String get chatMoreCamera;

  /// No description provided for @chatMoreVideo.
  ///
  /// In en, this message translates to:
  /// **'Video'**
  String get chatMoreVideo;

  /// No description provided for @chatMoreLocation.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get chatMoreLocation;

  /// No description provided for @chatMoreContact.
  ///
  /// In en, this message translates to:
  /// **'Contact'**
  String get chatMoreContact;

  /// No description provided for @chatMoreFile.
  ///
  /// In en, this message translates to:
  /// **'File'**
  String get chatMoreFile;

  /// No description provided for @chatMoreGift.
  ///
  /// In en, this message translates to:
  /// **'Gift'**
  String get chatMoreGift;

  /// No description provided for @chatMorePoll.
  ///
  /// In en, this message translates to:
  /// **'Poll'**
  String get chatMorePoll;

  /// No description provided for @chatGiftSheetTitle.
  ///
  /// In en, this message translates to:
  /// **'Send a gift'**
  String get chatGiftSheetTitle;

  /// No description provided for @chatGiftSheetSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Choose a gift from your inventory'**
  String get chatGiftSheetSubtitle;

  /// No description provided for @chatGiftInventoryEmpty.
  ///
  /// In en, this message translates to:
  /// **'You don\'t own any gifts yet. Buy gifts in your wallet first.'**
  String get chatGiftInventoryEmpty;

  /// No description provided for @chatGiftSentLabel.
  ///
  /// In en, this message translates to:
  /// **'Gift sent'**
  String get chatGiftSentLabel;

  /// No description provided for @chatMessageContact.
  ///
  /// In en, this message translates to:
  /// **'Contact'**
  String get chatMessageContact;

  /// No description provided for @chatPollSheetTitle.
  ///
  /// In en, this message translates to:
  /// **'Create a poll'**
  String get chatPollSheetTitle;

  /// No description provided for @chatPollQuestionHint.
  ///
  /// In en, this message translates to:
  /// **'Ask a question'**
  String get chatPollQuestionHint;

  /// No description provided for @chatPollOptionsLabel.
  ///
  /// In en, this message translates to:
  /// **'Options'**
  String get chatPollOptionsLabel;

  /// No description provided for @chatPollOptionHint.
  ///
  /// In en, this message translates to:
  /// **'Option {index}'**
  String chatPollOptionHint(int index);

  /// No description provided for @chatPollAddOption.
  ///
  /// In en, this message translates to:
  /// **'Add option'**
  String get chatPollAddOption;

  /// No description provided for @chatPollAllowMultiple.
  ///
  /// In en, this message translates to:
  /// **'Allow multiple answers'**
  String get chatPollAllowMultiple;

  /// No description provided for @chatPollSend.
  ///
  /// In en, this message translates to:
  /// **'Send poll'**
  String get chatPollSend;

  /// No description provided for @chatPollQuestionRequired.
  ///
  /// In en, this message translates to:
  /// **'Enter a question for your poll.'**
  String get chatPollQuestionRequired;

  /// No description provided for @chatPollOptionsRequired.
  ///
  /// In en, this message translates to:
  /// **'Add at least two options.'**
  String get chatPollOptionsRequired;

  /// No description provided for @chatPollEnded.
  ///
  /// In en, this message translates to:
  /// **'Poll ended'**
  String get chatPollEnded;

  /// No description provided for @chatPollVotesCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =0{No votes yet} =1{1 vote} other{{count} votes}}'**
  String chatPollVotesCount(int count);

  /// No description provided for @messagesInboxLastPoll.
  ///
  /// In en, this message translates to:
  /// **'Poll'**
  String get messagesInboxLastPoll;

  /// No description provided for @chatLastMessage1.
  ///
  /// In en, this message translates to:
  /// **'Can I know the final price?'**
  String get chatLastMessage1;

  /// No description provided for @chatLastMessage2.
  ///
  /// In en, this message translates to:
  /// **'Thanks for the update!'**
  String get chatLastMessage2;

  /// No description provided for @chatLastMessage3.
  ///
  /// In en, this message translates to:
  /// **'Is the property still available?'**
  String get chatLastMessage3;

  /// No description provided for @chatLastMessage4.
  ///
  /// In en, this message translates to:
  /// **'Sent a photo'**
  String get chatLastMessage4;

  /// No description provided for @chatLastMessage5.
  ///
  /// In en, this message translates to:
  /// **'See you tomorrow 👋'**
  String get chatLastMessage5;

  /// No description provided for @mediaStudioAutoCut.
  ///
  /// In en, this message translates to:
  /// **'AutoCut'**
  String get mediaStudioAutoCut;

  /// No description provided for @addPostAsAuction.
  ///
  /// In en, this message translates to:
  /// **'Show on live'**
  String get addPostAsAuction;

  /// No description provided for @auctionItemName.
  ///
  /// In en, this message translates to:
  /// **'Item name'**
  String get auctionItemName;

  /// No description provided for @auctionItemNameHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. Antique Pocket Watch'**
  String get auctionItemNameHint;

  /// No description provided for @auctionStartingPrice.
  ///
  /// In en, this message translates to:
  /// **'Starting price (USD)'**
  String get auctionStartingPrice;

  /// No description provided for @auctionTargetPriceLabel.
  ///
  /// In en, this message translates to:
  /// **'Target price (USD)'**
  String get auctionTargetPriceLabel;

  /// No description provided for @auctionStartDate.
  ///
  /// In en, this message translates to:
  /// **'Auction starts'**
  String get auctionStartDate;

  /// No description provided for @auctionEndDate.
  ///
  /// In en, this message translates to:
  /// **'Auction ends'**
  String get auctionEndDate;

  /// No description provided for @auctionEndBeforeStart.
  ///
  /// In en, this message translates to:
  /// **'End date must be after start date'**
  String get auctionEndBeforeStart;

  /// No description provided for @auctionTargetBelowStart.
  ///
  /// In en, this message translates to:
  /// **'Target price must be greater than starting price'**
  String get auctionTargetBelowStart;

  /// No description provided for @auctionInvalidPrice.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid price'**
  String get auctionInvalidPrice;

  /// No description provided for @hashtagFeedSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Posts with this hashtag'**
  String get hashtagFeedSubtitle;

  /// No description provided for @noHashtagPosts.
  ///
  /// In en, this message translates to:
  /// **'No posts for this hashtag yet'**
  String get noHashtagPosts;

  /// No description provided for @trendingHashtags.
  ///
  /// In en, this message translates to:
  /// **'Trending hashtags'**
  String get trendingHashtags;

  /// No description provided for @searchHashtagsHint.
  ///
  /// In en, this message translates to:
  /// **'Search hashtags'**
  String get searchHashtagsHint;

  /// No description provided for @noHashtagsFound.
  ///
  /// In en, this message translates to:
  /// **'No hashtags found'**
  String get noHashtagsFound;

  /// No description provided for @hashtagPostCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =0{No posts} =1{1 post} other{{count} posts}}'**
  String hashtagPostCount(int count);

  /// No description provided for @notificationsEmpty.
  ///
  /// In en, this message translates to:
  /// **'No notifications yet'**
  String get notificationsEmpty;

  /// No description provided for @notificationsEmptySubtitle.
  ///
  /// In en, this message translates to:
  /// **'When someone interacts with you, you\'ll see it here.'**
  String get notificationsEmptySubtitle;

  /// No description provided for @notificationsEmptyUnread.
  ///
  /// In en, this message translates to:
  /// **'You\'re all caught up — no unread notifications.'**
  String get notificationsEmptyUnread;

  /// No description provided for @notificationsEmptyRead.
  ///
  /// In en, this message translates to:
  /// **'No read notifications yet.'**
  String get notificationsEmptyRead;

  /// No description provided for @notificationsFilterUnreadCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 unread notification} other{{count} unread notifications}}'**
  String notificationsFilterUnreadCount(int count);

  /// No description provided for @notificationsRetry.
  ///
  /// In en, this message translates to:
  /// **'Try again'**
  String get notificationsRetry;

  /// No description provided for @notificationsOk.
  ///
  /// In en, this message translates to:
  /// **'OK'**
  String get notificationsOk;

  /// No description provided for @notificationsLoadError.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load notifications'**
  String get notificationsLoadError;

  /// No description provided for @notificationsMarkAllRead.
  ///
  /// In en, this message translates to:
  /// **'Mark all read'**
  String get notificationsMarkAllRead;

  /// No description provided for @notificationsClearRead.
  ///
  /// In en, this message translates to:
  /// **'Clear read'**
  String get notificationsClearRead;

  /// No description provided for @notificationsFilterAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get notificationsFilterAll;

  /// No description provided for @notificationsFilterUnread.
  ///
  /// In en, this message translates to:
  /// **'Unread'**
  String get notificationsFilterUnread;

  /// No description provided for @notificationsFilterRead.
  ///
  /// In en, this message translates to:
  /// **'Read'**
  String get notificationsFilterRead;

  /// No description provided for @notificationsFilterViewAll.
  ///
  /// In en, this message translates to:
  /// **'View all'**
  String get notificationsFilterViewAll;

  /// No description provided for @notificationsFilterActivity.
  ///
  /// In en, this message translates to:
  /// **'Activity'**
  String get notificationsFilterActivity;

  /// No description provided for @notificationsFilterAuctions.
  ///
  /// In en, this message translates to:
  /// **'Auctions'**
  String get notificationsFilterAuctions;

  /// No description provided for @notificationsFilterInvites.
  ///
  /// In en, this message translates to:
  /// **'Invites'**
  String get notificationsFilterInvites;

  /// No description provided for @notificationsAccept.
  ///
  /// In en, this message translates to:
  /// **'Accept'**
  String get notificationsAccept;

  /// No description provided for @notificationsDecline.
  ///
  /// In en, this message translates to:
  /// **'Decline'**
  String get notificationsDecline;

  /// No description provided for @notificationsEmptyActivity.
  ///
  /// In en, this message translates to:
  /// **'No activity notifications yet.'**
  String get notificationsEmptyActivity;

  /// No description provided for @notificationsEmptyAuctions.
  ///
  /// In en, this message translates to:
  /// **'No auction notifications yet.'**
  String get notificationsEmptyAuctions;

  /// No description provided for @notificationsEmptyInvites.
  ///
  /// In en, this message translates to:
  /// **'No invite notifications yet.'**
  String get notificationsEmptyInvites;

  /// No description provided for @notificationContextPost.
  ///
  /// In en, this message translates to:
  /// **'Post'**
  String get notificationContextPost;

  /// No description provided for @notificationMediaVideo.
  ///
  /// In en, this message translates to:
  /// **'Video'**
  String get notificationMediaVideo;

  /// No description provided for @notificationMediaImage.
  ///
  /// In en, this message translates to:
  /// **'Image'**
  String get notificationMediaImage;

  /// No description provided for @notificationActionFollowedYou.
  ///
  /// In en, this message translates to:
  /// **'followed you'**
  String get notificationActionFollowedYou;

  /// No description provided for @notificationActionFollowRequest.
  ///
  /// In en, this message translates to:
  /// **'requested to follow you'**
  String get notificationActionFollowRequest;

  /// No description provided for @notificationActionFollowAccepted.
  ///
  /// In en, this message translates to:
  /// **'accepted your follow request'**
  String get notificationActionFollowAccepted;

  /// No description provided for @notificationActionPostLike.
  ///
  /// In en, this message translates to:
  /// **'liked your post'**
  String get notificationActionPostLike;

  /// No description provided for @notificationActionPostComment.
  ///
  /// In en, this message translates to:
  /// **'commented on your post'**
  String get notificationActionPostComment;

  /// No description provided for @notificationActionCommentReply.
  ///
  /// In en, this message translates to:
  /// **'replied to your comment'**
  String get notificationActionCommentReply;

  /// No description provided for @notificationActionCommentLike.
  ///
  /// In en, this message translates to:
  /// **'liked your comment'**
  String get notificationActionCommentLike;

  /// No description provided for @notificationActionMention.
  ///
  /// In en, this message translates to:
  /// **'mentioned you'**
  String get notificationActionMention;

  /// No description provided for @notificationActionRepost.
  ///
  /// In en, this message translates to:
  /// **'reposted your post'**
  String get notificationActionRepost;

  /// No description provided for @notificationActionGift.
  ///
  /// In en, this message translates to:
  /// **'sent you a gift'**
  String get notificationActionGift;

  /// No description provided for @notificationActionAuctionUpdate.
  ///
  /// In en, this message translates to:
  /// **'updated an auction you follow'**
  String get notificationActionAuctionUpdate;

  /// No description provided for @notificationActionAuctionWon.
  ///
  /// In en, this message translates to:
  /// **'you won an auction'**
  String get notificationActionAuctionWon;

  /// No description provided for @notificationSomeone.
  ///
  /// In en, this message translates to:
  /// **'Someone'**
  String get notificationSomeone;

  /// No description provided for @notificationTitleDefault.
  ///
  /// In en, this message translates to:
  /// **'Notification'**
  String get notificationTitleDefault;

  /// No description provided for @notificationTitleNewFollower.
  ///
  /// In en, this message translates to:
  /// **'New follower'**
  String get notificationTitleNewFollower;

  /// No description provided for @notificationTitleFollowRequest.
  ///
  /// In en, this message translates to:
  /// **'Follow request'**
  String get notificationTitleFollowRequest;

  /// No description provided for @notificationTitleFollowAccepted.
  ///
  /// In en, this message translates to:
  /// **'Follow request accepted'**
  String get notificationTitleFollowAccepted;

  /// No description provided for @notificationTitlePostLike.
  ///
  /// In en, this message translates to:
  /// **'New like'**
  String get notificationTitlePostLike;

  /// No description provided for @notificationTitlePostComment.
  ///
  /// In en, this message translates to:
  /// **'New comment'**
  String get notificationTitlePostComment;

  /// No description provided for @notificationTitleCommentReply.
  ///
  /// In en, this message translates to:
  /// **'New reply'**
  String get notificationTitleCommentReply;

  /// No description provided for @notificationTitleCommentLike.
  ///
  /// In en, this message translates to:
  /// **'Comment liked'**
  String get notificationTitleCommentLike;

  /// No description provided for @notificationTitleMention.
  ///
  /// In en, this message translates to:
  /// **'Mention'**
  String get notificationTitleMention;

  /// No description provided for @notificationTitleRepost.
  ///
  /// In en, this message translates to:
  /// **'Repost'**
  String get notificationTitleRepost;

  /// No description provided for @notificationTitleGift.
  ///
  /// In en, this message translates to:
  /// **'Gift received'**
  String get notificationTitleGift;

  /// No description provided for @notificationTitleAuctionUpdate.
  ///
  /// In en, this message translates to:
  /// **'Auction update'**
  String get notificationTitleAuctionUpdate;

  /// No description provided for @notificationTitleAuctionWon.
  ///
  /// In en, this message translates to:
  /// **'Auction won'**
  String get notificationTitleAuctionWon;

  /// No description provided for @notificationBodyDefault.
  ///
  /// In en, this message translates to:
  /// **'You have a new notification'**
  String get notificationBodyDefault;

  /// No description provided for @notificationBodyNewFollower.
  ///
  /// In en, this message translates to:
  /// **'{name} started following you'**
  String notificationBodyNewFollower(String name);

  /// No description provided for @notificationBodyFollowRequest.
  ///
  /// In en, this message translates to:
  /// **'{name} requested to follow you'**
  String notificationBodyFollowRequest(String name);

  /// No description provided for @notificationBodyFollowAccepted.
  ///
  /// In en, this message translates to:
  /// **'{name} accepted your follow request'**
  String notificationBodyFollowAccepted(String name);

  /// No description provided for @notificationBodyPostLike.
  ///
  /// In en, this message translates to:
  /// **'{name} liked your post'**
  String notificationBodyPostLike(String name);

  /// No description provided for @notificationBodyPostComment.
  ///
  /// In en, this message translates to:
  /// **'{name} commented on your post'**
  String notificationBodyPostComment(String name);

  /// No description provided for @notificationBodyCommentReply.
  ///
  /// In en, this message translates to:
  /// **'{name} replied to your comment'**
  String notificationBodyCommentReply(String name);

  /// No description provided for @notificationBodyCommentLike.
  ///
  /// In en, this message translates to:
  /// **'{name} liked your comment'**
  String notificationBodyCommentLike(String name);

  /// No description provided for @notificationBodyMention.
  ///
  /// In en, this message translates to:
  /// **'{name} mentioned you'**
  String notificationBodyMention(String name);

  /// No description provided for @notificationBodyRepost.
  ///
  /// In en, this message translates to:
  /// **'{name} reposted your post'**
  String notificationBodyRepost(String name);

  /// No description provided for @notificationBodyGift.
  ///
  /// In en, this message translates to:
  /// **'{name} sent you a gift'**
  String notificationBodyGift(String name);

  /// No description provided for @notificationBodyAuctionUpdate.
  ///
  /// In en, this message translates to:
  /// **'An auction you follow was updated'**
  String get notificationBodyAuctionUpdate;

  /// No description provided for @notificationBodyAuctionWon.
  ///
  /// In en, this message translates to:
  /// **'You won an auction'**
  String get notificationBodyAuctionWon;

  /// No description provided for @walletTitle.
  ///
  /// In en, this message translates to:
  /// **'Wallet'**
  String get walletTitle;

  /// No description provided for @walletBalanceLabel.
  ///
  /// In en, this message translates to:
  /// **'Coins Balance'**
  String get walletBalanceLabel;

  /// No description provided for @walletChoosePackage.
  ///
  /// In en, this message translates to:
  /// **'Choose a Package'**
  String get walletChoosePackage;

  /// No description provided for @walletCustomAmountTitle.
  ///
  /// In en, this message translates to:
  /// **'Custom amount'**
  String get walletCustomAmountTitle;

  /// No description provided for @walletCustomCoinsLabel.
  ///
  /// In en, this message translates to:
  /// **'How many coins?'**
  String get walletCustomCoinsLabel;

  /// No description provided for @walletCustomCoinsHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. 500'**
  String get walletCustomCoinsHint;

  /// No description provided for @walletCustomCoinsReceive.
  ///
  /// In en, this message translates to:
  /// **'You receive'**
  String get walletCustomCoinsReceive;

  /// No description provided for @walletCustomCoinsValue.
  ///
  /// In en, this message translates to:
  /// **'{coins} coins'**
  String walletCustomCoinsValue(String coins);

  /// No description provided for @walletCustomYouPay.
  ///
  /// In en, this message translates to:
  /// **'You pay'**
  String get walletCustomYouPay;

  /// No description provided for @walletPackageQuotes.
  ///
  /// In en, this message translates to:
  /// **'Package quotes'**
  String get walletPackageQuotes;

  /// No description provided for @walletPackageQuotePrice.
  ///
  /// In en, this message translates to:
  /// **'Package price'**
  String get walletPackageQuotePrice;

  /// No description provided for @walletPricingPreviewCost.
  ///
  /// In en, this message translates to:
  /// **'Total cost'**
  String get walletPricingPreviewCost;

  /// No description provided for @walletPricingPreviewLoading.
  ///
  /// In en, this message translates to:
  /// **'Calculating...'**
  String get walletPricingPreviewLoading;

  /// No description provided for @walletCustomAmountInvalid.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid coin amount.'**
  String get walletCustomAmountInvalid;

  /// No description provided for @walletPurchaseSuccess.
  ///
  /// In en, this message translates to:
  /// **'Successfully purchased {amount} coins!'**
  String walletPurchaseSuccess(int amount);

  /// No description provided for @walletTopUpButton.
  ///
  /// In en, this message translates to:
  /// **'Top Up'**
  String get walletTopUpButton;

  /// No description provided for @walletProcessing.
  ///
  /// In en, this message translates to:
  /// **'Processing payment...'**
  String get walletProcessing;

  /// No description provided for @walletCardNumber.
  ///
  /// In en, this message translates to:
  /// **'Card Number'**
  String get walletCardNumber;

  /// No description provided for @walletExpiry.
  ///
  /// In en, this message translates to:
  /// **'Expiry Date (MM/YY)'**
  String get walletExpiry;

  /// No description provided for @walletCvv.
  ///
  /// In en, this message translates to:
  /// **'CVV'**
  String get walletCvv;

  /// No description provided for @walletCardHolder.
  ///
  /// In en, this message translates to:
  /// **'Cardholder Name'**
  String get walletCardHolder;

  /// No description provided for @walletPayButton.
  ///
  /// In en, this message translates to:
  /// **'Pay {price}'**
  String walletPayButton(String price);

  /// No description provided for @coinsHubTitle.
  ///
  /// In en, this message translates to:
  /// **'Coins'**
  String get coinsHubTitle;

  /// No description provided for @coinsAvailableBalance.
  ///
  /// In en, this message translates to:
  /// **'Available balance'**
  String get coinsAvailableBalance;

  /// No description provided for @coinsWalletAccountName.
  ///
  /// In en, this message translates to:
  /// **'{name}\'s Account'**
  String coinsWalletAccountName(String name);

  /// No description provided for @coinsBalanceRefresh.
  ///
  /// In en, this message translates to:
  /// **'Refresh balance'**
  String get coinsBalanceRefresh;

  /// No description provided for @coinsBalanceFooterHint.
  ///
  /// In en, this message translates to:
  /// **'UPDATED ON OPEN'**
  String get coinsBalanceFooterHint;

  /// No description provided for @coinsBalanceFooter.
  ///
  /// In en, this message translates to:
  /// **'{date} | {hint}'**
  String coinsBalanceFooter(String date, String hint);

  /// No description provided for @coinsTabBuy.
  ///
  /// In en, this message translates to:
  /// **'Buy'**
  String get coinsTabBuy;

  /// No description provided for @coinsTabMarket.
  ///
  /// In en, this message translates to:
  /// **'Market'**
  String get coinsTabMarket;

  /// No description provided for @coinsTabVault.
  ///
  /// In en, this message translates to:
  /// **'Vault'**
  String get coinsTabVault;

  /// No description provided for @coinsUnit.
  ///
  /// In en, this message translates to:
  /// **'coins'**
  String get coinsUnit;

  /// No description provided for @coinsHistoryTitle.
  ///
  /// In en, this message translates to:
  /// **'Recent activity'**
  String get coinsHistoryTitle;

  /// No description provided for @coinsMarketSuccess.
  ///
  /// In en, this message translates to:
  /// **'Gift added to your vault!'**
  String get coinsMarketSuccess;

  /// No description provided for @coinsVaultEmpty.
  ///
  /// In en, this message translates to:
  /// **'No gifts in your vault yet. Visit the market to buy gifts with coins.'**
  String get coinsVaultEmpty;

  /// No description provided for @coinsVaultOwned.
  ///
  /// In en, this message translates to:
  /// **'In vault'**
  String get coinsVaultOwned;

  /// No description provided for @coinsInsufficientBalance.
  ///
  /// In en, this message translates to:
  /// **'Not enough coins. Buy more in the Buy tab.'**
  String get coinsInsufficientBalance;

  /// No description provided for @walletAccountingPurchase.
  ///
  /// In en, this message translates to:
  /// **'Bought coins'**
  String get walletAccountingPurchase;

  /// No description provided for @walletAccountingGiftPurchase.
  ///
  /// In en, this message translates to:
  /// **'Bought gift'**
  String get walletAccountingGiftPurchase;

  /// No description provided for @walletAccountingGiftReceived.
  ///
  /// In en, this message translates to:
  /// **'Received gift'**
  String get walletAccountingGiftReceived;

  /// No description provided for @walletAccountingPromotion.
  ///
  /// In en, this message translates to:
  /// **'Post promotion'**
  String get walletAccountingPromotion;

  /// No description provided for @walletAccountingAdmin.
  ///
  /// In en, this message translates to:
  /// **'Balance adjustment'**
  String get walletAccountingAdmin;

  /// No description provided for @balanceTitle.
  ///
  /// In en, this message translates to:
  /// **'Balance'**
  String get balanceTitle;

  /// No description provided for @balanceDefaultUserName.
  ///
  /// In en, this message translates to:
  /// **'User'**
  String get balanceDefaultUserName;

  /// No description provided for @balanceUserTitle.
  ///
  /// In en, this message translates to:
  /// **'{name}\'s balance'**
  String balanceUserTitle(String name);

  /// No description provided for @balanceEstimatedBalance.
  ///
  /// In en, this message translates to:
  /// **'Estimated balance'**
  String get balanceEstimatedBalance;

  /// No description provided for @balanceView.
  ///
  /// In en, this message translates to:
  /// **'View'**
  String get balanceView;

  /// No description provided for @balanceGet.
  ///
  /// In en, this message translates to:
  /// **'Get'**
  String get balanceGet;

  /// No description provided for @balanceScheduledPayouts.
  ///
  /// In en, this message translates to:
  /// **'Scheduled payouts'**
  String get balanceScheduledPayouts;

  /// No description provided for @balanceViewFullSchedule.
  ///
  /// In en, this message translates to:
  /// **'View full schedule >'**
  String get balanceViewFullSchedule;

  /// No description provided for @balanceSetupPaymentsBanner.
  ///
  /// In en, this message translates to:
  /// **'To receive payouts from Creator Rewards Program, set up payments.'**
  String get balanceSetupPaymentsBanner;

  /// No description provided for @balanceSetup.
  ///
  /// In en, this message translates to:
  /// **'Set up'**
  String get balanceSetup;

  /// No description provided for @balanceSetupRequired.
  ///
  /// In en, this message translates to:
  /// **'Setup required'**
  String get balanceSetupRequired;

  /// No description provided for @balancePastPayouts.
  ///
  /// In en, this message translates to:
  /// **'Past payouts >'**
  String get balancePastPayouts;

  /// No description provided for @balanceTransactions.
  ///
  /// In en, this message translates to:
  /// **'Transactions'**
  String get balanceTransactions;

  /// No description provided for @balanceTransactionPreview.
  ///
  /// In en, this message translates to:
  /// **'{title}: {amount} >'**
  String balanceTransactionPreview(String title, String amount);

  /// No description provided for @balanceFirstCoinOfferTitle.
  ///
  /// In en, this message translates to:
  /// **'First Coin purchase offer'**
  String get balanceFirstCoinOfferTitle;

  /// No description provided for @balanceFirstCoinOfferSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Get bonus Coins and a 99% off animated Gift from your first purchase'**
  String get balanceFirstCoinOfferSubtitle;

  /// No description provided for @balanceGetNow.
  ///
  /// In en, this message translates to:
  /// **'Get now →'**
  String get balanceGetNow;

  /// No description provided for @balanceMonetization.
  ///
  /// In en, this message translates to:
  /// **'Monetization'**
  String get balanceMonetization;

  /// No description provided for @balanceViewMore.
  ///
  /// In en, this message translates to:
  /// **'View more >'**
  String get balanceViewMore;

  /// No description provided for @balanceMonetizationLive.
  ///
  /// In en, this message translates to:
  /// **'LIVE'**
  String get balanceMonetizationLive;

  /// No description provided for @balanceMonetizationActivities.
  ///
  /// In en, this message translates to:
  /// **'Activities'**
  String get balanceMonetizationActivities;

  /// No description provided for @balanceServices.
  ///
  /// In en, this message translates to:
  /// **'Services'**
  String get balanceServices;

  /// No description provided for @balancePaymentMethods.
  ///
  /// In en, this message translates to:
  /// **'Payment methods'**
  String get balancePaymentMethods;

  /// No description provided for @balanceRequired.
  ///
  /// In en, this message translates to:
  /// **'Required'**
  String get balanceRequired;

  /// No description provided for @balanceTaxInformation.
  ///
  /// In en, this message translates to:
  /// **'Tax information'**
  String get balanceTaxInformation;

  /// No description provided for @balanceIdentityVerification.
  ///
  /// In en, this message translates to:
  /// **'Identity verification'**
  String get balanceIdentityVerification;

  /// No description provided for @balanceMonetizationCenter.
  ///
  /// In en, this message translates to:
  /// **'Monetization Center'**
  String get balanceMonetizationCenter;

  /// No description provided for @balanceExplore.
  ///
  /// In en, this message translates to:
  /// **'Explore >'**
  String get balanceExplore;

  /// No description provided for @balanceProgramCreatorRewards.
  ///
  /// In en, this message translates to:
  /// **'Creator Rewards Program'**
  String get balanceProgramCreatorRewards;

  /// No description provided for @balanceProgramTiktokGo.
  ///
  /// In en, this message translates to:
  /// **'TikTok GO rewards'**
  String get balanceProgramTiktokGo;

  /// No description provided for @balanceProgramSeries.
  ///
  /// In en, this message translates to:
  /// **'Series'**
  String get balanceProgramSeries;

  /// No description provided for @balanceSetupPaymentsTitle.
  ///
  /// In en, this message translates to:
  /// **'Set up payments'**
  String get balanceSetupPaymentsTitle;

  /// No description provided for @balanceSetupPaymentsMessage.
  ///
  /// In en, this message translates to:
  /// **'Ensure your information is accurate to receive payouts on time. You can change this at any time.'**
  String get balanceSetupPaymentsMessage;

  /// No description provided for @balancePayoutMethodTitle.
  ///
  /// In en, this message translates to:
  /// **'Payout method'**
  String get balancePayoutMethodTitle;

  /// No description provided for @balancePayoutMethodSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Select where to receive payouts.'**
  String get balancePayoutMethodSubtitle;

  /// No description provided for @balanceTaxInfoTitle.
  ///
  /// In en, this message translates to:
  /// **'Tax information'**
  String get balanceTaxInfoTitle;

  /// No description provided for @balanceTaxInfoSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Required for compliance purposes.'**
  String get balanceTaxInfoSubtitle;

  /// No description provided for @balanceIdentityTitle.
  ///
  /// In en, this message translates to:
  /// **'Identity verification'**
  String get balanceIdentityTitle;

  /// No description provided for @balanceIdentitySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Get your ID ready.'**
  String get balanceIdentitySubtitle;

  /// No description provided for @balanceAddPayoutMethod.
  ///
  /// In en, this message translates to:
  /// **'Add payout method'**
  String get balanceAddPayoutMethod;

  /// No description provided for @balanceCountryRegion.
  ///
  /// In en, this message translates to:
  /// **'Country / region'**
  String get balanceCountryRegion;

  /// No description provided for @balanceCountryRegionNote.
  ///
  /// In en, this message translates to:
  /// **'You can only register for one country or region. Make sure your selection is correct.'**
  String get balanceCountryRegionNote;

  /// No description provided for @balanceChoosePayoutMethod.
  ///
  /// In en, this message translates to:
  /// **'Choose payout method'**
  String get balanceChoosePayoutMethod;

  /// No description provided for @balancePayoutZaloPay.
  ///
  /// In en, this message translates to:
  /// **'ZaloPay (VND)'**
  String get balancePayoutZaloPay;

  /// No description provided for @balancePayoutZaloPayDetails.
  ///
  /// In en, this message translates to:
  /// **'Service fee 1.5% | Min. withdrawal 2 USD | Arrives in 1 business day'**
  String get balancePayoutZaloPayDetails;

  /// No description provided for @balancePayoutBank.
  ///
  /// In en, this message translates to:
  /// **'Bank transfer (VND)'**
  String get balancePayoutBank;

  /// No description provided for @balancePayoutBankDetails.
  ///
  /// In en, this message translates to:
  /// **'Service fee 2.9 USD | Min. withdrawal 8 USD | Arrives in 3-5 business days'**
  String get balancePayoutBankDetails;

  /// No description provided for @balancePayoutPayPal.
  ///
  /// In en, this message translates to:
  /// **'PayPal (USD)'**
  String get balancePayoutPayPal;

  /// No description provided for @balancePayoutPayPalDetails.
  ///
  /// In en, this message translates to:
  /// **'Service fee 1.5% + 0.1 USD | Min. withdrawal 1 USD | Arrives in 1 business day'**
  String get balancePayoutPayPalDetails;

  /// No description provided for @balanceTransactionHistory.
  ///
  /// In en, this message translates to:
  /// **'Transaction history'**
  String get balanceTransactionHistory;

  /// No description provided for @balanceTransactionDetails.
  ///
  /// In en, this message translates to:
  /// **'Transaction details'**
  String get balanceTransactionDetails;

  /// No description provided for @balanceTransactionNotFound.
  ///
  /// In en, this message translates to:
  /// **'Transaction not found'**
  String get balanceTransactionNotFound;

  /// No description provided for @balanceNoTransactions.
  ///
  /// In en, this message translates to:
  /// **'No transactions yet'**
  String get balanceNoTransactions;

  /// No description provided for @balanceTabAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get balanceTabAll;

  /// No description provided for @balanceTabRevenue.
  ///
  /// In en, this message translates to:
  /// **'Revenue'**
  String get balanceTabRevenue;

  /// No description provided for @balanceTabExpense.
  ///
  /// In en, this message translates to:
  /// **'Expense'**
  String get balanceTabExpense;

  /// No description provided for @balanceTabPayout.
  ///
  /// In en, this message translates to:
  /// **'Payout'**
  String get balanceTabPayout;

  /// No description provided for @balanceTabRefund.
  ///
  /// In en, this message translates to:
  /// **'Refund'**
  String get balanceTabRefund;

  /// No description provided for @balanceDetailStatus.
  ///
  /// In en, this message translates to:
  /// **'Status'**
  String get balanceDetailStatus;

  /// No description provided for @balanceStatusCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get balanceStatusCompleted;

  /// No description provided for @balanceDetailType.
  ///
  /// In en, this message translates to:
  /// **'Type'**
  String get balanceDetailType;

  /// No description provided for @balanceDetailActivityType.
  ///
  /// In en, this message translates to:
  /// **'Activity type'**
  String get balanceDetailActivityType;

  /// No description provided for @balanceDetailPaymentMethod.
  ///
  /// In en, this message translates to:
  /// **'Payment method'**
  String get balanceDetailPaymentMethod;

  /// No description provided for @balanceDetailCreated.
  ///
  /// In en, this message translates to:
  /// **'Created'**
  String get balanceDetailCreated;

  /// No description provided for @balanceDetailUpdated.
  ///
  /// In en, this message translates to:
  /// **'Updated'**
  String get balanceDetailUpdated;

  /// No description provided for @balanceDetailTransactionId.
  ///
  /// In en, this message translates to:
  /// **'Transaction ID'**
  String get balanceDetailTransactionId;

  /// No description provided for @balanceCopied.
  ///
  /// In en, this message translates to:
  /// **'Copied to clipboard'**
  String get balanceCopied;

  /// No description provided for @balanceNeedHelp.
  ///
  /// In en, this message translates to:
  /// **'Need help? >'**
  String get balanceNeedHelp;

  /// No description provided for @deleteChatTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete chat'**
  String get deleteChatTitle;

  /// No description provided for @deleteChatMessage.
  ///
  /// In en, this message translates to:
  /// **'Are you sure you want to delete this conversation? This action cannot be undone.'**
  String get deleteChatMessage;

  /// No description provided for @deleteChatConfirm.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get deleteChatConfirm;

  /// No description provided for @deleteForEveryone.
  ///
  /// In en, this message translates to:
  /// **'Delete for everyone'**
  String get deleteForEveryone;

  /// No description provided for @cameraFlip.
  ///
  /// In en, this message translates to:
  /// **'Flip'**
  String get cameraFlip;

  /// No description provided for @cameraFlash.
  ///
  /// In en, this message translates to:
  /// **'Flash'**
  String get cameraFlash;

  /// No description provided for @cameraSwitch.
  ///
  /// In en, this message translates to:
  /// **'Switch camera'**
  String get cameraSwitch;

  /// No description provided for @cameraSpeed.
  ///
  /// In en, this message translates to:
  /// **'Speed'**
  String get cameraSpeed;

  /// No description provided for @cameraBeauty.
  ///
  /// In en, this message translates to:
  /// **'Retouch'**
  String get cameraBeauty;

  /// No description provided for @cameraFilters.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get cameraFilters;

  /// No description provided for @cameraTimer.
  ///
  /// In en, this message translates to:
  /// **'Timer'**
  String get cameraTimer;

  /// No description provided for @cameraSetCountdown.
  ///
  /// In en, this message translates to:
  /// **'Set countdown'**
  String get cameraSetCountdown;

  /// No description provided for @cameraStartCountdown.
  ///
  /// In en, this message translates to:
  /// **'Start countdown'**
  String get cameraStartCountdown;

  /// No description provided for @cameraDragRecordingLimit.
  ///
  /// In en, this message translates to:
  /// **'Drag to set recording limit'**
  String get cameraDragRecordingLimit;

  /// No description provided for @cameraMusic.
  ///
  /// In en, this message translates to:
  /// **'Music'**
  String get cameraMusic;

  /// No description provided for @cameraEffects.
  ///
  /// In en, this message translates to:
  /// **'Effects'**
  String get cameraEffects;

  /// No description provided for @cameraUpload.
  ///
  /// In en, this message translates to:
  /// **'Upload from library'**
  String get cameraUpload;

  /// No description provided for @cameraOriginalSound.
  ///
  /// In en, this message translates to:
  /// **'Original Sound'**
  String get cameraOriginalSound;

  /// No description provided for @cameraSeconds.
  ///
  /// In en, this message translates to:
  /// **'seconds'**
  String get cameraSeconds;

  /// No description provided for @cameraRecording.
  ///
  /// In en, this message translates to:
  /// **'Recording'**
  String get cameraRecording;

  /// No description provided for @cameraMusicComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Music selection is coming soon.'**
  String get cameraMusicComingSoon;

  /// No description provided for @cameraPermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'Camera and microphone permissions are required to record.'**
  String get cameraPermissionDenied;

  /// No description provided for @cameraStarting.
  ///
  /// In en, this message translates to:
  /// **'Starting camera...'**
  String get cameraStarting;

  /// No description provided for @cameraOpenSettings.
  ///
  /// In en, this message translates to:
  /// **'Open settings'**
  String get cameraOpenSettings;

  /// No description provided for @cameraUnavailable.
  ///
  /// In en, this message translates to:
  /// **'No camera was found on this device.'**
  String get cameraUnavailable;

  /// No description provided for @cameraInitError.
  ///
  /// In en, this message translates to:
  /// **'Could not start the camera: {error}'**
  String cameraInitError(String error);

  /// No description provided for @cameraCaptureError.
  ///
  /// In en, this message translates to:
  /// **'Capture failed: {error}'**
  String cameraCaptureError(String error);

  /// No description provided for @cameraCategoryTrending.
  ///
  /// In en, this message translates to:
  /// **'Trending'**
  String get cameraCategoryTrending;

  /// No description provided for @cameraCategoryNew.
  ///
  /// In en, this message translates to:
  /// **'New'**
  String get cameraCategoryNew;

  /// No description provided for @cameraCategoryPortrait.
  ///
  /// In en, this message translates to:
  /// **'Portrait'**
  String get cameraCategoryPortrait;

  /// No description provided for @cameraCategoryVibe.
  ///
  /// In en, this message translates to:
  /// **'Vibe'**
  String get cameraCategoryVibe;

  /// No description provided for @cameraCategoryLandscape.
  ///
  /// In en, this message translates to:
  /// **'Landscape'**
  String get cameraCategoryLandscape;

  /// No description provided for @cameraFilterOriginal.
  ///
  /// In en, this message translates to:
  /// **'Original'**
  String get cameraFilterOriginal;

  /// No description provided for @cameraFilterWarm.
  ///
  /// In en, this message translates to:
  /// **'Warm'**
  String get cameraFilterWarm;

  /// No description provided for @cameraFilterCool.
  ///
  /// In en, this message translates to:
  /// **'Cool'**
  String get cameraFilterCool;

  /// No description provided for @cameraFilterSunny.
  ///
  /// In en, this message translates to:
  /// **'Sunny'**
  String get cameraFilterSunny;

  /// No description provided for @cameraFilterPink.
  ///
  /// In en, this message translates to:
  /// **'Pink'**
  String get cameraFilterPink;

  /// No description provided for @cameraFilterMoody.
  ///
  /// In en, this message translates to:
  /// **'Moody'**
  String get cameraFilterMoody;

  /// No description provided for @cameraFilterBw.
  ///
  /// In en, this message translates to:
  /// **'B&W'**
  String get cameraFilterBw;

  /// No description provided for @cameraFilterRetro.
  ///
  /// In en, this message translates to:
  /// **'Retro'**
  String get cameraFilterRetro;

  /// No description provided for @cameraFilterFlashVintage.
  ///
  /// In en, this message translates to:
  /// **'Flash'**
  String get cameraFilterFlashVintage;

  /// No description provided for @cameraFilterBeautyGlow.
  ///
  /// In en, this message translates to:
  /// **'Glow'**
  String get cameraFilterBeautyGlow;

  /// No description provided for @cameraFilterNaturalBright.
  ///
  /// In en, this message translates to:
  /// **'Natural'**
  String get cameraFilterNaturalBright;

  /// No description provided for @cameraFilterGoldenHour.
  ///
  /// In en, this message translates to:
  /// **'Golden'**
  String get cameraFilterGoldenHour;

  /// No description provided for @openCameraStudio.
  ///
  /// In en, this message translates to:
  /// **'Open camera'**
  String get openCameraStudio;

  /// No description provided for @cameraModePhoto.
  ///
  /// In en, this message translates to:
  /// **'PHOTO'**
  String get cameraModePhoto;

  /// No description provided for @cameraModeVideo.
  ///
  /// In en, this message translates to:
  /// **'Video'**
  String get cameraModeVideo;

  /// No description provided for @cameraModeLive.
  ///
  /// In en, this message translates to:
  /// **'LIVE'**
  String get cameraModeLive;

  /// No description provided for @cameraModeText.
  ///
  /// In en, this message translates to:
  /// **'TEXT'**
  String get cameraModeText;

  /// No description provided for @cameraAddSound.
  ///
  /// In en, this message translates to:
  /// **'Add sound'**
  String get cameraAddSound;

  /// No description provided for @cameraMuteOriginalSound.
  ///
  /// In en, this message translates to:
  /// **'Mute original sound'**
  String get cameraMuteOriginalSound;

  /// No description provided for @cameraLayout.
  ///
  /// In en, this message translates to:
  /// **'Layout'**
  String get cameraLayout;

  /// No description provided for @cameraAspectRatio.
  ///
  /// In en, this message translates to:
  /// **'Ratio'**
  String get cameraAspectRatio;

  /// No description provided for @cameraTabPost.
  ///
  /// In en, this message translates to:
  /// **'Post'**
  String get cameraTabPost;

  /// No description provided for @cameraTabCreative.
  ///
  /// In en, this message translates to:
  /// **'Create'**
  String get cameraTabCreative;

  /// No description provided for @cameraDuration10m.
  ///
  /// In en, this message translates to:
  /// **'10m'**
  String get cameraDuration10m;

  /// No description provided for @cameraZoom.
  ///
  /// In en, this message translates to:
  /// **'Zoom'**
  String get cameraZoom;

  /// No description provided for @cameraZoomOut.
  ///
  /// In en, this message translates to:
  /// **'Zoom out'**
  String get cameraZoomOut;

  /// No description provided for @cameraZoomIn.
  ///
  /// In en, this message translates to:
  /// **'Zoom in'**
  String get cameraZoomIn;

  /// No description provided for @cameraGoLive.
  ///
  /// In en, this message translates to:
  /// **'Go LIVE'**
  String get cameraGoLive;

  /// No description provided for @cameraLiveTitleHint.
  ///
  /// In en, this message translates to:
  /// **'Add a title'**
  String get cameraLiveTitleHint;

  /// No description provided for @cameraLiveComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Live streaming is coming soon.'**
  String get cameraLiveComingSoon;

  /// No description provided for @cameraEffectCrown.
  ///
  /// In en, this message translates to:
  /// **'Crown'**
  String get cameraEffectCrown;

  /// No description provided for @cameraEffectBunny.
  ///
  /// In en, this message translates to:
  /// **'Bunny'**
  String get cameraEffectBunny;

  /// No description provided for @cameraEffectSunglasses.
  ///
  /// In en, this message translates to:
  /// **'Shades'**
  String get cameraEffectSunglasses;

  /// No description provided for @cameraEffectDog.
  ///
  /// In en, this message translates to:
  /// **'Dog'**
  String get cameraEffectDog;

  /// No description provided for @cameraEffectHearts.
  ///
  /// In en, this message translates to:
  /// **'Hearts'**
  String get cameraEffectHearts;

  /// No description provided for @cameraEffectSparkle.
  ///
  /// In en, this message translates to:
  /// **'Sparkle'**
  String get cameraEffectSparkle;

  /// No description provided for @cameraEffectNeon.
  ///
  /// In en, this message translates to:
  /// **'Neon'**
  String get cameraEffectNeon;

  /// No description provided for @cameraEffectGlitch.
  ///
  /// In en, this message translates to:
  /// **'Glitch'**
  String get cameraEffectGlitch;

  /// No description provided for @cameraEffectGlasses.
  ///
  /// In en, this message translates to:
  /// **'Glasses'**
  String get cameraEffectGlasses;

  /// No description provided for @cameraEffectMoustache.
  ///
  /// In en, this message translates to:
  /// **'Moustache'**
  String get cameraEffectMoustache;

  /// No description provided for @cameraEffectBigEyes.
  ///
  /// In en, this message translates to:
  /// **'Big Eyes'**
  String get cameraEffectBigEyes;

  /// No description provided for @cameraEffectBigLips.
  ///
  /// In en, this message translates to:
  /// **'Big Lips'**
  String get cameraEffectBigLips;

  /// No description provided for @cameraEffectNose.
  ///
  /// In en, this message translates to:
  /// **'Nose'**
  String get cameraEffectNose;

  /// No description provided for @cameraFilterPure.
  ///
  /// In en, this message translates to:
  /// **'Pure'**
  String get cameraFilterPure;

  /// No description provided for @cameraFilterBright.
  ///
  /// In en, this message translates to:
  /// **'Bright'**
  String get cameraFilterBright;

  /// No description provided for @cameraFilterClean.
  ///
  /// In en, this message translates to:
  /// **'Clean'**
  String get cameraFilterClean;

  /// No description provided for @cameraFilterSoft.
  ///
  /// In en, this message translates to:
  /// **'Soft'**
  String get cameraFilterSoft;

  /// No description provided for @cameraFilterSunset.
  ///
  /// In en, this message translates to:
  /// **'Sunset'**
  String get cameraFilterSunset;

  /// No description provided for @cameraCategoryLife.
  ///
  /// In en, this message translates to:
  /// **'Life'**
  String get cameraCategoryLife;

  /// No description provided for @mediaEditorShare.
  ///
  /// In en, this message translates to:
  /// **'Share'**
  String get mediaEditorShare;

  /// No description provided for @mediaEditorText.
  ///
  /// In en, this message translates to:
  /// **'Text'**
  String get mediaEditorText;

  /// No description provided for @mediaEditorStickers.
  ///
  /// In en, this message translates to:
  /// **'Stickers'**
  String get mediaEditorStickers;

  /// No description provided for @mediaEditorCrop.
  ///
  /// In en, this message translates to:
  /// **'Crop'**
  String get mediaEditorCrop;

  /// No description provided for @mediaEditorEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get mediaEditorEdit;

  /// No description provided for @mediaEditorMore.
  ///
  /// In en, this message translates to:
  /// **'More'**
  String get mediaEditorMore;

  /// No description provided for @mediaEditorComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Coming soon'**
  String get mediaEditorComingSoon;

  /// No description provided for @mediaEditorDone.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get mediaEditorDone;

  /// No description provided for @mediaEditorTrim.
  ///
  /// In en, this message translates to:
  /// **'Trim'**
  String get mediaEditorTrim;

  /// No description provided for @videoEditorSplit.
  ///
  /// In en, this message translates to:
  /// **'Split'**
  String get videoEditorSplit;

  /// No description provided for @videoEditorDeleteSegment.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get videoEditorDeleteSegment;

  /// No description provided for @mediaEditorReset.
  ///
  /// In en, this message translates to:
  /// **'Reset'**
  String get mediaEditorReset;

  /// No description provided for @mediaEditorDiscard.
  ///
  /// In en, this message translates to:
  /// **'Discard'**
  String get mediaEditorDiscard;

  /// No description provided for @mediaEditorSaveDraft.
  ///
  /// In en, this message translates to:
  /// **'Save draft'**
  String get mediaEditorSaveDraft;

  /// No description provided for @mediaEditorContinueEditing.
  ///
  /// In en, this message translates to:
  /// **'Continue editing'**
  String get mediaEditorContinueEditing;

  /// No description provided for @mediaEditorSendToFriends.
  ///
  /// In en, this message translates to:
  /// **'Send to friends'**
  String get mediaEditorSendToFriends;

  /// No description provided for @mediaEditorDiscardTitle.
  ///
  /// In en, this message translates to:
  /// **'Discard changes?'**
  String get mediaEditorDiscardTitle;

  /// No description provided for @mediaPhotoEditorFace.
  ///
  /// In en, this message translates to:
  /// **'Beauty'**
  String get mediaPhotoEditorFace;

  /// No description provided for @mediaPhotoEditorMakeup.
  ///
  /// In en, this message translates to:
  /// **'Makeup'**
  String get mediaPhotoEditorMakeup;

  /// No description provided for @mediaPhotoEditorLipstick.
  ///
  /// In en, this message translates to:
  /// **'Lipstick'**
  String get mediaPhotoEditorLipstick;

  /// No description provided for @mediaPhotoEditorBlush.
  ///
  /// In en, this message translates to:
  /// **'Blush'**
  String get mediaPhotoEditorBlush;

  /// No description provided for @mediaPhotoEditorEyeliner.
  ///
  /// In en, this message translates to:
  /// **'Eyeliner'**
  String get mediaPhotoEditorEyeliner;

  /// No description provided for @mediaPhotoEditorEyeshadow.
  ///
  /// In en, this message translates to:
  /// **'Shadow'**
  String get mediaPhotoEditorEyeshadow;

  /// No description provided for @mediaPhotoEditorFoundation.
  ///
  /// In en, this message translates to:
  /// **'Foundation'**
  String get mediaPhotoEditorFoundation;

  /// No description provided for @mediaPhotoEditorContour.
  ///
  /// In en, this message translates to:
  /// **'Contour'**
  String get mediaPhotoEditorContour;

  /// No description provided for @mediaPhotoEditorUnderEye.
  ///
  /// In en, this message translates to:
  /// **'Under-eye'**
  String get mediaPhotoEditorUnderEye;

  /// No description provided for @mediaPhotoEditorBrightenEye.
  ///
  /// In en, this message translates to:
  /// **'Brighten eye'**
  String get mediaPhotoEditorBrightenEye;

  /// No description provided for @mediaPhotoEditorMagic.
  ///
  /// In en, this message translates to:
  /// **'Magic'**
  String get mediaPhotoEditorMagic;

  /// No description provided for @mediaPhotoEditorOff.
  ///
  /// In en, this message translates to:
  /// **'Off'**
  String get mediaPhotoEditorOff;

  /// No description provided for @mediaPhotoEditorSmooth.
  ///
  /// In en, this message translates to:
  /// **'Smooth'**
  String get mediaPhotoEditorSmooth;

  /// No description provided for @mediaPhotoEditorSaturation.
  ///
  /// In en, this message translates to:
  /// **'Saturation'**
  String get mediaPhotoEditorSaturation;

  /// No description provided for @mediaPhotoEditorBrightness.
  ///
  /// In en, this message translates to:
  /// **'Brightness'**
  String get mediaPhotoEditorBrightness;

  /// No description provided for @mediaPhotoEditorContrast.
  ///
  /// In en, this message translates to:
  /// **'Contrast'**
  String get mediaPhotoEditorContrast;

  /// No description provided for @mediaPhotoEditorShape.
  ///
  /// In en, this message translates to:
  /// **'Shape'**
  String get mediaPhotoEditorShape;

  /// No description provided for @mediaPhotoEditorEyes.
  ///
  /// In en, this message translates to:
  /// **'Eyes'**
  String get mediaPhotoEditorEyes;

  /// No description provided for @mediaPhotoEditorTooth.
  ///
  /// In en, this message translates to:
  /// **'Tooth'**
  String get mediaPhotoEditorTooth;

  /// No description provided for @mediaPhotoEditorMouth.
  ///
  /// In en, this message translates to:
  /// **'Mouth'**
  String get mediaPhotoEditorMouth;

  /// No description provided for @mediaPhotoEditorExposure.
  ///
  /// In en, this message translates to:
  /// **'Exposure'**
  String get mediaPhotoEditorExposure;

  /// No description provided for @mediaPhotoEditorWhiteBalance.
  ///
  /// In en, this message translates to:
  /// **'Warmth'**
  String get mediaPhotoEditorWhiteBalance;

  /// No description provided for @mediaPhotoEditorHighlights.
  ///
  /// In en, this message translates to:
  /// **'Highlights'**
  String get mediaPhotoEditorHighlights;

  /// No description provided for @mediaPhotoEditorShadows.
  ///
  /// In en, this message translates to:
  /// **'Shadows'**
  String get mediaPhotoEditorShadows;

  /// No description provided for @mediaPhotoEditorNose.
  ///
  /// In en, this message translates to:
  /// **'Nose'**
  String get mediaPhotoEditorNose;

  /// No description provided for @mediaPhotoEditorOn.
  ///
  /// In en, this message translates to:
  /// **'On'**
  String get mediaPhotoEditorOn;

  /// No description provided for @mediaTextHint.
  ///
  /// In en, this message translates to:
  /// **'Type something'**
  String get mediaTextHint;

  /// No description provided for @promotePostTitle.
  ///
  /// In en, this message translates to:
  /// **'Promote post'**
  String get promotePostTitle;

  /// No description provided for @promotionScreenTitle.
  ///
  /// In en, this message translates to:
  /// **'Promotion'**
  String get promotionScreenTitle;

  /// No description provided for @promotePostAction.
  ///
  /// In en, this message translates to:
  /// **'Promote'**
  String get promotePostAction;

  /// No description provided for @promoteGoalTitle.
  ///
  /// In en, this message translates to:
  /// **'Choose your goal'**
  String get promoteGoalTitle;

  /// No description provided for @promoteAudienceTitle.
  ///
  /// In en, this message translates to:
  /// **'Define your audience'**
  String get promoteAudienceTitle;

  /// No description provided for @promoteAgeRange.
  ///
  /// In en, this message translates to:
  /// **'Age range'**
  String get promoteAgeRange;

  /// No description provided for @promoteGeoTarget.
  ///
  /// In en, this message translates to:
  /// **'Target people nearby'**
  String get promoteGeoTarget;

  /// No description provided for @promoteGeoTargetHint.
  ///
  /// In en, this message translates to:
  /// **'Use your current location for local reach'**
  String get promoteGeoTargetHint;

  /// No description provided for @promoteGeoMapHint.
  ///
  /// In en, this message translates to:
  /// **'Tap the map to choose your target area. Default is your location.'**
  String get promoteGeoMapHint;

  /// No description provided for @promoteGeoUseMyLocation.
  ///
  /// In en, this message translates to:
  /// **'Use my location'**
  String get promoteGeoUseMyLocation;

  /// No description provided for @promoteGeoPlaceLoading.
  ///
  /// In en, this message translates to:
  /// **'Looking up place…'**
  String get promoteGeoPlaceLoading;

  /// No description provided for @promoteGeoCity.
  ///
  /// In en, this message translates to:
  /// **'City'**
  String get promoteGeoCity;

  /// No description provided for @promoteGeoRegion.
  ///
  /// In en, this message translates to:
  /// **'Region'**
  String get promoteGeoRegion;

  /// No description provided for @promoteGeoTown.
  ///
  /// In en, this message translates to:
  /// **'Town'**
  String get promoteGeoTown;

  /// No description provided for @promoteGeoCountry.
  ///
  /// In en, this message translates to:
  /// **'Country'**
  String get promoteGeoCountry;

  /// No description provided for @promoteGeoContinent.
  ///
  /// In en, this message translates to:
  /// **'Continent'**
  String get promoteGeoContinent;

  /// No description provided for @promoteBudgetTitle.
  ///
  /// In en, this message translates to:
  /// **'Select budget'**
  String get promoteBudgetTitle;

  /// No description provided for @promoteProcessing.
  ///
  /// In en, this message translates to:
  /// **'Processing...'**
  String get promoteProcessing;

  /// No description provided for @promotePostCta.
  ///
  /// In en, this message translates to:
  /// **'Promote for {price}'**
  String promotePostCta(String price);

  /// No description provided for @promotePostSuccess.
  ///
  /// In en, this message translates to:
  /// **'Promotion started! Wallet balance: {balance}'**
  String promotePostSuccess(String balance);

  /// No description provided for @promotedBadge.
  ///
  /// In en, this message translates to:
  /// **'Promoted'**
  String get promotedBadge;

  /// No description provided for @promoteLanguages.
  ///
  /// In en, this message translates to:
  /// **'Languages'**
  String get promoteLanguages;

  /// No description provided for @promoteInterests.
  ///
  /// In en, this message translates to:
  /// **'Interests'**
  String get promoteInterests;

  /// No description provided for @promoteRadiusKm.
  ///
  /// In en, this message translates to:
  /// **'Radius: {km} km'**
  String promoteRadiusKm(int km);

  /// No description provided for @promotePayFailedTitle.
  ///
  /// In en, this message translates to:
  /// **'Payment failed'**
  String get promotePayFailedTitle;

  /// No description provided for @promoteRetryPay.
  ///
  /// In en, this message translates to:
  /// **'Retry payment'**
  String get promoteRetryPay;

  /// No description provided for @promoteAudienceCustomize.
  ///
  /// In en, this message translates to:
  /// **'Customize audience'**
  String get promoteAudienceCustomize;

  /// No description provided for @promoteAudienceAllGenders.
  ///
  /// In en, this message translates to:
  /// **'All genders'**
  String get promoteAudienceAllGenders;

  /// No description provided for @promoteAudienceNearby.
  ///
  /// In en, this message translates to:
  /// **'Nearby'**
  String get promoteAudienceNearby;

  /// No description provided for @promoteAudienceGender.
  ///
  /// In en, this message translates to:
  /// **'Gender'**
  String get promoteAudienceGender;

  /// No description provided for @promotePostNoCaption.
  ///
  /// In en, this message translates to:
  /// **'No caption'**
  String get promotePostNoCaption;

  /// No description provided for @promotePopularBadge.
  ///
  /// In en, this message translates to:
  /// **'POPULAR'**
  String get promotePopularBadge;

  /// No description provided for @promoteImpressions.
  ///
  /// In en, this message translates to:
  /// **'{count} impressions'**
  String promoteImpressions(int count);

  /// No description provided for @promoteStepGoalHeading.
  ///
  /// In en, this message translates to:
  /// **'What is your goal?'**
  String get promoteStepGoalHeading;

  /// No description provided for @promoteStepGoalSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Choose a goal for promoting this video.'**
  String get promoteStepGoalSubtitle;

  /// No description provided for @promoteStepAudienceSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Select how you want to reach your audience for your promotion.'**
  String get promoteStepAudienceSubtitle;

  /// No description provided for @promoteAudienceDefault.
  ///
  /// In en, this message translates to:
  /// **'Default audience'**
  String get promoteAudienceDefault;

  /// No description provided for @promoteAudienceDefaultHint.
  ///
  /// In en, this message translates to:
  /// **'We\'ll choose the best audience for you'**
  String get promoteAudienceDefaultHint;

  /// No description provided for @promoteAudienceCreateOwn.
  ///
  /// In en, this message translates to:
  /// **'Create your own'**
  String get promoteAudienceCreateOwn;

  /// No description provided for @promoteStepLocationHeading.
  ///
  /// In en, this message translates to:
  /// **'Choose your target area'**
  String get promoteStepLocationHeading;

  /// No description provided for @promoteStepLocationSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Detect your location and set a radius to reach people nearby.'**
  String get promoteStepLocationSubtitle;

  /// No description provided for @promoteStepBudgetSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Choose a promotion package for your campaign.'**
  String get promoteStepBudgetSubtitle;

  /// No description provided for @promoteBudgetTotal.
  ///
  /// In en, this message translates to:
  /// **'{price} total'**
  String promoteBudgetTotal(String price);

  /// No description provided for @promoteEstimatedViews.
  ///
  /// In en, this message translates to:
  /// **'{min} – {max}'**
  String promoteEstimatedViews(String min, String max);

  /// No description provided for @promoteEstimatedViewsLabel.
  ///
  /// In en, this message translates to:
  /// **'Estimated video views'**
  String get promoteEstimatedViewsLabel;

  /// No description provided for @promoteOverviewTitle.
  ///
  /// In en, this message translates to:
  /// **'Overview'**
  String get promoteOverviewTitle;

  /// No description provided for @promoteOverviewGoal.
  ///
  /// In en, this message translates to:
  /// **'Goal'**
  String get promoteOverviewGoal;

  /// No description provided for @promoteOverviewAudience.
  ///
  /// In en, this message translates to:
  /// **'Audience'**
  String get promoteOverviewAudience;

  /// No description provided for @promoteOverviewLocation.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get promoteOverviewLocation;

  /// No description provided for @promoteOverviewBudget.
  ///
  /// In en, this message translates to:
  /// **'Budget'**
  String get promoteOverviewBudget;

  /// No description provided for @promoteLocationOff.
  ///
  /// In en, this message translates to:
  /// **'Location targeting off'**
  String get promoteLocationOff;

  /// No description provided for @promoteLocationPending.
  ///
  /// In en, this message translates to:
  /// **'Location not set'**
  String get promoteLocationPending;

  /// No description provided for @promoteAudienceNearbyWithRadius.
  ///
  /// In en, this message translates to:
  /// **'Nearby · {km} km'**
  String promoteAudienceNearbyWithRadius(int km);

  /// No description provided for @promoteLocationModeRegional.
  ///
  /// In en, this message translates to:
  /// **'Regionally'**
  String get promoteLocationModeRegional;

  /// No description provided for @promoteLocationModeRegionalHint.
  ///
  /// In en, this message translates to:
  /// **'Choose country, region, and town'**
  String get promoteLocationModeRegionalHint;

  /// No description provided for @promoteLocationModeMap.
  ///
  /// In en, this message translates to:
  /// **'On map'**
  String get promoteLocationModeMap;

  /// No description provided for @promoteLocationModeMapHint.
  ///
  /// In en, this message translates to:
  /// **'Detect GPS and pick a radius on the map'**
  String get promoteLocationModeMapHint;

  /// No description provided for @promoteSelectCountry.
  ///
  /// In en, this message translates to:
  /// **'Country'**
  String get promoteSelectCountry;

  /// No description provided for @promoteSelectCountryHint.
  ///
  /// In en, this message translates to:
  /// **'Select country'**
  String get promoteSelectCountryHint;

  /// No description provided for @promoteSelectRegion.
  ///
  /// In en, this message translates to:
  /// **'Region'**
  String get promoteSelectRegion;

  /// No description provided for @promoteSelectRegionHint.
  ///
  /// In en, this message translates to:
  /// **'Select region'**
  String get promoteSelectRegionHint;

  /// No description provided for @promoteSelectTown.
  ///
  /// In en, this message translates to:
  /// **'Town'**
  String get promoteSelectTown;

  /// No description provided for @promoteSelectTownHint.
  ///
  /// In en, this message translates to:
  /// **'Select town'**
  String get promoteSelectTownHint;

  /// No description provided for @promoteLocationRegionalSummary.
  ///
  /// In en, this message translates to:
  /// **'{town} · {region} · {country}'**
  String promoteLocationRegionalSummary(String town, String region, String country);

  /// No description provided for @promoteLocationCountryRequired.
  ///
  /// In en, this message translates to:
  /// **'Please select a country.'**
  String get promoteLocationCountryRequired;

  /// No description provided for @promoteLocationRegionRequired.
  ///
  /// In en, this message translates to:
  /// **'Please select a region.'**
  String get promoteLocationRegionRequired;

  /// No description provided for @promoteLocationTownRequired.
  ///
  /// In en, this message translates to:
  /// **'Please select a town.'**
  String get promoteLocationTownRequired;

  /// No description provided for @promoteLocationTownCoordinatesRequired.
  ///
  /// In en, this message translates to:
  /// **'This town has no coordinates. Please choose another town.'**
  String get promoteLocationTownCoordinatesRequired;

  /// No description provided for @promoteLocationMapRequired.
  ///
  /// In en, this message translates to:
  /// **'Please allow location or pick a point on the map.'**
  String get promoteLocationMapRequired;

  /// No description provided for @promoteOverviewSubtotal.
  ///
  /// In en, this message translates to:
  /// **'Subtotal'**
  String get promoteOverviewSubtotal;

  /// No description provided for @promoteOverviewTotal.
  ///
  /// In en, this message translates to:
  /// **'Total'**
  String get promoteOverviewTotal;

  /// No description provided for @promoteNext.
  ///
  /// In en, this message translates to:
  /// **'Next'**
  String get promoteNext;

  /// No description provided for @promotePayStart.
  ///
  /// In en, this message translates to:
  /// **'Pay and start promotion'**
  String get promotePayStart;

  /// No description provided for @promoteQuickPack.
  ///
  /// In en, this message translates to:
  /// **'Ready-to-use promotion pack'**
  String get promoteQuickPack;

  /// No description provided for @promoteStepOf.
  ///
  /// In en, this message translates to:
  /// **'Step {current} of {total}'**
  String promoteStepOf(int current, int total);

  /// No description provided for @promoteInsightsDashboardTitle.
  ///
  /// In en, this message translates to:
  /// **'Promoted posts'**
  String get promoteInsightsDashboardTitle;

  /// No description provided for @promoteInsightsTitle.
  ///
  /// In en, this message translates to:
  /// **'Promotion insights'**
  String get promoteInsightsTitle;

  /// No description provided for @promoteInsightsEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No promoted posts yet'**
  String get promoteInsightsEmptyTitle;

  /// No description provided for @promoteInsightsEmptyHint.
  ///
  /// In en, this message translates to:
  /// **'Promote a video from your feed to see performance here.'**
  String get promoteInsightsEmptyHint;

  /// No description provided for @promoteInsightsPerformanceTitle.
  ///
  /// In en, this message translates to:
  /// **'Performance'**
  String get promoteInsightsPerformanceTitle;

  /// No description provided for @promoteInsightsPromotedImpressions.
  ///
  /// In en, this message translates to:
  /// **'Promoted impressions'**
  String get promoteInsightsPromotedImpressions;

  /// No description provided for @promoteInsightsFollowersGained.
  ///
  /// In en, this message translates to:
  /// **'Followers gained'**
  String get promoteInsightsFollowersGained;

  /// No description provided for @promoteInsightsSpend.
  ///
  /// In en, this message translates to:
  /// **'Promotion spend'**
  String get promoteInsightsSpend;

  /// No description provided for @promoteInsightsEngagementRate.
  ///
  /// In en, this message translates to:
  /// **'Engagement rate'**
  String get promoteInsightsEngagementRate;

  /// No description provided for @promoteInsightsShares.
  ///
  /// In en, this message translates to:
  /// **'Shares'**
  String get promoteInsightsShares;

  /// No description provided for @promoteInsightsCostPerImpression.
  ///
  /// In en, this message translates to:
  /// **'Cost / impression'**
  String get promoteInsightsCostPerImpression;

  /// No description provided for @promoteInsightsCostPerView.
  ///
  /// In en, this message translates to:
  /// **'Cost / view'**
  String get promoteInsightsCostPerView;

  /// No description provided for @promoteInsightsUniqueViewers.
  ///
  /// In en, this message translates to:
  /// **'Unique viewers'**
  String get promoteInsightsUniqueViewers;

  /// No description provided for @promoteInsightsChartTitle.
  ///
  /// In en, this message translates to:
  /// **'Impressions (last 7 days)'**
  String get promoteInsightsChartTitle;

  /// No description provided for @promoteInsightsNoChartData.
  ///
  /// In en, this message translates to:
  /// **'No impression data yet'**
  String get promoteInsightsNoChartData;

  /// No description provided for @promoteInsightsCampaignProgress.
  ///
  /// In en, this message translates to:
  /// **'Campaign progress'**
  String get promoteInsightsCampaignProgress;

  /// No description provided for @promoteInsightsImpressions.
  ///
  /// In en, this message translates to:
  /// **'Impressions'**
  String get promoteInsightsImpressions;

  /// No description provided for @promoteInsightsBudget.
  ///
  /// In en, this message translates to:
  /// **'Budget'**
  String get promoteInsightsBudget;

  /// No description provided for @promoteInsightsPauseCampaign.
  ///
  /// In en, this message translates to:
  /// **'Pause campaign'**
  String get promoteInsightsPauseCampaign;

  /// No description provided for @promoteInsightsResumeCampaign.
  ///
  /// In en, this message translates to:
  /// **'Resume campaign'**
  String get promoteInsightsResumeCampaign;

  /// No description provided for @promoteInsightsCampaignHistory.
  ///
  /// In en, this message translates to:
  /// **'Campaign history'**
  String get promoteInsightsCampaignHistory;

  /// No description provided for @promoteInsightsCampaignHistoryHint.
  ///
  /// In en, this message translates to:
  /// **'Tap a campaign to filter stats'**
  String get promoteInsightsCampaignHistoryHint;

  /// No description provided for @promoteInsightsAllCampaigns.
  ///
  /// In en, this message translates to:
  /// **'All campaigns'**
  String get promoteInsightsAllCampaigns;

  /// No description provided for @promoteInsightsMultipleCampaigns.
  ///
  /// In en, this message translates to:
  /// **'Multiple campaigns'**
  String get promoteInsightsMultipleCampaigns;

  /// No description provided for @promoteInsightsViewInsights.
  ///
  /// In en, this message translates to:
  /// **'View insights'**
  String get promoteInsightsViewInsights;

  /// No description provided for @promoteInsightsObjectiveViews.
  ///
  /// In en, this message translates to:
  /// **'Video views'**
  String get promoteInsightsObjectiveViews;

  /// No description provided for @promoteInsightsObjectiveFollowers.
  ///
  /// In en, this message translates to:
  /// **'Followers'**
  String get promoteInsightsObjectiveFollowers;

  /// No description provided for @promoteInsightsObjectiveEngagement.
  ///
  /// In en, this message translates to:
  /// **'Engagement'**
  String get promoteInsightsObjectiveEngagement;

  /// No description provided for @promoteInsightsObjectiveChallenges.
  ///
  /// In en, this message translates to:
  /// **'Challenges'**
  String get promoteInsightsObjectiveChallenges;

  /// No description provided for @promoteInsightsObjectiveProfileVisits.
  ///
  /// In en, this message translates to:
  /// **'Profile visits'**
  String get promoteInsightsObjectiveProfileVisits;

  /// No description provided for @promoteInsightsObjectiveSales.
  ///
  /// In en, this message translates to:
  /// **'Sales'**
  String get promoteInsightsObjectiveSales;

  /// No description provided for @promoteInsightsStatusActive.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get promoteInsightsStatusActive;

  /// No description provided for @promoteInsightsStatusPaused.
  ///
  /// In en, this message translates to:
  /// **'Paused'**
  String get promoteInsightsStatusPaused;

  /// No description provided for @promoteInsightsStatusPendingPayment.
  ///
  /// In en, this message translates to:
  /// **'Pending payment'**
  String get promoteInsightsStatusPendingPayment;

  /// No description provided for @promoteInsightsStatusCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get promoteInsightsStatusCompleted;

  /// No description provided for @promoteInsightsStatusCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get promoteInsightsStatusCancelled;

  /// No description provided for @promoteInsightsCampaignProgressSummary.
  ///
  /// In en, this message translates to:
  /// **'{percent} · {spent} spent'**
  String promoteInsightsCampaignProgressSummary(String percent, String spent);

  /// No description provided for @settingsPromotedPosts.
  ///
  /// In en, this message translates to:
  /// **'Promoted posts'**
  String get settingsPromotedPosts;

  /// No description provided for @soundLabel.
  ///
  /// In en, this message translates to:
  /// **'Sound'**
  String get soundLabel;

  /// No description provided for @soundNoneSelected.
  ///
  /// In en, this message translates to:
  /// **'None'**
  String get soundNoneSelected;

  /// No description provided for @soundPickerTitle.
  ///
  /// In en, this message translates to:
  /// **'Add sound'**
  String get soundPickerTitle;

  /// No description provided for @soundSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search sounds'**
  String get soundSearchHint;

  /// No description provided for @soundTabTrending.
  ///
  /// In en, this message translates to:
  /// **'Trending'**
  String get soundTabTrending;

  /// No description provided for @soundTabBrowse.
  ///
  /// In en, this message translates to:
  /// **'Browse'**
  String get soundTabBrowse;

  /// No description provided for @soundTabMine.
  ///
  /// In en, this message translates to:
  /// **'My sounds'**
  String get soundTabMine;

  /// No description provided for @soundTabHot.
  ///
  /// In en, this message translates to:
  /// **'Hot'**
  String get soundTabHot;

  /// No description provided for @soundTabForYou.
  ///
  /// In en, this message translates to:
  /// **'For You'**
  String get soundTabForYou;

  /// No description provided for @soundTabFavorites.
  ///
  /// In en, this message translates to:
  /// **'Favorites'**
  String get soundTabFavorites;

  /// No description provided for @soundTabRecent.
  ///
  /// In en, this message translates to:
  /// **'Recent'**
  String get soundTabRecent;

  /// No description provided for @soundTabAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get soundTabAll;

  /// No description provided for @soundPickerEmpty.
  ///
  /// In en, this message translates to:
  /// **'No sounds found'**
  String get soundPickerEmpty;

  /// No description provided for @soundPickFromFiles.
  ///
  /// In en, this message translates to:
  /// **'Pick from files'**
  String get soundPickFromFiles;

  /// No description provided for @soundTrimTooltip.
  ///
  /// In en, this message translates to:
  /// **'Trim'**
  String get soundTrimTooltip;

  /// No description provided for @soundFavoriteTooltip.
  ///
  /// In en, this message translates to:
  /// **'Favorite'**
  String get soundFavoriteTooltip;

  /// No description provided for @soundSecondsSelected.
  ///
  /// In en, this message translates to:
  /// **'{count}s selected'**
  String soundSecondsSelected(int count);

  /// No description provided for @soundUseThis.
  ///
  /// In en, this message translates to:
  /// **'Use'**
  String get soundUseThis;

  /// No description provided for @soundUseThisSound.
  ///
  /// In en, this message translates to:
  /// **'Use this sound'**
  String get soundUseThisSound;

  /// No description provided for @soundUseSoundCta.
  ///
  /// In en, this message translates to:
  /// **'Use sound'**
  String get soundUseSoundCta;

  /// No description provided for @soundSave.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get soundSave;

  /// No description provided for @soundSaved.
  ///
  /// In en, this message translates to:
  /// **'Saved'**
  String get soundSaved;

  /// No description provided for @soundAddToStory.
  ///
  /// In en, this message translates to:
  /// **'Add to Story'**
  String get soundAddToStory;

  /// No description provided for @soundFindRelatedHint.
  ///
  /// In en, this message translates to:
  /// **'Find related content'**
  String get soundFindRelatedHint;

  /// No description provided for @soundOriginalBadge.
  ///
  /// In en, this message translates to:
  /// **'Original'**
  String get soundOriginalBadge;

  /// No description provided for @soundConfirmSelection.
  ///
  /// In en, this message translates to:
  /// **'Use selected sound'**
  String get soundConfirmSelection;

  /// No description provided for @soundClearSelection.
  ///
  /// In en, this message translates to:
  /// **'Remove music'**
  String get soundClearSelection;

  /// No description provided for @soundDetailTitle.
  ///
  /// In en, this message translates to:
  /// **'Sound'**
  String get soundDetailTitle;

  /// No description provided for @soundVideosUsing.
  ///
  /// In en, this message translates to:
  /// **'Videos using this sound'**
  String get soundVideosUsing;

  /// No description provided for @soundNoVideosYet.
  ///
  /// In en, this message translates to:
  /// **'No videos yet'**
  String get soundNoVideosYet;

  /// No description provided for @soundOriginalLink.
  ///
  /// In en, this message translates to:
  /// **'Original: {name}'**
  String soundOriginalLink(String name);

  /// No description provided for @soundUseCount.
  ///
  /// In en, this message translates to:
  /// **'{count} videos'**
  String soundUseCount(int count);

  /// No description provided for @soundUseCountThousands.
  ///
  /// In en, this message translates to:
  /// **'{count}K videos'**
  String soundUseCountThousands(String count);

  /// No description provided for @soundUseCountMillions.
  ///
  /// In en, this message translates to:
  /// **'{count}M videos'**
  String soundUseCountMillions(String count);

  /// No description provided for @soundPostsCount.
  ///
  /// In en, this message translates to:
  /// **'{count} posts'**
  String soundPostsCount(int count);

  /// No description provided for @soundPostsCountThousands.
  ///
  /// In en, this message translates to:
  /// **'{count}K posts'**
  String soundPostsCountThousands(String count);

  /// No description provided for @soundPostsCountMillions.
  ///
  /// In en, this message translates to:
  /// **'{count}M posts'**
  String soundPostsCountMillions(String count);

  /// No description provided for @interestSelectionTitle.
  ///
  /// In en, this message translates to:
  /// **'Choose your interests'**
  String get interestSelectionTitle;

  /// No description provided for @interestSelectionSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Pick a few categories so we can personalize your experience.'**
  String get interestSelectionSubtitle;

  /// No description provided for @interestSelectionSkip.
  ///
  /// In en, this message translates to:
  /// **'Skip'**
  String get interestSelectionSkip;

  /// No description provided for @interestSelectionContinue.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get interestSelectionContinue;

  /// No description provided for @interestSelectionMinHint.
  ///
  /// In en, this message translates to:
  /// **'Select at least {count} interests'**
  String interestSelectionMinHint(int count);

  /// No description provided for @interestSelectionCountHint.
  ///
  /// In en, this message translates to:
  /// **'{selected}/{min} interested'**
  String interestSelectionCountHint(int selected, int min);

  /// No description provided for @interestSelectionNotInterestedHint.
  ///
  /// In en, this message translates to:
  /// **'Tap again to mark as not interested (optional).'**
  String get interestSelectionNotInterestedHint;

  /// No description provided for @interestSelectionNotInterestedLegend.
  ///
  /// In en, this message translates to:
  /// **'Not interested'**
  String get interestSelectionNotInterestedLegend;

  /// No description provided for @interestSelectionInterestedLegend.
  ///
  /// In en, this message translates to:
  /// **'Interested'**
  String get interestSelectionInterestedLegend;

  /// No description provided for @interestSelectionSave.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get interestSelectionSave;

  /// No description provided for @settingsInterests.
  ///
  /// In en, this message translates to:
  /// **'Interests'**
  String get settingsInterests;

  /// No description provided for @settingsMyProducts.
  ///
  /// In en, this message translates to:
  /// **'My Products'**
  String get settingsMyProducts;

  /// No description provided for @shopGoToMyProducts.
  ///
  /// In en, this message translates to:
  /// **'Go to My Products'**
  String get shopGoToMyProducts;

  /// No description provided for @shopMakeAuction.
  ///
  /// In en, this message translates to:
  /// **'Show on live'**
  String get shopMakeAuction;

  /// No description provided for @shopMyProductsSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search my products...'**
  String get shopMyProductsSearchHint;

  /// No description provided for @shopFilterAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get shopFilterAll;

  /// No description provided for @shopNoMatchingProducts.
  ///
  /// In en, this message translates to:
  /// **'No matching products'**
  String get shopNoMatchingProducts;

  /// No description provided for @shopSortQuantityHigh.
  ///
  /// In en, this message translates to:
  /// **'Qty: High'**
  String get shopSortQuantityHigh;

  /// No description provided for @shopSortQuantityLow.
  ///
  /// In en, this message translates to:
  /// **'Qty: Low'**
  String get shopSortQuantityLow;

  /// No description provided for @shopFilters.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get shopFilters;

  /// No description provided for @shopMediaType.
  ///
  /// In en, this message translates to:
  /// **'Media'**
  String get shopMediaType;

  /// No description provided for @shopMediaImage.
  ///
  /// In en, this message translates to:
  /// **'Image'**
  String get shopMediaImage;

  /// No description provided for @shopMediaVideo.
  ///
  /// In en, this message translates to:
  /// **'Video'**
  String get shopMediaVideo;

  /// No description provided for @shopMediaCarousel.
  ///
  /// In en, this message translates to:
  /// **'Carousel'**
  String get shopMediaCarousel;

  /// No description provided for @shopMinPriceCoins.
  ///
  /// In en, this message translates to:
  /// **'Min coins'**
  String get shopMinPriceCoins;

  /// No description provided for @shopMaxPriceCoins.
  ///
  /// In en, this message translates to:
  /// **'Max coins'**
  String get shopMaxPriceCoins;

  /// No description provided for @shopApplyFilters.
  ///
  /// In en, this message translates to:
  /// **'Apply'**
  String get shopApplyFilters;

  /// No description provided for @shopClearFilters.
  ///
  /// In en, this message translates to:
  /// **'Clear'**
  String get shopClearFilters;

  /// No description provided for @retry.
  ///
  /// In en, this message translates to:
  /// **'Try again'**
  String get retry;

  /// No description provided for @seeTranslation.
  ///
  /// In en, this message translates to:
  /// **'See translation'**
  String get seeTranslation;

  /// No description provided for @seeOriginal.
  ///
  /// In en, this message translates to:
  /// **'See original'**
  String get seeOriginal;

  /// No description provided for @translationFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not translate'**
  String get translationFailed;

  /// No description provided for @postLinksTitle.
  ///
  /// In en, this message translates to:
  /// **'Links'**
  String get postLinksTitle;

  /// No description provided for @tryEffectAction.
  ///
  /// In en, this message translates to:
  /// **'Try effect'**
  String get tryEffectAction;

  /// No description provided for @effectsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Effects'**
  String get effectsSubtitle;

  /// No description provided for @templateExportPreparing.
  ///
  /// In en, this message translates to:
  /// **'Preparing…'**
  String get templateExportPreparing;

  /// No description provided for @templateExportUploading.
  ///
  /// In en, this message translates to:
  /// **'Uploading…'**
  String get templateExportUploading;

  /// No description provided for @templateExportUploaded.
  ///
  /// In en, this message translates to:
  /// **'Uploaded'**
  String get templateExportUploaded;

  /// No description provided for @templateExportPreparingSlots.
  ///
  /// In en, this message translates to:
  /// **'Preparing slots…'**
  String get templateExportPreparingSlots;

  /// No description provided for @templateExportRendering.
  ///
  /// In en, this message translates to:
  /// **'Rendering…'**
  String get templateExportRendering;

  /// No description provided for @templateExportAlmostDone.
  ///
  /// In en, this message translates to:
  /// **'Almost done…'**
  String get templateExportAlmostDone;

  /// No description provided for @templateExportDownloading.
  ///
  /// In en, this message translates to:
  /// **'Downloading…'**
  String get templateExportDownloading;

  /// No description provided for @templateExportDone.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get templateExportDone;

  /// No description provided for @templateExportFailed.
  ///
  /// In en, this message translates to:
  /// **'Template export failed — try again'**
  String get templateExportFailed;

  /// No description provided for @templateCouldNotLoad.
  ///
  /// In en, this message translates to:
  /// **'Could not load template'**
  String get templateCouldNotLoad;

  /// No description provided for @templatePreviewFailed.
  ///
  /// In en, this message translates to:
  /// **'Template preview failed'**
  String get templatePreviewFailed;

  /// No description provided for @templateHandoffFailed.
  ///
  /// In en, this message translates to:
  /// **'Could not hand off template video'**
  String get templateHandoffFailed;

  /// No description provided for @templateApplying.
  ///
  /// In en, this message translates to:
  /// **'Applying template…'**
  String get templateApplying;

  /// No description provided for @templateAddMediaToPreview.
  ///
  /// In en, this message translates to:
  /// **'Add media to preview'**
  String get templateAddMediaToPreview;

  /// No description provided for @templateNeedMediaFirst.
  ///
  /// In en, this message translates to:
  /// **'Take or add a photo/video first'**
  String get templateNeedMediaFirst;

  /// No description provided for @mediaStudioTemplates.
  ///
  /// In en, this message translates to:
  /// **'Templates'**
  String get mediaStudioTemplates;

  /// No description provided for @pinToTop.
  ///
  /// In en, this message translates to:
  /// **'Pin to top'**
  String get pinToTop;

  /// No description provided for @unpin.
  ///
  /// In en, this message translates to:
  /// **'Unpin'**
  String get unpin;

  /// No description provided for @pinnedToTopSuccess.
  ///
  /// In en, this message translates to:
  /// **'Pinned to top of profile'**
  String get pinnedToTopSuccess;

  /// No description provided for @unpinnedSuccess.
  ///
  /// In en, this message translates to:
  /// **'Unpinned from profile'**
  String get unpinnedSuccess;

  /// No description provided for @closeFriendsTab.
  ///
  /// In en, this message translates to:
  /// **'Close Friends'**
  String get closeFriendsTab;

  /// No description provided for @addCloseFriendsTitle.
  ///
  /// In en, this message translates to:
  /// **'Add Close Friends'**
  String get addCloseFriendsTitle;

  /// No description provided for @addCloseFriendsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Choose friends to add to your close friends list'**
  String get addCloseFriendsSubtitle;

  /// No description provided for @searchCloseFriendsHint.
  ///
  /// In en, this message translates to:
  /// **'Search close friends...'**
  String get searchCloseFriendsHint;

  /// No description provided for @noCloseFriendsYet.
  ///
  /// In en, this message translates to:
  /// **'No close friends added yet.'**
  String get noCloseFriendsYet;

  /// No description provided for @profileLinksTitle.
  ///
  /// In en, this message translates to:
  /// **'Links'**
  String get profileLinksTitle;

  /// No description provided for @noLinksAddedYet.
  ///
  /// In en, this message translates to:
  /// **'No links added yet.'**
  String get noLinksAddedYet;

  /// No description provided for @accountTypePersonal.
  ///
  /// In en, this message translates to:
  /// **'Personal'**
  String get accountTypePersonal;

  /// No description provided for @accountTypeCreator.
  ///
  /// In en, this message translates to:
  /// **'Creator'**
  String get accountTypeCreator;

  /// No description provided for @accountTypeBusiness.
  ///
  /// In en, this message translates to:
  /// **'Business'**
  String get accountTypeBusiness;

  /// No description provided for @badgeOfficial.
  ///
  /// In en, this message translates to:
  /// **'Official'**
  String get badgeOfficial;

  /// No description provided for @badgeCreator.
  ///
  /// In en, this message translates to:
  /// **'Creator'**
  String get badgeCreator;

  /// No description provided for @addToHighlights.
  ///
  /// In en, this message translates to:
  /// **'Add to highlights'**
  String get addToHighlights;

  /// No description provided for @newHighlight.
  ///
  /// In en, this message translates to:
  /// **'New highlight'**
  String get newHighlight;

  /// No description provided for @editCover.
  ///
  /// In en, this message translates to:
  /// **'Edit cover'**
  String get editCover;

  /// No description provided for @highlightsTitle.
  ///
  /// In en, this message translates to:
  /// **'Highlights'**
  String get highlightsTitle;

  /// No description provided for @noStoriesInArchive.
  ///
  /// In en, this message translates to:
  /// **'No stories found in archive'**
  String get noStoriesInArchive;

  /// No description provided for @removeFromHighlight.
  ///
  /// In en, this message translates to:
  /// **'Remove from Highlight'**
  String get removeFromHighlight;

  /// No description provided for @highlightCreated.
  ///
  /// In en, this message translates to:
  /// **'Highlight created'**
  String get highlightCreated;

  /// No description provided for @highlightUpdated.
  ///
  /// In en, this message translates to:
  /// **'Highlight updated'**
  String get highlightUpdated;

  /// No description provided for @chooseFromGallery.
  ///
  /// In en, this message translates to:
  /// **'Choose from Gallery'**
  String get chooseFromGallery;

  /// No description provided for @pasteImageUrl.
  ///
  /// In en, this message translates to:
  /// **'Paste Image URL'**
  String get pasteImageUrl;

  /// No description provided for @newHighlightButton.
  ///
  /// In en, this message translates to:
  /// **'New'**
  String get newHighlightButton;

  /// No description provided for @aboutThisStory.
  ///
  /// In en, this message translates to:
  /// **'About this story'**
  String get aboutThisStory;

  /// No description provided for @editHighlight.
  ///
  /// In en, this message translates to:
  /// **'Edit highlight'**
  String get editHighlight;

  /// No description provided for @deleteHighlight.
  ///
  /// In en, this message translates to:
  /// **'Delete Highlight'**
  String get deleteHighlight;

  /// No description provided for @highlightDeleted.
  ///
  /// In en, this message translates to:
  /// **'Highlight deleted'**
  String get highlightDeleted;

  /// No description provided for @highlightEmptyRemoved.
  ///
  /// In en, this message translates to:
  /// **'This highlight is empty and was removed'**
  String get highlightEmptyRemoved;

  /// No description provided for @highlightNameLabel.
  ///
  /// In en, this message translates to:
  /// **'Highlight Name'**
  String get highlightNameLabel;

  /// No description provided for @highlightNameHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. Travel, Memories'**
  String get highlightNameHint;

  /// No description provided for @coverUpdated.
  ///
  /// In en, this message translates to:
  /// **'Cover updated'**
  String get coverUpdated;

  /// No description provided for @failedToUploadCover.
  ///
  /// In en, this message translates to:
  /// **'Failed to upload cover image'**
  String get failedToUploadCover;

  /// No description provided for @failedToLoadHighlightDetails.
  ///
  /// In en, this message translates to:
  /// **'Failed to load highlight details'**
  String get failedToLoadHighlightDetails;

  /// No description provided for @failedToAddStoryToHighlight.
  ///
  /// In en, this message translates to:
  /// **'Failed to add story to highlight'**
  String get failedToAddStoryToHighlight;

  /// No description provided for @marketplaceTitle.
  ///
  /// In en, this message translates to:
  /// **'Marketplace'**
  String get marketplaceTitle;

  /// No description provided for @marketplaceLikedProducts.
  ///
  /// In en, this message translates to:
  /// **'Liked Products'**
  String get marketplaceLikedProducts;

  /// No description provided for @marketplaceNoLikedProducts.
  ///
  /// In en, this message translates to:
  /// **'No liked products yet'**
  String get marketplaceNoLikedProducts;

  /// No description provided for @marketplaceTagline.
  ///
  /// In en, this message translates to:
  /// **'Buy. Own. Resell.'**
  String get marketplaceTagline;

  /// No description provided for @marketplaceSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search products, brands, categories...'**
  String get marketplaceSearchHint;

  /// No description provided for @marketplaceHeroTitle.
  ///
  /// In en, this message translates to:
  /// **'Buy. Own. Resell.'**
  String get marketplaceHeroTitle;

  /// No description provided for @marketplaceHeroSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Purchase products and resell eligible purchases through Bimo-Bond auctions.'**
  String get marketplaceHeroSubtitle;

  /// No description provided for @marketplaceExploreCta.
  ///
  /// In en, this message translates to:
  /// **'Explore Marketplace'**
  String get marketplaceExploreCta;

  /// No description provided for @marketplaceCategories.
  ///
  /// In en, this message translates to:
  /// **'Categories'**
  String get marketplaceCategories;

  /// No description provided for @marketplaceRecommended.
  ///
  /// In en, this message translates to:
  /// **'Recommended for You'**
  String get marketplaceRecommended;

  /// No description provided for @marketplaceEndingSoon.
  ///
  /// In en, this message translates to:
  /// **'Ending Soon Auctions'**
  String get marketplaceEndingSoon;

  /// No description provided for @marketplaceNoAuctions.
  ///
  /// In en, this message translates to:
  /// **'No active auctions ending soon'**
  String get marketplaceNoAuctions;

  /// No description provided for @marketplaceLiveAuction.
  ///
  /// In en, this message translates to:
  /// **'LIVE AUCTION'**
  String get marketplaceLiveAuction;

  /// No description provided for @marketplaceAuctionLabel.
  ///
  /// In en, this message translates to:
  /// **'AUCTION'**
  String get marketplaceAuctionLabel;

  /// No description provided for @marketplaceCurrentBid.
  ///
  /// In en, this message translates to:
  /// **'Current Bid'**
  String get marketplaceCurrentBid;

  /// No description provided for @marketplaceBidCount.
  ///
  /// In en, this message translates to:
  /// **'{count} Bids'**
  String marketplaceBidCount(int count);

  /// No description provided for @marketplaceViewAuction.
  ///
  /// In en, this message translates to:
  /// **'View Auction'**
  String get marketplaceViewAuction;

  /// No description provided for @marketplaceFilters.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get marketplaceFilters;

  /// No description provided for @marketplaceFilterPrice.
  ///
  /// In en, this message translates to:
  /// **'Price'**
  String get marketplaceFilterPrice;

  /// No description provided for @marketplaceMin.
  ///
  /// In en, this message translates to:
  /// **'Min'**
  String get marketplaceMin;

  /// No description provided for @marketplaceMax.
  ///
  /// In en, this message translates to:
  /// **'Max'**
  String get marketplaceMax;

  /// No description provided for @marketplaceFilterListingType.
  ///
  /// In en, this message translates to:
  /// **'Listing type'**
  String get marketplaceFilterListingType;

  /// No description provided for @marketplaceInStockOnly.
  ///
  /// In en, this message translates to:
  /// **'In stock only'**
  String get marketplaceInStockOnly;

  /// No description provided for @marketplaceClearFilters.
  ///
  /// In en, this message translates to:
  /// **'Clear'**
  String get marketplaceClearFilters;

  /// No description provided for @marketplaceApplyFilters.
  ///
  /// In en, this message translates to:
  /// **'Apply'**
  String get marketplaceApplyFilters;

  /// No description provided for @marketplaceSortPopular.
  ///
  /// In en, this message translates to:
  /// **'Popular'**
  String get marketplaceSortPopular;

  /// No description provided for @marketplaceSortEndingSoon.
  ///
  /// In en, this message translates to:
  /// **'Ending Soon'**
  String get marketplaceSortEndingSoon;

  /// No description provided for @marketplaceProductCount.
  ///
  /// In en, this message translates to:
  /// **'{count} Products'**
  String marketplaceProductCount(int count);

  /// No description provided for @marketplaceTabPurchased.
  ///
  /// In en, this message translates to:
  /// **'Purchased'**
  String get marketplaceTabPurchased;

  /// No description provided for @marketplaceTabPending.
  ///
  /// In en, this message translates to:
  /// **'Pending Delivery'**
  String get marketplaceTabPending;

  /// No description provided for @marketplaceTabDelivered.
  ///
  /// In en, this message translates to:
  /// **'Delivered'**
  String get marketplaceTabDelivered;

  /// No description provided for @marketplaceTabAuctioned.
  ///
  /// In en, this message translates to:
  /// **'Auctioned'**
  String get marketplaceTabAuctioned;

  /// No description provided for @marketplaceTabSold.
  ///
  /// In en, this message translates to:
  /// **'Sold'**
  String get marketplaceTabSold;

  /// No description provided for @marketplaceNoProducts.
  ///
  /// In en, this message translates to:
  /// **'No products in this tab'**
  String get marketplaceNoProducts;

  /// No description provided for @marketplacePurchaseConfirmed.
  ///
  /// In en, this message translates to:
  /// **'Purchase Confirmed'**
  String get marketplacePurchaseConfirmed;

  /// No description provided for @marketplaceDeliveryLabel.
  ///
  /// In en, this message translates to:
  /// **'Delivery'**
  String get marketplaceDeliveryLabel;

  /// No description provided for @marketplaceDeliveryPending.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get marketplaceDeliveryPending;

  /// No description provided for @marketplaceDeliveryShipped.
  ///
  /// In en, this message translates to:
  /// **'Shipped'**
  String get marketplaceDeliveryShipped;

  /// No description provided for @marketplaceDeliveryDelivered.
  ///
  /// In en, this message translates to:
  /// **'Delivered'**
  String get marketplaceDeliveryDelivered;

  /// No description provided for @marketplaceTrackDelivery.
  ///
  /// In en, this message translates to:
  /// **'Track Delivery'**
  String get marketplaceTrackDelivery;

  /// No description provided for @marketplaceSellAtAuction.
  ///
  /// In en, this message translates to:
  /// **'Sell at Auction'**
  String get marketplaceSellAtAuction;

  /// No description provided for @marketplacePurchasePrice.
  ///
  /// In en, this message translates to:
  /// **'Purchase price'**
  String get marketplacePurchasePrice;

  /// No description provided for @marketplaceStartingPrice.
  ///
  /// In en, this message translates to:
  /// **'Starting Price'**
  String get marketplaceStartingPrice;

  /// No description provided for @marketplaceReservePrice.
  ///
  /// In en, this message translates to:
  /// **'Reserve Price'**
  String get marketplaceReservePrice;

  /// No description provided for @marketplaceBuyNowPrice.
  ///
  /// In en, this message translates to:
  /// **'Buy Now Price'**
  String get marketplaceBuyNowPrice;

  /// No description provided for @marketplaceAuctionDuration.
  ///
  /// In en, this message translates to:
  /// **'Auction Duration'**
  String get marketplaceAuctionDuration;

  /// No description provided for @marketplaceDescription.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get marketplaceDescription;

  /// No description provided for @marketplaceAuctionPreview.
  ///
  /// In en, this message translates to:
  /// **'Auction Preview'**
  String get marketplaceAuctionPreview;

  /// No description provided for @marketplacePublishAuction.
  ///
  /// In en, this message translates to:
  /// **'Publish Auction'**
  String get marketplacePublishAuction;

  /// No description provided for @marketplaceAuctionPublished.
  ///
  /// In en, this message translates to:
  /// **'Auction published'**
  String get marketplaceAuctionPublished;

  /// No description provided for @marketplacePlaceBid.
  ///
  /// In en, this message translates to:
  /// **'Place Bid'**
  String get marketplacePlaceBid;

  /// No description provided for @marketplaceYourBid.
  ///
  /// In en, this message translates to:
  /// **'Your Bid'**
  String get marketplaceYourBid;

  /// No description provided for @marketplaceConfirmBid.
  ///
  /// In en, this message translates to:
  /// **'Confirm Bid'**
  String get marketplaceConfirmBid;

  /// No description provided for @marketplaceEndsIn.
  ///
  /// In en, this message translates to:
  /// **'Ends in'**
  String get marketplaceEndsIn;

  /// No description provided for @marketplaceBidHistory.
  ///
  /// In en, this message translates to:
  /// **'Bid history'**
  String get marketplaceBidHistory;

  /// No description provided for @marketplaceNoBidsYet.
  ///
  /// In en, this message translates to:
  /// **'No bids yet'**
  String get marketplaceNoBidsYet;

  /// No description provided for @marketplaceSpecifications.
  ///
  /// In en, this message translates to:
  /// **'Specifications'**
  String get marketplaceSpecifications;

  /// No description provided for @marketplaceVerifiedProduct.
  ///
  /// In en, this message translates to:
  /// **'Verified Product'**
  String get marketplaceVerifiedProduct;

  /// No description provided for @marketplaceSecurePayment.
  ///
  /// In en, this message translates to:
  /// **'Secure Payment'**
  String get marketplaceSecurePayment;

  /// No description provided for @marketplaceBuyerProtection.
  ///
  /// In en, this message translates to:
  /// **'Buyer Protection'**
  String get marketplaceBuyerProtection;

  /// No description provided for @marketplaceDeliveryTracking.
  ///
  /// In en, this message translates to:
  /// **'Delivery Tracking'**
  String get marketplaceDeliveryTracking;

  /// No description provided for @templateEditorSound.
  ///
  /// In en, this message translates to:
  /// **'Sound'**
  String get templateEditorSound;

  /// No description provided for @templateEditorText.
  ///
  /// In en, this message translates to:
  /// **'Text'**
  String get templateEditorText;

  /// No description provided for @templateEditorEffects.
  ///
  /// In en, this message translates to:
  /// **'Effects'**
  String get templateEditorEffects;

  /// No description provided for @templateEditorFilters.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get templateEditorFilters;

  /// No description provided for @templateEditorTransitions.
  ///
  /// In en, this message translates to:
  /// **'Transitions'**
  String get templateEditorTransitions;

  /// No description provided for @templateEditorStickers.
  ///
  /// In en, this message translates to:
  /// **'Stickers'**
  String get templateEditorStickers;

  /// No description provided for @templateEditorCopy.
  ///
  /// In en, this message translates to:
  /// **'Copy'**
  String get templateEditorCopy;

  /// No description provided for @templateEditorDelete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get templateEditorDelete;

  /// No description provided for @templateEditorLayers.
  ///
  /// In en, this message translates to:
  /// **'Layers'**
  String get templateEditorLayers;

  /// No description provided for @templateEditorNone.
  ///
  /// In en, this message translates to:
  /// **'None'**
  String get templateEditorNone;

  /// No description provided for @templateEditorTrending.
  ///
  /// In en, this message translates to:
  /// **'Trending'**
  String get templateEditorTrending;

  /// No description provided for @templateEditorApply.
  ///
  /// In en, this message translates to:
  /// **'Apply'**
  String get templateEditorApply;

  /// No description provided for @templateEditorDefault.
  ///
  /// In en, this message translates to:
  /// **'Default'**
  String get templateEditorDefault;

  /// No description provided for @templateEditorPhoto.
  ///
  /// In en, this message translates to:
  /// **'Photo'**
  String get templateEditorPhoto;

  /// No description provided for @templateEditorVideo.
  ///
  /// In en, this message translates to:
  /// **'Video'**
  String get templateEditorVideo;

  /// No description provided for @templateEditorFont.
  ///
  /// In en, this message translates to:
  /// **'Font'**
  String get templateEditorFont;

  /// No description provided for @templateEditorAddText.
  ///
  /// In en, this message translates to:
  /// **'Add text'**
  String get templateEditorAddText;

  /// No description provided for @templateEditorReplaceText.
  ///
  /// In en, this message translates to:
  /// **'Replace text'**
  String get templateEditorReplaceText;

  /// No description provided for @templateEditorReplaceSticker.
  ///
  /// In en, this message translates to:
  /// **'Replace sticker'**
  String get templateEditorReplaceSticker;

  /// No description provided for @templateEditorReplaceFilter.
  ///
  /// In en, this message translates to:
  /// **'Replace filter'**
  String get templateEditorReplaceFilter;

  /// No description provided for @templateEditorReplaceEffect.
  ///
  /// In en, this message translates to:
  /// **'Replace effect'**
  String get templateEditorReplaceEffect;

  /// No description provided for @templateEditorReplaceTransition.
  ///
  /// In en, this message translates to:
  /// **'Replace transition'**
  String get templateEditorReplaceTransition;

  /// No description provided for @templateEditorReplaceMusic.
  ///
  /// In en, this message translates to:
  /// **'Replace music'**
  String get templateEditorReplaceMusic;

  /// No description provided for @templateEditorAddFilterClip.
  ///
  /// In en, this message translates to:
  /// **'Add filter · clip {clip}'**
  String templateEditorAddFilterClip(int clip);

  /// No description provided for @templateEditorAddEffectClip.
  ///
  /// In en, this message translates to:
  /// **'Add effect · clip {clip}'**
  String templateEditorAddEffectClip(int clip);

  /// No description provided for @templateEditorAddTransition.
  ///
  /// In en, this message translates to:
  /// **'Add transition'**
  String get templateEditorAddTransition;

  /// No description provided for @templateEditorFilterLayers.
  ///
  /// In en, this message translates to:
  /// **'Filter layers'**
  String get templateEditorFilterLayers;

  /// No description provided for @templateEditorEffectLayers.
  ///
  /// In en, this message translates to:
  /// **'Effect layers'**
  String get templateEditorEffectLayers;

  /// No description provided for @templateEditorServerPreview.
  ///
  /// In en, this message translates to:
  /// **'Server preview'**
  String get templateEditorServerPreview;

  /// No description provided for @templateEditorContinueWithRender.
  ///
  /// In en, this message translates to:
  /// **'Tap → to continue with this render'**
  String get templateEditorContinueWithRender;

  /// No description provided for @templateEditorTypeBelow.
  ///
  /// In en, this message translates to:
  /// **'Type below…'**
  String get templateEditorTypeBelow;

  /// No description provided for @templateEditorTypeCaption.
  ///
  /// In en, this message translates to:
  /// **'Type your caption…'**
  String get templateEditorTypeCaption;

  /// No description provided for @templateEditorDragPinchResize.
  ///
  /// In en, this message translates to:
  /// **'Drag to move · Pinch to resize'**
  String get templateEditorDragPinchResize;

  /// No description provided for @templateEditorTapMediaToPlace.
  ///
  /// In en, this message translates to:
  /// **'Tap media to place · Drag to move'**
  String get templateEditorTapMediaToPlace;

  /// No description provided for @templateEditorPickStickerBelow.
  ///
  /// In en, this message translates to:
  /// **'Pick a sticker below'**
  String get templateEditorPickStickerBelow;

  /// No description provided for @templateEditorTapStickerBelow.
  ///
  /// In en, this message translates to:
  /// **'Tap a sticker below'**
  String get templateEditorTapStickerBelow;

  /// No description provided for @templateEditorDragResizeSticker.
  ///
  /// In en, this message translates to:
  /// **'Drag to move · Pinch or ± to resize'**
  String get templateEditorDragResizeSticker;

  /// No description provided for @templateEditorMaxFiltersPerClip.
  ///
  /// In en, this message translates to:
  /// **'Max {count} filters per clip'**
  String templateEditorMaxFiltersPerClip(int count);

  /// No description provided for @templateEditorMaxEffectsPerClip.
  ///
  /// In en, this message translates to:
  /// **'Max {count} effects per clip'**
  String templateEditorMaxEffectsPerClip(int count);

  /// No description provided for @templateEditorTransitionsNeedClips.
  ///
  /// In en, this message translates to:
  /// **'Transitions need at least 2 clips'**
  String get templateEditorTransitionsNeedClips;

  /// No description provided for @templateEditorAddMediaAllSlots.
  ///
  /// In en, this message translates to:
  /// **'Add media to all slots before rendering.'**
  String get templateEditorAddMediaAllSlots;

  /// No description provided for @templateEditorCouldNotRender.
  ///
  /// In en, this message translates to:
  /// **'Could not render on server'**
  String get templateEditorCouldNotRender;

  /// No description provided for @templateEditorExportFailed.
  ///
  /// In en, this message translates to:
  /// **'Export failed'**
  String get templateEditorExportFailed;

  /// No description provided for @templateEditorPresetNone.
  ///
  /// In en, this message translates to:
  /// **'None'**
  String get templateEditorPresetNone;

  /// No description provided for @templateEditorPresetCinematic.
  ///
  /// In en, this message translates to:
  /// **'Cinematic'**
  String get templateEditorPresetCinematic;

  /// No description provided for @templateEditorPresetWarm.
  ///
  /// In en, this message translates to:
  /// **'Warm'**
  String get templateEditorPresetWarm;

  /// No description provided for @templateEditorPresetCool.
  ///
  /// In en, this message translates to:
  /// **'Cool'**
  String get templateEditorPresetCool;

  /// No description provided for @templateEditorPresetVintage.
  ///
  /// In en, this message translates to:
  /// **'Vintage'**
  String get templateEditorPresetVintage;

  /// No description provided for @templateEditorPresetVivid.
  ///
  /// In en, this message translates to:
  /// **'Vivid'**
  String get templateEditorPresetVivid;

  /// No description provided for @templateEditorPresetFade.
  ///
  /// In en, this message translates to:
  /// **'Fade'**
  String get templateEditorPresetFade;

  /// No description provided for @templateEditorPresetBw.
  ///
  /// In en, this message translates to:
  /// **'B&W'**
  String get templateEditorPresetBw;

  /// No description provided for @templateEditorPresetZoomIn.
  ///
  /// In en, this message translates to:
  /// **'Zoom in'**
  String get templateEditorPresetZoomIn;

  /// No description provided for @templateEditorPresetZoomOut.
  ///
  /// In en, this message translates to:
  /// **'Zoom out'**
  String get templateEditorPresetZoomOut;

  /// No description provided for @templateEditorPresetShake.
  ///
  /// In en, this message translates to:
  /// **'Shake'**
  String get templateEditorPresetShake;

  /// No description provided for @templateEditorPresetPulse.
  ///
  /// In en, this message translates to:
  /// **'Pulse'**
  String get templateEditorPresetPulse;

  /// No description provided for @templateEditorPresetCrossfade.
  ///
  /// In en, this message translates to:
  /// **'Crossfade'**
  String get templateEditorPresetCrossfade;

  /// No description provided for @templateEditorPresetFlash.
  ///
  /// In en, this message translates to:
  /// **'Flash'**
  String get templateEditorPresetFlash;

  /// No description provided for @templateEditorPresetSlideLeft.
  ///
  /// In en, this message translates to:
  /// **'Slide left'**
  String get templateEditorPresetSlideLeft;

  /// No description provided for @templateEditorPresetSlideRight.
  ///
  /// In en, this message translates to:
  /// **'Slide right'**
  String get templateEditorPresetSlideRight;

  /// No description provided for @templateEditorPresetZoom.
  ///
  /// In en, this message translates to:
  /// **'Zoom'**
  String get templateEditorPresetZoom;

  /// No description provided for @templateEditorPresetBlur.
  ///
  /// In en, this message translates to:
  /// **'Blur'**
  String get templateEditorPresetBlur;

  /// No description provided for @templateEditorPresetGlitch.
  ///
  /// In en, this message translates to:
  /// **'Glitch'**
  String get templateEditorPresetGlitch;

  /// No description provided for @templateEditorPresetFilmBurn.
  ///
  /// In en, this message translates to:
  /// **'Film burn'**
  String get templateEditorPresetFilmBurn;

  /// No description provided for @templateEditorClipReplace.
  ///
  /// In en, this message translates to:
  /// **'Replace'**
  String get templateEditorClipReplace;

  /// No description provided for @templateEditorClipVolume.
  ///
  /// In en, this message translates to:
  /// **'Volume'**
  String get templateEditorClipVolume;

  /// No description provided for @templateEditorClipReduceNoise.
  ///
  /// In en, this message translates to:
  /// **'Reduce noise'**
  String get templateEditorClipReduceNoise;

  /// No description provided for @templateEditorClipRotate.
  ///
  /// In en, this message translates to:
  /// **'Rotate'**
  String get templateEditorClipRotate;

  /// No description provided for @templateEditorClipBeautify.
  ///
  /// In en, this message translates to:
  /// **'Beautify'**
  String get templateEditorClipBeautify;

  /// No description provided for @templateEditorClipAdjust.
  ///
  /// In en, this message translates to:
  /// **'Adjust'**
  String get templateEditorClipAdjust;

  /// No description provided for @templateEditorClipOverlay.
  ///
  /// In en, this message translates to:
  /// **'Overlay'**
  String get templateEditorClipOverlay;

  /// No description provided for @templateEditorClipReverse.
  ///
  /// In en, this message translates to:
  /// **'Reverse'**
  String get templateEditorClipReverse;

  /// No description provided for @templateEditorClipFreeze.
  ///
  /// In en, this message translates to:
  /// **'Freeze'**
  String get templateEditorClipFreeze;

  /// No description provided for @templateEditorClipMask.
  ///
  /// In en, this message translates to:
  /// **'Mask'**
  String get templateEditorClipMask;

  /// No description provided for @templateEditorClipOpacity.
  ///
  /// In en, this message translates to:
  /// **'Opacity'**
  String get templateEditorClipOpacity;

  /// No description provided for @templateEditorClipVoiceEffect.
  ///
  /// In en, this message translates to:
  /// **'Voice effect'**
  String get templateEditorClipVoiceEffect;

  /// No description provided for @templateEditorClipAnimation.
  ///
  /// In en, this message translates to:
  /// **'Animation'**
  String get templateEditorClipAnimation;

  /// No description provided for @templateEditorClipCutout.
  ///
  /// In en, this message translates to:
  /// **'Cutout'**
  String get templateEditorClipCutout;

  /// No description provided for @templateEditorClipBackground.
  ///
  /// In en, this message translates to:
  /// **'Background'**
  String get templateEditorClipBackground;

  /// No description provided for @templateEditorClipMagic.
  ///
  /// In en, this message translates to:
  /// **'Magic'**
  String get templateEditorClipMagic;

  /// No description provided for @templateEditorClipComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Coming soon'**
  String get templateEditorClipComingSoon;

  /// No description provided for @livePromotionPromotedLabel.
  ///
  /// In en, this message translates to:
  /// **'Promoted'**
  String get livePromotionPromotedLabel;

  /// No description provided for @lpTitle.
  ///
  /// In en, this message translates to:
  /// **'Promote LIVE'**
  String get lpTitle;

  /// No description provided for @lpMine.
  ///
  /// In en, this message translates to:
  /// **'My LIVE promotions'**
  String get lpMine;

  /// No description provided for @lpPreLive.
  ///
  /// In en, this message translates to:
  /// **'Start your public LIVE first, then open Share → Promote. This camera preview has no saved LIVE to promote.'**
  String get lpPreLive;

  /// No description provided for @lpUnavailable.
  ///
  /// In en, this message translates to:
  /// **'LIVE promotions are temporarily unavailable. Please try again later.'**
  String get lpUnavailable;

  /// No description provided for @lpEligibility.
  ///
  /// In en, this message translates to:
  /// **'Only the host of a public planned or active LIVE can promote it, using an account that is neither private nor banned. Eligibility must be confirmed.'**
  String get lpEligibility;

  /// No description provided for @lpDisabled.
  ///
  /// In en, this message translates to:
  /// **'LIVE promotions are currently disabled.'**
  String get lpDisabled;

  /// No description provided for @lpObjective.
  ///
  /// In en, this message translates to:
  /// **'Your goal'**
  String get lpObjective;

  /// No description provided for @lpViews.
  ///
  /// In en, this message translates to:
  /// **'More viewers'**
  String get lpViews;

  /// No description provided for @lpFollowers.
  ///
  /// In en, this message translates to:
  /// **'More followers'**
  String get lpFollowers;

  /// No description provided for @lpAudience.
  ///
  /// In en, this message translates to:
  /// **'Audience'**
  String get lpAudience;

  /// No description provided for @lpAutomatic.
  ///
  /// In en, this message translates to:
  /// **'Automatic audience'**
  String get lpAutomatic;

  /// No description provided for @lpCustomAudience.
  ///
  /// In en, this message translates to:
  /// **'Custom audience'**
  String get lpCustomAudience;

  /// No description provided for @lpAutomaticHint.
  ///
  /// In en, this message translates to:
  /// **'Let the service select people likely to watch your LIVE.'**
  String get lpAutomaticHint;

  /// No description provided for @lpGenders.
  ///
  /// In en, this message translates to:
  /// **'Genders'**
  String get lpGenders;

  /// No description provided for @lpAgeMin.
  ///
  /// In en, this message translates to:
  /// **'Minimum age (optional)'**
  String get lpAgeMin;

  /// No description provided for @lpAgeMax.
  ///
  /// In en, this message translates to:
  /// **'Maximum age (optional)'**
  String get lpAgeMax;

  /// No description provided for @lpCountries.
  ///
  /// In en, this message translates to:
  /// **'Countries'**
  String get lpCountries;

  /// No description provided for @lpLanguages.
  ///
  /// In en, this message translates to:
  /// **'Languages'**
  String get lpLanguages;

  /// No description provided for @lpCategories.
  ///
  /// In en, this message translates to:
  /// **'Interests'**
  String get lpCategories;

  /// No description provided for @lpOptionsUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Audience options are unavailable. Retry to load them.'**
  String get lpOptionsUnavailable;

  /// No description provided for @lpGeo.
  ///
  /// In en, this message translates to:
  /// **'Geographic targeting (optional)'**
  String get lpGeo;

  /// No description provided for @lpLatitude.
  ///
  /// In en, this message translates to:
  /// **'Latitude'**
  String get lpLatitude;

  /// No description provided for @lpLongitude.
  ///
  /// In en, this message translates to:
  /// **'Longitude'**
  String get lpLongitude;

  /// No description provided for @lpRadius.
  ///
  /// In en, this message translates to:
  /// **'Radius in km'**
  String get lpRadius;

  /// No description provided for @lpPickMap.
  ///
  /// In en, this message translates to:
  /// **'Choose on map'**
  String get lpPickMap;

  /// No description provided for @lpClearGeo.
  ///
  /// In en, this message translates to:
  /// **'Clear location'**
  String get lpClearGeo;

  /// No description provided for @lpBudget.
  ///
  /// In en, this message translates to:
  /// **'Budget'**
  String get lpBudget;

  /// No description provided for @lpCustomBudget.
  ///
  /// In en, this message translates to:
  /// **'Custom budget'**
  String get lpCustomBudget;

  /// No description provided for @lpPackage.
  ///
  /// In en, this message translates to:
  /// **'Package'**
  String get lpPackage;

  /// No description provided for @lpPackagesUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Packages are unavailable. You can prepare a custom budget.'**
  String get lpPackagesUnavailable;

  /// No description provided for @lpCoins.
  ///
  /// In en, this message translates to:
  /// **'Coins'**
  String get lpCoins;

  /// No description provided for @lpDuration.
  ///
  /// In en, this message translates to:
  /// **'Duration in days'**
  String get lpDuration;

  /// No description provided for @lpEstimates.
  ///
  /// In en, this message translates to:
  /// **'Estimated results'**
  String get lpEstimates;

  /// No description provided for @lpEstimateHint.
  ///
  /// In en, this message translates to:
  /// **'Estimates are not guaranteed. Actual delivery depends on your LIVE and audience.'**
  String get lpEstimateHint;

  /// No description provided for @lpNoEstimates.
  ///
  /// In en, this message translates to:
  /// **'Estimates are unavailable.'**
  String get lpNoEstimates;

  /// No description provided for @lpCreate.
  ///
  /// In en, this message translates to:
  /// **'Create campaign'**
  String get lpCreate;

  /// No description provided for @lpCreateHint.
  ///
  /// In en, this message translates to:
  /// **'Creating a campaign does not pay for it. You will review and confirm payment separately.'**
  String get lpCreateHint;

  /// No description provided for @lpSave.
  ///
  /// In en, this message translates to:
  /// **'Save changes'**
  String get lpSave;

  /// No description provided for @lpEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit campaign'**
  String get lpEdit;

  /// No description provided for @lpPay.
  ///
  /// In en, this message translates to:
  /// **'Review payment'**
  String get lpPay;

  /// No description provided for @lpConfirmPay.
  ///
  /// In en, this message translates to:
  /// **'Confirm and pay'**
  String get lpConfirmPay;

  /// No description provided for @lpCost.
  ///
  /// In en, this message translates to:
  /// **'Campaign cost'**
  String get lpCost;

  /// No description provided for @lpBalance.
  ///
  /// In en, this message translates to:
  /// **'Current coin balance'**
  String get lpBalance;

  /// No description provided for @lpUnknown.
  ///
  /// In en, this message translates to:
  /// **'Unavailable'**
  String get lpUnknown;

  /// No description provided for @lpRetry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get lpRetry;

  /// No description provided for @lpRefresh.
  ///
  /// In en, this message translates to:
  /// **'Refresh'**
  String get lpRefresh;

  /// No description provided for @lpCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel campaign'**
  String get lpCancel;

  /// No description provided for @lpCancelHint.
  ///
  /// In en, this message translates to:
  /// **'Cancel this campaign? The server refunds unused prepaid coins. The updated balance may take a moment to appear.'**
  String get lpCancelHint;

  /// No description provided for @lpBack.
  ///
  /// In en, this message translates to:
  /// **'Back'**
  String get lpBack;

  /// No description provided for @lpPause.
  ///
  /// In en, this message translates to:
  /// **'Pause'**
  String get lpPause;

  /// No description provided for @lpResume.
  ///
  /// In en, this message translates to:
  /// **'Resume'**
  String get lpResume;

  /// No description provided for @lpEmpty.
  ///
  /// In en, this message translates to:
  /// **'No LIVE promotions yet'**
  String get lpEmpty;

  /// No description provided for @lpEmptyHint.
  ///
  /// In en, this message translates to:
  /// **'Open Share → Promote while hosting a public LIVE.'**
  String get lpEmptyHint;

  /// No description provided for @lpLoadMore.
  ///
  /// In en, this message translates to:
  /// **'Load more'**
  String get lpLoadMore;

  /// No description provided for @lpPending.
  ///
  /// In en, this message translates to:
  /// **'Pending payment'**
  String get lpPending;

  /// No description provided for @lpActive.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get lpActive;

  /// No description provided for @lpPaused.
  ///
  /// In en, this message translates to:
  /// **'Paused'**
  String get lpPaused;

  /// No description provided for @lpCompleted.
  ///
  /// In en, this message translates to:
  /// **'Completed'**
  String get lpCompleted;

  /// No description provided for @lpCancelled.
  ///
  /// In en, this message translates to:
  /// **'Cancelled'**
  String get lpCancelled;

  /// No description provided for @lpUnknownStatus.
  ///
  /// In en, this message translates to:
  /// **'Status unavailable — refresh'**
  String get lpUnknownStatus;

  /// No description provided for @lpImpressions.
  ///
  /// In en, this message translates to:
  /// **'Impressions'**
  String get lpImpressions;

  /// No description provided for @lpSpend.
  ///
  /// In en, this message translates to:
  /// **'Coins spent'**
  String get lpSpend;

  /// No description provided for @lpRemaining.
  ///
  /// In en, this message translates to:
  /// **'Coins remaining'**
  String get lpRemaining;

  /// No description provided for @lpPaymentUnknown.
  ///
  /// In en, this message translates to:
  /// **'Payment is being verified. Refresh campaign and balance before taking further action. Do not pay again while the outcome is unknown.'**
  String get lpPaymentUnknown;

  /// No description provided for @lpCleanup.
  ///
  /// In en, this message translates to:
  /// **'LIVE has ended. Campaign status and any unused balance refund are being updated.'**
  String get lpCleanup;

  /// No description provided for @lpInsufficient.
  ///
  /// In en, this message translates to:
  /// **'Your coin balance is insufficient. Top up, then refresh before confirming payment.'**
  String get lpInsufficient;

  /// No description provided for @lpTopUp.
  ///
  /// In en, this message translates to:
  /// **'Top up coins'**
  String get lpTopUp;

  /// No description provided for @lpValidation.
  ///
  /// In en, this message translates to:
  /// **'Check the budget mode, minimum 5 coins, duration (1, 3, 7 or 14 days), age order, and complete valid geographic coordinates with a positive radius.'**
  String get lpValidation;

  /// No description provided for @lpInteger.
  ///
  /// In en, this message translates to:
  /// **'Enter a whole number.'**
  String get lpInteger;

  /// No description provided for @lpNumber.
  ///
  /// In en, this message translates to:
  /// **'Enter a valid finite number.'**
  String get lpNumber;

  /// No description provided for @lpClose.
  ///
  /// In en, this message translates to:
  /// **'Close promotions'**
  String get lpClose;

  /// No description provided for @liveMetricUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Not available'**
  String get liveMetricUnavailable;

  /// No description provided for @liveSummaryTitle.
  ///
  /// In en, this message translates to:
  /// **'LIVE summary'**
  String get liveSummaryTitle;

  /// No description provided for @liveSummaryEmpty.
  ///
  /// In en, this message translates to:
  /// **'No summary available.'**
  String get liveSummaryEmpty;

  /// No description provided for @liveSummaryDuration.
  ///
  /// In en, this message translates to:
  /// **'Duration (seconds)'**
  String get liveSummaryDuration;

  /// No description provided for @liveSummaryPeak.
  ///
  /// In en, this message translates to:
  /// **'Peak viewers'**
  String get liveSummaryPeak;

  /// No description provided for @liveSummarySessions.
  ///
  /// In en, this message translates to:
  /// **'Viewer sessions'**
  String get liveSummarySessions;

  /// No description provided for @liveSummaryLikes.
  ///
  /// In en, this message translates to:
  /// **'Likes'**
  String get liveSummaryLikes;

  /// No description provided for @liveSummaryComments.
  ///
  /// In en, this message translates to:
  /// **'Comments'**
  String get liveSummaryComments;

  /// No description provided for @liveSummaryCoins.
  ///
  /// In en, this message translates to:
  /// **'Earned coins'**
  String get liveSummaryCoins;

  /// No description provided for @liveSummaryGifters.
  ///
  /// In en, this message translates to:
  /// **'Top gifters'**
  String get liveSummaryGifters;

  /// No description provided for @liveSummaryUnique.
  ///
  /// In en, this message translates to:
  /// **'Unique viewers'**
  String get liveSummaryUnique;

  /// No description provided for @liveSummaryWatch.
  ///
  /// In en, this message translates to:
  /// **'Watch time (seconds)'**
  String get liveSummaryWatch;

  /// No description provided for @liveSummaryAverage.
  ///
  /// In en, this message translates to:
  /// **'Average watch time (seconds)'**
  String get liveSummaryAverage;

  /// No description provided for @liveSummaryFollowers.
  ///
  /// In en, this message translates to:
  /// **'New followers'**
  String get liveSummaryFollowers;

  /// No description provided for @liveSummaryShares.
  ///
  /// In en, this message translates to:
  /// **'Shares'**
  String get liveSummaryShares;

  /// No description provided for @liveSummaryOrders.
  ///
  /// In en, this message translates to:
  /// **'Shop orders'**
  String get liveSummaryOrders;

  /// No description provided for @liveSummaryRevenue.
  ///
  /// In en, this message translates to:
  /// **'Shop revenue (coins)'**
  String get liveSummaryRevenue;

  /// No description provided for @liveSummaryTraffic.
  ///
  /// In en, this message translates to:
  /// **'Traffic sources'**
  String get liveSummaryTraffic;

  /// No description provided for @liveGiftGoalLabel.
  ///
  /// In en, this message translates to:
  /// **'Gift goal'**
  String get liveGiftGoalLabel;

  /// No description provided for @liveFanClubPriceUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Subscription prices are not verified yet. Joining is unavailable.'**
  String get liveFanClubPriceUnavailable;

  /// No description provided for @liveDiscoveryForYou.
  ///
  /// In en, this message translates to:
  /// **'For You'**
  String get liveDiscoveryForYou;

  /// No description provided for @liveDiscoveryFollowing.
  ///
  /// In en, this message translates to:
  /// **'Following'**
  String get liveDiscoveryFollowing;

  /// No description provided for @liveDiscoveryNearby.
  ///
  /// In en, this message translates to:
  /// **'Nearby'**
  String get liveDiscoveryNearby;

  /// No description provided for @liveDiscoveryAudio.
  ///
  /// In en, this message translates to:
  /// **'Audio'**
  String get liveDiscoveryAudio;

  /// No description provided for @liveDiscoveryFilter.
  ///
  /// In en, this message translates to:
  /// **'Filter LIVE'**
  String get liveDiscoveryFilter;

  /// No description provided for @liveDiscoveryTopic.
  ///
  /// In en, this message translates to:
  /// **'Topic'**
  String get liveDiscoveryTopic;

  /// No description provided for @liveDiscoveryCategory.
  ///
  /// In en, this message translates to:
  /// **'Category ID'**
  String get liveDiscoveryCategory;

  /// No description provided for @liveLocationUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Enable location services and allow location access to see nearby LIVE streams.'**
  String get liveLocationUnavailable;

  /// No description provided for @liveGalleryReorder.
  ///
  /// In en, this message translates to:
  /// **'Drag to reorder'**
  String get liveGalleryReorder;

  /// No description provided for @liveLeagueTitle.
  ///
  /// In en, this message translates to:
  /// **'Host league'**
  String get liveLeagueTitle;

  /// No description provided for @liveLeagueProgress.
  ///
  /// In en, this message translates to:
  /// **'Progress to next tier'**
  String get liveLeagueProgress;

  /// No description provided for @liveReplayTitle.
  ///
  /// In en, this message translates to:
  /// **'Replay and clips'**
  String get liveReplayTitle;

  /// No description provided for @liveRecordingStatus.
  ///
  /// In en, this message translates to:
  /// **'Recording status'**
  String get liveRecordingStatus;

  /// No description provided for @liveReplayStatus.
  ///
  /// In en, this message translates to:
  /// **'Replay status'**
  String get liveReplayStatus;

  /// No description provided for @liveReplayUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Playback needs a verified response from the replay service.'**
  String get liveReplayUnavailable;

  /// No description provided for @liveCouponCode.
  ///
  /// In en, this message translates to:
  /// **'Coupon code'**
  String get liveCouponCode;

  /// No description provided for @liveApplyCoupon.
  ///
  /// In en, this message translates to:
  /// **'Apply coupon'**
  String get liveApplyCoupon;

  /// No description provided for @liveDeal.
  ///
  /// In en, this message translates to:
  /// **'LIVE deal'**
  String get liveDeal;

  /// No description provided for @liveDealPrice.
  ///
  /// In en, this message translates to:
  /// **'Flash price (coins)'**
  String get liveDealPrice;

  /// No description provided for @liveDealEnd.
  ///
  /// In en, this message translates to:
  /// **'Flash ends at (ISO time)'**
  String get liveDealEnd;

  /// No description provided for @liveDealDiscount.
  ///
  /// In en, this message translates to:
  /// **'Coupon discount (coins)'**
  String get liveDealDiscount;

  /// No description provided for @liveDealSave.
  ///
  /// In en, this message translates to:
  /// **'Save deal'**
  String get liveDealSave;

  /// No description provided for @liveDealSold.
  ///
  /// In en, this message translates to:
  /// **'Sold'**
  String get liveDealSold;

  /// No description provided for @liveCouponAvailable.
  ///
  /// In en, this message translates to:
  /// **'Coupon available'**
  String get liveCouponAvailable;

  /// No description provided for @liveTicketEnabled.
  ///
  /// In en, this message translates to:
  /// **'Paid entry'**
  String get liveTicketEnabled;

  /// No description provided for @liveTicketPrice.
  ///
  /// In en, this message translates to:
  /// **'Ticket price (coins)'**
  String get liveTicketPrice;

  /// No description provided for @liveTicketBuy.
  ///
  /// In en, this message translates to:
  /// **'Buy ticket for {coins} coins'**
  String liveTicketBuy(int coins);

  /// No description provided for @liveTicketRequiredDetail.
  ///
  /// In en, this message translates to:
  /// **'This LIVE requires a ticket before entry.'**
  String get liveTicketRequiredDetail;

  /// No description provided for @liveTicketUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Could not check entry access. Please refresh.'**
  String get liveTicketUnavailable;

  /// No description provided for @livePaymentUnresolved.
  ///
  /// In en, this message translates to:
  /// **'Your payment is awaiting confirmation. Check its status before paying again.'**
  String get livePaymentUnresolved;

  /// No description provided for @liveTicketChecking.
  ///
  /// In en, this message translates to:
  /// **'Checking entry access…'**
  String get liveTicketChecking;

  /// No description provided for @liveTicketTitle.
  ///
  /// In en, this message translates to:
  /// **'LIVE entry'**
  String get liveTicketTitle;

  /// No description provided for @liveTicketRefresh.
  ///
  /// In en, this message translates to:
  /// **'Check ticket status'**
  String get liveTicketRefresh;

  /// No description provided for @liveEntryBack.
  ///
  /// In en, this message translates to:
  /// **'Back'**
  String get liveEntryBack;

  /// No description provided for @shopCouponLabel.
  ///
  /// In en, this message translates to:
  /// **'LIVE coupon'**
  String get shopCouponLabel;

  /// No description provided for @shopCouponHint.
  ///
  /// In en, this message translates to:
  /// **'Enter a coupon code'**
  String get shopCouponHint;

  /// No description provided for @shopCouponApply.
  ///
  /// In en, this message translates to:
  /// **'Apply'**
  String get shopCouponApply;

  /// No description provided for @shopPreviewChanged.
  ///
  /// In en, this message translates to:
  /// **'Your checkout details changed. Review the updated total before paying.'**
  String get shopPreviewChanged;

  /// No description provided for @liveFanClubTiers.
  ///
  /// In en, this message translates to:
  /// **'Membership tiers'**
  String get liveFanClubTiers;

  /// No description provided for @liveFanClubJoinTier.
  ///
  /// In en, this message translates to:
  /// **'Join {tier}'**
  String liveFanClubJoinTier(String tier);

  /// No description provided for @liveFanClubPriceCoins.
  ///
  /// In en, this message translates to:
  /// **'{coins} coins for 30 days'**
  String liveFanClubPriceCoins(int coins);

  /// No description provided for @liveFanClubCurrentTier.
  ///
  /// In en, this message translates to:
  /// **'Your current membership'**
  String get liveFanClubCurrentTier;

  /// No description provided for @liveFanClubLoyalty.
  ///
  /// In en, this message translates to:
  /// **'Loyalty: {badge}'**
  String liveFanClubLoyalty(String badge);

  /// No description provided for @liveFanClubEmotes.
  ///
  /// In en, this message translates to:
  /// **'Club emotes'**
  String get liveFanClubEmotes;

  /// No description provided for @liveFanClubEmoteLocked.
  ///
  /// In en, this message translates to:
  /// **'Unlocks with {tier}'**
  String liveFanClubEmoteLocked(String tier);

  /// No description provided for @liveFanClubConfirmTitle.
  ///
  /// In en, this message translates to:
  /// **'Confirm membership'**
  String get liveFanClubConfirmTitle;

  /// No description provided for @liveFanClubConfirmBody.
  ///
  /// In en, this message translates to:
  /// **'{coins} coins will be taken from your wallet for {tier} membership for 30 days.'**
  String liveFanClubConfirmBody(int coins, String tier);

  /// No description provided for @liveFanClubConfirmAction.
  ///
  /// In en, this message translates to:
  /// **'Pay and continue'**
  String get liveFanClubConfirmAction;

  /// No description provided for @liveFanClubAwaitingConfirmation.
  ///
  /// In en, this message translates to:
  /// **'An earlier membership payment is not confirmed yet. Check your membership before trying again.'**
  String get liveFanClubAwaitingConfirmation;

  /// No description provided for @liveFanClubHostSettings.
  ///
  /// In en, this message translates to:
  /// **'Club settings'**
  String get liveFanClubHostSettings;

  /// No description provided for @liveFanClubHostPrice.
  ///
  /// In en, this message translates to:
  /// **'Basic membership price (coins)'**
  String get liveFanClubHostPrice;

  /// No description provided for @liveFanClubHostName.
  ///
  /// In en, this message translates to:
  /// **'Club name'**
  String get liveFanClubHostName;

  /// No description provided for @liveFanClubHostEnabled.
  ///
  /// In en, this message translates to:
  /// **'Enable fan club'**
  String get liveFanClubHostEnabled;

  /// No description provided for @liveFanClubAddEmote.
  ///
  /// In en, this message translates to:
  /// **'Add emote'**
  String get liveFanClubAddEmote;

  /// No description provided for @liveFanClubEmoteCode.
  ///
  /// In en, this message translates to:
  /// **'Emote code'**
  String get liveFanClubEmoteCode;

  /// No description provided for @liveFanClubEmoteImage.
  ///
  /// In en, this message translates to:
  /// **'Image URL'**
  String get liveFanClubEmoteImage;

  /// No description provided for @liveFanClubEmoteMinTier.
  ///
  /// In en, this message translates to:
  /// **'Minimum tier'**
  String get liveFanClubEmoteMinTier;

  /// No description provided for @liveFanClubSave.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get liveFanClubSave;

  /// No description provided for @liveReplayRefresh.
  ///
  /// In en, this message translates to:
  /// **'Refresh'**
  String get liveReplayRefresh;

  /// No description provided for @liveReplayViews.
  ///
  /// In en, this message translates to:
  /// **'Views: {count}'**
  String liveReplayViews(int count);

  /// No description provided for @liveReplayExpires.
  ///
  /// In en, this message translates to:
  /// **'Expires on {date}'**
  String liveReplayExpires(String date);

  /// No description provided for @liveReplayPreparing.
  ///
  /// In en, this message translates to:
  /// **'The recording is still being prepared; the replay is not ready yet.'**
  String get liveReplayPreparing;

  /// No description provided for @liveReplayGone.
  ///
  /// In en, this message translates to:
  /// **'This replay is no longer available.'**
  String get liveReplayGone;

  /// No description provided for @liveReplayPublish.
  ///
  /// In en, this message translates to:
  /// **'Publish replay URL'**
  String get liveReplayPublish;

  /// No description provided for @liveReplayRemove.
  ///
  /// In en, this message translates to:
  /// **'Delete replay'**
  String get liveReplayRemove;

  /// No description provided for @liveReplayUrl.
  ///
  /// In en, this message translates to:
  /// **'Replay file URL'**
  String get liveReplayUrl;

  /// No description provided for @liveClipSelect.
  ///
  /// In en, this message translates to:
  /// **'Choose the clip start and end'**
  String get liveClipSelect;

  /// No description provided for @liveClipRange.
  ///
  /// In en, this message translates to:
  /// **'From {start} to {end} ({seconds} seconds)'**
  String liveClipRange(String start, String end, int seconds);

  /// No description provided for @liveClipPreview.
  ///
  /// In en, this message translates to:
  /// **'Preview selection'**
  String get liveClipPreview;

  /// No description provided for @liveClipCreate.
  ///
  /// In en, this message translates to:
  /// **'Create clip'**
  String get liveClipCreate;

  /// No description provided for @liveClipPublish.
  ///
  /// In en, this message translates to:
  /// **'Publish clip'**
  String get liveClipPublish;

  /// No description provided for @liveClipTitle.
  ///
  /// In en, this message translates to:
  /// **'Clip title'**
  String get liveClipTitle;

  /// No description provided for @liveClipDescription.
  ///
  /// In en, this message translates to:
  /// **'Post description'**
  String get liveClipDescription;

  /// No description provided for @liveClipsTitle.
  ///
  /// In en, this message translates to:
  /// **'Clips'**
  String get liveClipsTitle;

  /// No description provided for @liveClipsEmpty.
  ///
  /// In en, this message translates to:
  /// **'No clips yet.'**
  String get liveClipsEmpty;

  /// No description provided for @liveClipOpenPost.
  ///
  /// In en, this message translates to:
  /// **'Open post'**
  String get liveClipOpenPost;

  /// No description provided for @liveGamesTitle.
  ///
  /// In en, this message translates to:
  /// **'Official games'**
  String get liveGamesTitle;

  /// No description provided for @liveGamesStart.
  ///
  /// In en, this message translates to:
  /// **'Start a game'**
  String get liveGamesStart;

  /// No description provided for @liveGamesActiveOne.
  ///
  /// In en, this message translates to:
  /// **'A game is already running.'**
  String get liveGamesActiveOne;

  /// No description provided for @liveGamesNone.
  ///
  /// In en, this message translates to:
  /// **'No game right now.'**
  String get liveGamesNone;

  /// No description provided for @liveGameQuiz.
  ///
  /// In en, this message translates to:
  /// **'Quiz'**
  String get liveGameQuiz;

  /// No description provided for @liveGameWheel.
  ///
  /// In en, this message translates to:
  /// **'Prize wheel'**
  String get liveGameWheel;

  /// No description provided for @liveGameLuckyDraw.
  ///
  /// In en, this message translates to:
  /// **'Lucky draw'**
  String get liveGameLuckyDraw;

  /// No description provided for @liveGameQuestion.
  ///
  /// In en, this message translates to:
  /// **'Question'**
  String get liveGameQuestion;

  /// No description provided for @liveGameOption.
  ///
  /// In en, this message translates to:
  /// **'Option {index}'**
  String liveGameOption(int index);

  /// No description provided for @liveGameCorrectOption.
  ///
  /// In en, this message translates to:
  /// **'Correct answer'**
  String get liveGameCorrectOption;

  /// No description provided for @liveGamePrize.
  ///
  /// In en, this message translates to:
  /// **'Prize {index}'**
  String liveGamePrize(int index);

  /// No description provided for @liveGameAddOption.
  ///
  /// In en, this message translates to:
  /// **'Add option'**
  String get liveGameAddOption;

  /// No description provided for @liveGameAddPrize.
  ///
  /// In en, this message translates to:
  /// **'Add prize'**
  String get liveGameAddPrize;

  /// No description provided for @liveGameEnd.
  ///
  /// In en, this message translates to:
  /// **'End game'**
  String get liveGameEnd;

  /// No description provided for @liveGamePlay.
  ///
  /// In en, this message translates to:
  /// **'Play'**
  String get liveGamePlay;

  /// No description provided for @liveGamePlayed.
  ///
  /// In en, this message translates to:
  /// **'You already played'**
  String get liveGamePlayed;

  /// No description provided for @liveGameAnswerHidden.
  ///
  /// In en, this message translates to:
  /// **'The answer appears after the host ends the game.'**
  String get liveGameAnswerHidden;

  /// No description provided for @liveGameWaitingResult.
  ///
  /// In en, this message translates to:
  /// **'Waiting for the server result…'**
  String get liveGameWaitingResult;

  /// No description provided for @liveGameWinner.
  ///
  /// In en, this message translates to:
  /// **'Winner: {name}'**
  String liveGameWinner(String name);

  /// No description provided for @liveGameResultPrize.
  ///
  /// In en, this message translates to:
  /// **'Prize: {prize}'**
  String liveGameResultPrize(String prize);

  /// No description provided for @liveGamePlays.
  ///
  /// In en, this message translates to:
  /// **'Plays: {count}'**
  String liveGamePlays(int count);

  /// No description provided for @liveGameUnsupported.
  ///
  /// In en, this message translates to:
  /// **'This game type is not supported in this build.'**
  String get liveGameUnsupported;

  /// No description provided for @shopLiveDealTitle.
  ///
  /// In en, this message translates to:
  /// **'Live-only deal'**
  String get shopLiveDealTitle;

  /// No description provided for @shopLiveDealFlashPrice.
  ///
  /// In en, this message translates to:
  /// **'Flash price (coins)'**
  String get shopLiveDealFlashPrice;

  /// No description provided for @shopLiveDealFlashEnds.
  ///
  /// In en, this message translates to:
  /// **'Ends in (minutes)'**
  String get shopLiveDealFlashEnds;

  /// No description provided for @shopLiveDealCouponCode.
  ///
  /// In en, this message translates to:
  /// **'Coupon code'**
  String get shopLiveDealCouponCode;

  /// No description provided for @shopLiveDealCouponOff.
  ///
  /// In en, this message translates to:
  /// **'Coupon amount (coins)'**
  String get shopLiveDealCouponOff;

  /// No description provided for @shopLiveDealSave.
  ///
  /// In en, this message translates to:
  /// **'Save deal'**
  String get shopLiveDealSave;

  /// No description provided for @shopLiveDealClearFlash.
  ///
  /// In en, this message translates to:
  /// **'Clear flash deal'**
  String get shopLiveDealClearFlash;

  /// No description provided for @shopLiveDealClearCoupon.
  ///
  /// In en, this message translates to:
  /// **'Clear coupon'**
  String get shopLiveDealClearCoupon;

  /// No description provided for @shopLiveDealNote.
  ///
  /// In en, this message translates to:
  /// **'The server calculates the final price; checkout preview shows it.'**
  String get shopLiveDealNote;

  /// No description provided for @shopLiveDealNeedsBoth.
  ///
  /// In en, this message translates to:
  /// **'Enter the price and the end time together, and the code and amount together.'**
  String get shopLiveDealNeedsBoth;

  /// No description provided for @shopLiveDealSaved.
  ///
  /// In en, this message translates to:
  /// **'Deal updated'**
  String get shopLiveDealSaved;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar': return AppLocalizationsAr();
    case 'en': return AppLocalizationsEn();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
