abstract class Failure {
  final String message;

  Failure(this.message);
}

class ServerFailure extends Failure {
  ServerFailure(super.message);
}

class CacheFailure extends Failure {
  CacheFailure(super.message);
}

class NetworkFailure extends Failure {
  NetworkFailure(super.message);
}

class TimeoutFailure extends Failure {
  TimeoutFailure(super.message);
}

class UnauthorizedFailure extends Failure {
  UnauthorizedFailure(super.message);
}

class UnknownFailure extends Failure {
  UnknownFailure(super.message);
}

class UnresolvedPaymentFailure extends Failure {
  UnresolvedPaymentFailure() : super('Payment awaiting confirmation');
}
