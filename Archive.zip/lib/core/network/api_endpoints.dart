/// Centralized API endpoint constants.
///
/// Override the host with `--dart-define=API_BASE_URL=https://api.example.com`
/// (no trailing slash). LiveKit `url` always comes from Nest start/join responses —
/// never hardcode LiveKit secrets or ports here.
class ApiEndpoints {
  ApiEndpoints._();

  /// Base URL for the Nest HTTP + Socket.IO host.
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://159.65.227.87',
  );

  // ── Auth ──────────────────────────────────────────────
  static const String authSendOtp = '/auth/send-otp';
  static const String authVerifyOtp = '/auth/verify-otp';
  static const String authForgotPassword = '/auth/forgot-password';
  static const String authResetPassword = '/auth/reset-password';
  static const String authLogin = '/auth/login';
  static const String authMe = '/auth/me';
  static const String authLogout = '/auth/logout';

  // ── Users ─────────────────────────────────────────────
  static const String usersMe = '/users/me';
  static const String usersMeInterests = '/users/me/interests';
  static const String usersMeReactivate = '/users/me/reactivate';
  static const String usersMeDeactivate = '/users/me/deactivate';

  // ── Lives (from lives/mobile-api.md) ───────────────────
  static const String lives = '/lives';
  static const String livesFeed = '/lives/feed';
  static const String livesAudio = '/lives/audio';
  static const String livesMine = '/lives/mine';
  static String liveById(String id) => '/lives/$id';
  static String liveStart(String id) => '/lives/$id/start';
  static String liveEnd(String id) => '/lives/$id/end';
  static String livePause(String id) => '/lives/$id/pause';
  static String liveResume(String id) => '/lives/$id/resume';
  static String liveStudio(String id) => '/lives/$id/studio';
  static String liveScene(String id) => '/lives/$id/scene';
  static String liveJoin(String id) => '/lives/$id/join';
  static String liveTicket(String id) => '/lives/$id/ticket';
  static String liveLeave(String id) => '/lives/$id/leave';
  static String liveLike(String id) => '/lives/$id/like';
  static String liveShare(String id) => '/lives/$id/share';
  static String liveReport(String id) => '/lives/$id/report';
  static String liveComments(String id) => '/lives/$id/comments';
  static String liveViewers(String id) => '/lives/$id/viewers';
  static String liveCommentById(String liveId, String commentId) =>
      '/lives/$liveId/comments/$commentId';
  static String liveCommentPin(String liveId, String commentId) =>
      '/lives/$liveId/comments/$commentId/pin';
  static String liveCommentUnpin(String liveId, String commentId) =>
      '/lives/$liveId/comments/$commentId/unpin';
  static String liveSettings(String id) => '/lives/$id/settings';
  static String liveGuests(String id) => '/lives/$id/guests';
  static String liveGuestInvite(String id) => '/lives/$id/guests/invite';
  static String liveGuestAcceptInvite(String id) =>
      '/lives/$id/guests/accept-invite';
  static String liveGuestRequest(String id) => '/lives/$id/guests/request';
  static String liveGuestLeave(String id) => '/lives/$id/guests/leave';
  static String liveGuestToken(String id) => '/lives/$id/guests/token';
  static String liveGuestAccept(String id, String userId) =>
      '/lives/$id/guests/$userId/accept';
  static String liveGuestReject(String id, String userId) =>
      '/lives/$id/guests/$userId/reject';
  static String liveGuestKick(String id, String userId) =>
      '/lives/$id/guests/$userId/kick';
  static String liveGuestMute(String id, String userId) =>
      '/lives/$id/guests/$userId/mute';
  static String liveGuestUnmute(String id, String userId) =>
      '/lives/$id/guests/$userId/unmute';
  static String liveGuestCameraOff(String id, String userId) =>
      '/lives/$id/guests/$userId/camera-off';
  static String liveGuestCameraOn(String id, String userId) =>
      '/lives/$id/guests/$userId/camera-on';
  static String liveGuestPromote(String id, String userId) =>
      '/lives/$id/guests/$userId/promote';
  static String liveGuestDemote(String id, String userId) =>
      '/lives/$id/guests/$userId/demote';
  static String liveBattle(String id) => '/lives/$id/battle';
  static String liveBattleOpponents(String id) => '/lives/$id/battle/opponents';
  static String liveBattleMatch(String id) => '/lives/$id/battle/match';
  static String liveBattleMultiplier(String id) =>
      '/lives/$id/battle/multiplier';
  static String liveBattleEnd(String id, String battleId) =>
      '/lives/$id/battle/$battleId/end';

  // ── 2v2 team PK + BO3 (lives/live-p1-parity.md §7, p2 §3) ──
  static String liveBattleOpenTeams(String id) =>
      '/lives/$id/battle/open-teams';
  static String liveBattleJoin(String id, String battleId) =>
      '/lives/$id/battle/$battleId/join';
  static String liveBattleInvite(String id, String battleId) =>
      '/lives/$id/battle/$battleId/invite';
  static String liveBattleLeave(String id, String battleId) =>
      '/lives/$id/battle/$battleId/leave';
  static String liveBattlePowerUp(String id, String battleId) =>
      '/lives/$id/battle/$battleId/power-up';

  // ── Multi-room co-host (lives/live-p1-parity.md §6, p2 §2) ──
  static String liveCohost(String id) => '/lives/$id/cohost';
  static String liveCohostHosts(String id) => '/lives/$id/cohost/hosts';
  static String liveCohostInvite(String id) => '/lives/$id/cohost/invite';
  static String liveCohostAccept(String id, String sessionId) =>
      '/lives/$id/cohost/$sessionId/accept';
  static String liveCohostEnd(String id, String sessionId) =>
      '/lives/$id/cohost/$sessionId/end';
  static String liveGallery(String id) => '/lives/$id/gallery';
  static String liveGiftGoal(String id) => '/lives/$id/gift-goal';
  static String livePolls(String id) => '/lives/$id/polls';
  static String livePollsActive(String id) => '/lives/$id/polls/active';
  static String livePollVote(String liveId, String pollId) =>
      '/lives/$liveId/polls/$pollId/vote';
  static String livePollEnd(String liveId, String pollId) =>
      '/lives/$liveId/polls/$pollId/end';
  static String liveQuestions(String id) => '/lives/$id/qa';
  static String liveQuestionPin(String liveId, String questionId) =>
      '/lives/$liveId/qa/$questionId/pin';
  static String liveQuestionAnswer(String liveId, String questionId) =>
      '/lives/$liveId/qa/$questionId/answer';
  static String liveTreasureBoxes(String id) => '/lives/$id/treasure-boxes';
  static String liveTreasureBoxClaim(String liveId, String boxId) =>
      '/lives/$liveId/treasure-boxes/$boxId/claim';
  static String liveAuctions(String id) => '/lives/$id/auctions';
  static String liveActiveAuctions(String id) => '/lives/$id/auctions/active';
  static String liveAuctionPin(String liveId, String auctionId) =>
      '/lives/$liveId/auctions/$auctionId/pin';
  static String liveAuctionsReorder(String liveId) =>
      '/lives/$liveId/auctions/reorder';
  static String liveHourlyLeaderboard(String id) =>
      '/lives/$id/leaderboard/hourly';
  static String liveGiftersLeaderboard(String id) =>
      '/lives/$id/leaderboard/gifters';
  static const String livesHourlyLeaderboard = '/lives/leaderboard/hourly';
  static String liveReplay(String id) => '/lives/$id/replay';
  static String liveClips(String id) => '/lives/$id/clips';
  static String liveClipPost(String id, String clipId) =>
      '/lives/$id/clips/$clipId/post';
  static const String livesNearby = '/lives/nearby';
  static const String livesLeagues = '/lives/leagues';
  static String liveHostLeague(String userId) => '/lives/host-league/$userId';
  static String liveViewerMuteChat(String liveId, String userId) =>
      '/lives/$liveId/viewers/$userId/mute-chat';
  static String liveViewerUnmuteChat(String liveId, String userId) =>
      '/lives/$liveId/viewers/$userId/unmute-chat';
  static String liveViewerBan(String liveId, String userId) =>
      '/lives/$liveId/viewers/$userId/ban';
  static String liveViewerUnban(String liveId, String userId) =>
      '/lives/$liveId/viewers/$userId/unban';
  static String liveChatRules(String id) => '/lives/$id/chat-rules';
  static String liveModerators(String id) => '/lives/$id/moderators';
  static String liveModeratorByUser(String liveId, String userId) =>
      '/lives/$liveId/moderators/$userId';
  static const String liveHouses = '/lives/houses';
  static String liveHouseById(String houseId) => '/lives/houses/$houseId';
  static String liveHouseRooms(String houseId) =>
      '/lives/houses/$houseId/rooms';
  static String liveSummary(String id) => '/lives/$id/summary';
  static const String giftsSend = '/gifts/send';

  // ── Official LIVE games (lives/live-p3-parity.md §3) ──
  static const String liveGamesCatalog = '/lives/games/catalog';
  static String liveGames(String liveId) => '/lives/$liveId/games';
  static String liveGamesActive(String liveId) =>
      '/lives/$liveId/games/active';
  static String liveGamePlay(String liveId, String gameId) =>
      '/lives/$liveId/games/$gameId/play';
  static String liveGameEnd(String liveId, String gameId) =>
      '/lives/$liveId/games/$gameId/end';

  // ── Fan Club (lives/mobile-api.md §20) ────────────────
  static String creatorsFanClub(String creatorId) =>
      '/creators/$creatorId/fan-club';
  static String creatorsFanClubSubscribe(String creatorId) =>
      '/creators/$creatorId/fan-club/subscribe';
  static String creatorsFanClubMembers(String creatorId) =>
      '/creators/$creatorId/fan-club/members';
  /// `POST /creators/:id/fan-club/emotes` (endpoints2.md §fan club, host only).
  static String creatorsFanClubEmotes(String creatorId) =>
      '/creators/$creatorId/fan-club/emotes';
  static const String usersMeFanClubs = '/users/me/fan-clubs';

  /// Builds a full URI for the given [path].
  static Uri uri(String path) => Uri.parse('$baseUrl$path');
}
